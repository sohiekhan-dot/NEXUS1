import { useState, useEffect, useRef, useCallback } from "react";

const AGENTS = [
  {
    id: "apex",
    name: "APEX",
    subtitle: "Momentum Predator",
    strategy: "Trend + Breakout",
    color: "#00ff88",
    accent: "#00cc66",
    risk: "High",
    timeframe: "15m–4h",
    pnl: 0,
    winRate: 0,
    trades: 0,
    status: "hunting",
    description: "Rides momentum with surgical entries. Cuts losses instantly, lets winners run indefinitely.",
    indicators: ["RSI", "MACD", "Volume Profile", "ATR"],
  },
  {
    id: "vega",
    name: "VEGA",
    subtitle: "Volatility Harvester",
    strategy: "Mean Reversion",
    color: "#ff6b35",
    accent: "#cc4a1a",
    risk: "Medium",
    timeframe: "1h–1D",
    pnl: 0,
    winRate: 0,
    trades: 0,
    status: "analyzing",
    description: "Exploits fear and greed cycles. Enters when the crowd panics, exits when they celebrate.",
    indicators: ["Bollinger Bands", "OBV", "Fear Index", "Z-Score"],
  },
  {
    id: "nova",
    name: "NOVA",
    subtitle: "Quantum Arbitrageur",
    strategy: "Statistical Arbitrage",
    color: "#a78bfa",
    accent: "#7c3aed",
    risk: "Low",
    timeframe: "Tick–5m",
    pnl: 0,
    winRate: 0,
    trades: 0,
    status: "executing",
    description: "Exploits micro-inefficiencies across correlated pairs with sub-millisecond precision.",
    indicators: ["Correlation Matrix", "Cointegration", "Spread Z", "Kelly Criterion"],
  },
  {
    id: "ares",
    name: "ARES",
    subtitle: "Order Flow Predator",
    strategy: "Dark Pool + Tape Reading",
    color: "#f43f5e",
    accent: "#be123c",
    risk: "Very High",
    timeframe: "1m–30m",
    pnl: 0,
    winRate: 0,
    trades: 0,
    status: "waiting",
    description: "Reads institutional order flow. Follows the smart money before the move happens.",
    indicators: ["Delta", "CVD", "Footprint", "Imbalance"],
  },
];

const SYMBOLS = ["BTC/USDT", "ETH/USDT", "SOL/USDT", "AAPL", "NVDA", "GOLD", "SPY", "EUR/USD"];

function generatePrice(base, volatility) {
  return base * (1 + (Math.random() - 0.5) * volatility);
}

function useMarketData() {
  const [prices, setPrices] = useState({
    "BTC/USDT": 68420,
    "ETH/USDT": 3845,
    "SOL/USDT": 182,
    AAPL: 214.5,
    NVDA: 875.3,
    GOLD: 2345,
    SPY: 528.4,
    "EUR/USD": 1.0842,
  });
  const [changes, setChanges] = useState({});

  useEffect(() => {
    const interval = setInterval(() => {
      setPrices((prev) => {
        const next = { ...prev };
        const newChanges = {};
        Object.keys(next).forEach((sym) => {
          const volatility = sym.includes("USDT") ? 0.003 : sym === "EUR/USD" ? 0.0008 : 0.002;
          const newPrice = generatePrice(next[sym], volatility);
          newChanges[sym] = newPrice > next[sym] ? "up" : "down";
          next[sym] = newPrice;
        });
        setChanges(newChanges);
        return next;
      });
    }, 800);
    return () => clearInterval(interval);
  }, []);

  return { prices, changes };
}

function useAgentSimulation() {
  const [agents, setAgents] = useState(
    AGENTS.map((a) => ({
      ...a,
      pnl: (Math.random() - 0.3) * 50000,
      winRate: 55 + Math.random() * 25,
      trades: Math.floor(Math.random() * 500) + 50,
      equity: Array.from({ length: 30 }, (_, i) => 100000 + (Math.random() - 0.4) * 5000 * i),
      recentTrades: [],
    }))
  );

  useEffect(() => {
    const interval = setInterval(() => {
      setAgents((prev) =>
        prev.map((agent) => {
          const tradeHappens = Math.random() < 0.15;
          if (!tradeHappens) return agent;

          const isWin = Math.random() < agent.winRate / 100;
          const pnlDelta = isWin ? Math.random() * 2000 + 200 : -(Math.random() * 800 + 100);
          const symbol = SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)];
          const side = Math.random() > 0.5 ? "LONG" : "SHORT";

          const newTrade = {
            id: Date.now() + Math.random(),
            symbol,
            side,
            pnl: pnlDelta,
            time: new Date().toLocaleTimeString(),
            win: isWin,
          };

          const statuses = ["hunting", "analyzing", "executing", "waiting", "in position"];
          const newStatus = Math.random() < 0.1 ? statuses[Math.floor(Math.random() * statuses.length)] : agent.status;

          return {
            ...agent,
            pnl: agent.pnl + pnlDelta,
            trades: agent.trades + 1,
            winRate: agent.winRate * 0.995 + (isWin ? 1 : 0) * 0.5,
            status: newStatus,
            equity: [...agent.equity.slice(-29), (agent.equity[agent.equity.length - 1] || 100000) + pnlDelta],
            recentTrades: [newTrade, ...agent.recentTrades.slice(0, 4)],
          };
        })
      );
    }, 1200);
    return () => clearInterval(interval);
  }, []);

  return agents;
}

function MiniChart({ data, color }) {
  const width = 120;
  const height = 40;
  if (!data || data.length < 2) return null;

  const min = Math.min(...data);
  const max = Math.max(...data);
  const range = max - min || 1;

  const points = data
    .map((v, i) => {
      const x = (i / (data.length - 1)) * width;
      const y = height - ((v - min) / range) * height;
      return `${x},${y}`;
    })
    .join(" ");

  const fillPoints = `0,${height} ${points} ${width},${height}`;

  return (
    <svg width={width} height={height} style={{ overflow: "visible" }}>
      <defs>
        <linearGradient id={`grad-${color.replace("#", "")}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.3" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      <polygon points={fillPoints} fill={`url(#grad-${color.replace("#", "")})`} />
      <polyline points={points} fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" />
    </svg>
  );
}

function StatusDot({ status, color }) {
  const statusColors = {
    hunting: "#00ff88",
    analyzing: "#f59e0b",
    executing: "#3b82f6",
    waiting: "#6b7280",
    "in position": "#f43f5e",
  };
  const dotColor = statusColors[status] || color;

  return (
    <span style={{ display: "inline-flex", alignItems: "center", gap: 6 }}>
      <span
        style={{
          width: 8,
          height: 8,
          borderRadius: "50%",
          background: dotColor,
          boxShadow: `0 0 8px ${dotColor}`,
          display: "inline-block",
          animation: status === "executing" || status === "in position" ? "pulse 1s infinite" : "none",
        }}
      />
      <span style={{ color: dotColor, fontSize: 11, fontFamily: "monospace", textTransform: "uppercase", letterSpacing: 1 }}>
        {status}
      </span>
    </span>
  );
}

function AgentCard({ agent, selected, onClick }) {
  const isPositive = agent.pnl >= 0;

  return (
    <div
      onClick={onClick}
      style={{
        background: selected
          ? `linear-gradient(135deg, rgba(${hexToRgb(agent.color)}, 0.12) 0%, rgba(10,10,15,0.95) 100%)`
          : "rgba(10,10,15,0.8)",
        border: `1px solid ${selected ? agent.color : "rgba(255,255,255,0.07)"}`,
        borderRadius: 16,
        padding: "20px 22px",
        cursor: "pointer",
        transition: "all 0.25s cubic-bezier(0.4,0,0.2,1)",
        boxShadow: selected ? `0 0 30px rgba(${hexToRgb(agent.color)}, 0.2), inset 0 1px 0 rgba(${hexToRgb(agent.color)},0.1)` : "none",
        backdropFilter: "blur(20px)",
        position: "relative",
        overflow: "hidden",
      }}
    >
      {selected && (
        <div
          style={{
            position: "absolute",
            top: 0,
            left: 0,
            right: 0,
            height: 2,
            background: `linear-gradient(90deg, transparent, ${agent.color}, transparent)`,
          }}
        />
      )}

      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 14 }}>
        <div>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 2 }}>
            <span
              style={{
                fontFamily: "'Orbitron', monospace",
                fontWeight: 900,
                fontSize: 18,
                color: agent.color,
                letterSpacing: 3,
                textShadow: `0 0 20px ${agent.color}66`,
              }}
            >
              {agent.name}
            </span>
          </div>
          <div style={{ color: "rgba(255,255,255,0.4)", fontSize: 11, fontFamily: "monospace", letterSpacing: 1 }}>
            {agent.subtitle}
          </div>
        </div>
        <StatusDot status={agent.status} color={agent.color} />
      </div>

      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end" }}>
        <div>
          <div
            style={{
              fontFamily: "'Orbitron', monospace",
              fontSize: 20,
              fontWeight: 700,
              color: isPositive ? "#00ff88" : "#f43f5e",
              letterSpacing: 1,
            }}
          >
            {isPositive ? "+" : ""}${agent.pnl.toFixed(0).replace(/\B(?=(\d{3})+(?!\d))/g, ",")}
          </div>
          <div style={{ color: "rgba(255,255,255,0.3)", fontSize: 10, fontFamily: "monospace", marginTop: 2 }}>
            {agent.winRate.toFixed(1)}% WIN · {agent.trades} TRADES
          </div>
        </div>
        <MiniChart data={agent.equity} color={isPositive ? "#00ff88" : "#f43f5e"} />
      </div>
    </div>
  );
}

function hexToRgb(hex) {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return result ? `${parseInt(result[1], 16)},${parseInt(result[2], 16)},${parseInt(result[3], 16)}` : "255,255,255";
}

function EquityChart({ data, color }) {
  const width = 400;
  const height = 120;
  if (!data || data.length < 2) return null;

  const min = Math.min(...data);
  const max = Math.max(...data);
  const range = max - min || 1;

  const points = data
    .map((v, i) => {
      const x = (i / (data.length - 1)) * width;
      const y = height - ((v - min) / range) * (height - 10) - 5;
      return `${x},${y}`;
    })
    .join(" ");

  const fillPoints = `0,${height} ${points} ${width},${height}`;
  const isPositive = data[data.length - 1] >= data[0];
  const chartColor = isPositive ? "#00ff88" : "#f43f5e";

  return (
    <svg width="100%" viewBox={`0 0 ${width} ${height}`} style={{ overflow: "visible" }}>
      <defs>
        <linearGradient id="equityGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={chartColor} stopOpacity="0.25" />
          <stop offset="100%" stopColor={chartColor} stopOpacity="0" />
        </linearGradient>
        <filter id="glow">
          <feGaussianBlur stdDeviation="2" result="coloredBlur" />
          <feMerge>
            <feMergeNode in="coloredBlur" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
      </defs>
      <polygon points={fillPoints} fill="url(#equityGrad)" />
      <polyline points={points} fill="none" stroke={chartColor} strokeWidth="2" strokeLinecap="round" filter="url(#glow)" />
    </svg>
  );
}

function AgentDetail({ agent }) {
  if (!agent) return null;

  const metrics = [
    { label: "SHARPE RATIO", value: (1.2 + Math.random() * 1.8).toFixed(2), suffix: "" },
    { label: "MAX DRAWDOWN", value: -(5 + Math.random() * 15).toFixed(1), suffix: "%" },
    { label: "AVG WIN", value: "$" + (800 + Math.random() * 1200).toFixed(0), suffix: "" },
    { label: "AVG LOSS", value: "-$" + (200 + Math.random() * 400).toFixed(0), suffix: "" },
    { label: "PROFIT FACTOR", value: (1.5 + Math.random() * 1.5).toFixed(2), suffix: "" },
    { label: "TOTAL PNL", value: (agent.pnl >= 0 ? "+" : "") + "$" + Math.abs(agent.pnl).toFixed(0).replace(/\B(?=(\d{3})+(?!\d))/g, ","), suffix: "" },
  ];

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
      <div
        style={{
          background: `linear-gradient(135deg, rgba(${hexToRgb(agent.color)}, 0.08) 0%, rgba(5,5,10,0.9) 100%)`,
          border: `1px solid rgba(${hexToRgb(agent.color)}, 0.2)`,
          borderRadius: 16,
          padding: 24,
        }}
      >
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 16 }}>
          <div>
            <div
              style={{
                fontFamily: "'Orbitron', monospace",
                fontSize: 28,
                fontWeight: 900,
                color: agent.color,
                letterSpacing: 4,
                textShadow: `0 0 30px ${agent.color}88`,
              }}
            >
              {agent.name}
            </div>
            <div style={{ color: "rgba(255,255,255,0.5)", fontSize: 13, marginTop: 4 }}>{agent.description}</div>
          </div>
          <StatusDot status={agent.status} color={agent.color} />
        </div>

        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 16 }}>
          {agent.indicators.map((ind) => (
            <span
              key={ind}
              style={{
                background: `rgba(${hexToRgb(agent.color)}, 0.1)`,
                border: `1px solid rgba(${hexToRgb(agent.color)}, 0.3)`,
                borderRadius: 6,
                padding: "3px 10px",
                fontSize: 10,
                color: agent.color,
                fontFamily: "monospace",
                letterSpacing: 1,
              }}
            >
              {ind}
            </span>
          ))}
        </div>

        <div style={{ marginBottom: 8, color: "rgba(255,255,255,0.3)", fontSize: 10, fontFamily: "monospace", letterSpacing: 1 }}>
          EQUITY CURVE
        </div>
        <EquityChart data={agent.equity} color={agent.color} />
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 10 }}>
        {metrics.map((m) => (
          <div
            key={m.label}
            style={{
              background: "rgba(10,10,15,0.8)",
              border: "1px solid rgba(255,255,255,0.07)",
              borderRadius: 12,
              padding: "14px 16px",
              backdropFilter: "blur(20px)",
            }}
          >
            <div style={{ color: "rgba(255,255,255,0.3)", fontSize: 9, fontFamily: "monospace", letterSpacing: 1, marginBottom: 6 }}>
              {m.label}
            </div>
            <div
              style={{
                fontFamily: "'Orbitron', monospace",
                fontSize: 14,
                fontWeight: 700,
                color: m.value.toString().startsWith("-") ? "#f43f5e" : m.value.toString().startsWith("+") ? "#00ff88" : "white",
              }}
            >
              {m.value}
              {m.suffix}
            </div>
          </div>
        ))}
      </div>

      {agent.recentTrades.length > 0 && (
        <div
          style={{
            background: "rgba(10,10,15,0.8)",
            border: "1px solid rgba(255,255,255,0.07)",
            borderRadius: 16,
            padding: 20,
          }}
        >
          <div style={{ color: "rgba(255,255,255,0.3)", fontSize: 10, fontFamily: "monospace", letterSpacing: 2, marginBottom: 14 }}>
            RECENT EXECUTIONS
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {agent.recentTrades.map((t) => (
              <div
                key={t.id}
                style={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                  padding: "8px 0",
                  borderBottom: "1px solid rgba(255,255,255,0.04)",
                }}
              >
                <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
                  <span
                    style={{
                      background: t.side === "LONG" ? "rgba(0,255,136,0.1)" : "rgba(244,63,94,0.1)",
                      color: t.side === "LONG" ? "#00ff88" : "#f43f5e",
                      border: `1px solid ${t.side === "LONG" ? "rgba(0,255,136,0.3)" : "rgba(244,63,94,0.3)"}`,
                      borderRadius: 4,
                      padding: "2px 7px",
                      fontSize: 9,
                      fontFamily: "monospace",
                      letterSpacing: 1,
                    }}
                  >
                    {t.side}
                  </span>
                  <span style={{ color: "rgba(255,255,255,0.7)", fontSize: 12, fontFamily: "monospace" }}>{t.symbol}</span>
                </div>
                <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
                  <span
                    style={{
                      fontFamily: "'Orbitron', monospace",
                      fontSize: 12,
                      color: t.pnl >= 0 ? "#00ff88" : "#f43f5e",
                    }}
                  >
                    {t.pnl >= 0 ? "+" : ""}${t.pnl.toFixed(0)}
                  </span>
                  <span style={{ color: "rgba(255,255,255,0.2)", fontSize: 10, fontFamily: "monospace" }}>{t.time}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function TickerBar({ prices, changes }) {
  return (
    <div
      style={{
        background: "rgba(5,5,10,0.9)",
        borderBottom: "1px solid rgba(255,255,255,0.06)",
        padding: "8px 0",
        overflow: "hidden",
        position: "relative",
      }}
    >
      <div
        style={{
          display: "flex",
          gap: 40,
          animation: "ticker 30s linear infinite",
          whiteSpace: "nowrap",
        }}
      >
        {[...SYMBOLS, ...SYMBOLS].map((sym, i) => {
          const price = prices[sym] || 0;
          const change = changes[sym];
          return (
            <span key={i} style={{ display: "inline-flex", gap: 8, alignItems: "center" }}>
              <span style={{ color: "rgba(255,255,255,0.4)", fontSize: 11, fontFamily: "monospace", letterSpacing: 1 }}>{sym}</span>
              <span
                style={{
                  fontFamily: "'Orbitron', monospace",
                  fontSize: 11,
                  fontWeight: 600,
                  color: change === "up" ? "#00ff88" : change === "down" ? "#f43f5e" : "white",
                  transition: "color 0.3s",
                }}
              >
                {price < 10 ? price.toFixed(4) : price < 100 ? price.toFixed(2) : price.toFixed(0)}
              </span>
              <span style={{ color: change === "up" ? "#00ff88" : "#f43f5e", fontSize: 9 }}>{change === "up" ? "▲" : "▼"}</span>
            </span>
          );
        })}
      </div>
    </div>
  );
}

export default function TradingAgents() {
  const [selectedId, setSelectedId] = useState("apex");
  const agents = useAgentSimulation();
  const { prices, changes } = useMarketData();
  const selectedAgent = agents.find((a) => a.id === selectedId);

  const totalPnl = agents.reduce((s, a) => s + a.pnl, 0);
  const totalTrades = agents.reduce((s, a) => s + a.trades, 0);
  const avgWinRate = agents.reduce((s, a) => s + a.winRate, 0) / agents.length;

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Share+Tech+Mono&display=swap');
        
        * { box-sizing: border-box; margin: 0; padding: 0; }
        
        body {
          background: #020208;
          min-height: 100vh;
          overflow-x: hidden;
        }
        
        ::-webkit-scrollbar { width: 4px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.1); border-radius: 2px; }
        
        @keyframes ticker {
          0% { transform: translateX(0); }
          100% { transform: translateX(-50%); }
        }
        
        @keyframes pulse {
          0%, 100% { opacity: 1; box-shadow: 0 0 8px currentColor; }
          50% { opacity: 0.5; box-shadow: 0 0 20px currentColor; }
        }
        
        @keyframes scanline {
          0% { top: -10%; }
          100% { top: 110%; }
        }
        
        @keyframes fadeInUp {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
        
        .scan-effect::after {
          content: '';
          position: absolute;
          left: 0;
          right: 0;
          height: 2px;
          background: linear-gradient(90deg, transparent, rgba(0,255,136,0.08), transparent);
          animation: scanline 4s linear infinite;
          pointer-events: none;
          z-index: 1;
        }
        
        .card-hover:hover {
          transform: translateY(-1px);
        }
        
        .animate-in {
          animation: fadeInUp 0.4s ease both;
        }
      `}</style>

      <div
        style={{
          minHeight: "100vh",
          background: "radial-gradient(ellipse at 20% 0%, rgba(0,255,136,0.04) 0%, transparent 60%), radial-gradient(ellipse at 80% 100%, rgba(167,139,250,0.04) 0%, transparent 60%), #020208",
          fontFamily: "'Share Tech Mono', monospace",
          color: "white",
          position: "relative",
        }}
        className="scan-effect"
      >
        {/* Header */}
        <div
          style={{
            padding: "16px 32px",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            borderBottom: "1px solid rgba(255,255,255,0.06)",
            background: "rgba(2,2,8,0.95)",
            backdropFilter: "blur(20px)",
            position: "sticky",
            top: 0,
            zIndex: 100,
          }}
        >
          <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
            <div
              style={{
                width: 36,
                height: 36,
                borderRadius: 10,
                background: "linear-gradient(135deg, #00ff88, #00cc66)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontSize: 18,
                boxShadow: "0 0 20px rgba(0,255,136,0.4)",
              }}
            >
              ◈
            </div>
            <div>
              <div
                style={{
                  fontFamily: "'Orbitron', monospace",
                  fontWeight: 900,
                  fontSize: 16,
                  letterSpacing: 4,
                  color: "white",
                }}
              >
                NEXUS TRADING
              </div>
              <div style={{ color: "rgba(255,255,255,0.3)", fontSize: 9, letterSpacing: 3 }}>AUTONOMOUS AGENT SYSTEM v4.2</div>
            </div>
          </div>

          <div style={{ display: "flex", gap: 32 }}>
            <div style={{ textAlign: "center" }}>
              <div
                style={{
                  fontFamily: "'Orbitron', monospace",
                  fontSize: 18,
                  fontWeight: 700,
                  color: totalPnl >= 0 ? "#00ff88" : "#f43f5e",
                }}
              >
                {totalPnl >= 0 ? "+" : ""}${Math.abs(totalPnl).toFixed(0).replace(/\B(?=(\d{3})+(?!\d))/g, ",")}
              </div>
              <div style={{ color: "rgba(255,255,255,0.3)", fontSize: 9, letterSpacing: 2 }}>PORTFOLIO P&L</div>
            </div>
            <div style={{ textAlign: "center" }}>
              <div style={{ fontFamily: "'Orbitron', monospace", fontSize: 18, fontWeight: 700, color: "#a78bfa" }}>
                {avgWinRate.toFixed(1)}%
              </div>
              <div style={{ color: "rgba(255,255,255,0.3)", fontSize: 9, letterSpacing: 2 }}>AVG WIN RATE</div>
            </div>
            <div style={{ textAlign: "center" }}>
              <div style={{ fontFamily: "'Orbitron', monospace", fontSize: 18, fontWeight: 700, color: "#f59e0b" }}>
                {totalTrades.toLocaleString()}
              </div>
              <div style={{ color: "rgba(255,255,255,0.3)", fontSize: 9, letterSpacing: 2 }}>TOTAL TRADES</div>
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <div
                style={{
                  width: 8,
                  height: 8,
                  borderRadius: "50%",
                  background: "#00ff88",
                  boxShadow: "0 0 10px #00ff88",
                  animation: "pulse 2s infinite",
                }}
              />
              <span style={{ fontSize: 11, color: "rgba(255,255,255,0.4)", letterSpacing: 1 }}>LIVE</span>
            </div>
          </div>
        </div>

        {/* Ticker */}
        <TickerBar prices={prices} changes={changes} />

        {/* Main Content */}
        <div style={{ display: "grid", gridTemplateColumns: "380px 1fr", gap: 0, height: "calc(100vh - 120px)" }}>
          {/* Left sidebar - agent cards */}
          <div
            style={{
              borderRight: "1px solid rgba(255,255,255,0.06)",
              padding: 20,
              display: "flex",
              flexDirection: "column",
              gap: 12,
              overflowY: "auto",
              background: "rgba(2,2,8,0.5)",
            }}
          >
            <div style={{ color: "rgba(255,255,255,0.2)", fontSize: 9, letterSpacing: 3, marginBottom: 4, paddingLeft: 4 }}>
              ACTIVE AGENTS · {agents.filter((a) => a.status !== "waiting").length}/{agents.length} RUNNING
            </div>
            {agents.map((agent) => (
              <div key={agent.id} className="card-hover animate-in" style={{ transition: "transform 0.2s" }}>
                <AgentCard agent={agent} selected={selectedId === agent.id} onClick={() => setSelectedId(agent.id)} />
              </div>
            ))}

            {/* Allocation bar */}
            <div
              style={{
                background: "rgba(10,10,15,0.8)",
                border: "1px solid rgba(255,255,255,0.06)",
                borderRadius: 12,
                padding: 16,
                marginTop: 8,
              }}
            >
              <div style={{ color: "rgba(255,255,255,0.3)", fontSize: 9, letterSpacing: 2, marginBottom: 12 }}>CAPITAL ALLOCATION</div>
              {agents.map((agent) => {
                const pct = 25;
                return (
                  <div key={agent.id} style={{ marginBottom: 8 }}>
                    <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
                      <span style={{ color: agent.color, fontSize: 10, fontFamily: "monospace", letterSpacing: 1 }}>{agent.name}</span>
                      <span style={{ color: "rgba(255,255,255,0.4)", fontSize: 10 }}>{pct}%</span>
                    </div>
                    <div style={{ height: 3, background: "rgba(255,255,255,0.05)", borderRadius: 2 }}>
                      <div
                        style={{
                          height: "100%",
                          width: `${pct}%`,
                          background: `linear-gradient(90deg, ${agent.color}, ${agent.accent})`,
                          borderRadius: 2,
                          boxShadow: `0 0 8px ${agent.color}66`,
                        }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right detail panel */}
          <div style={{ padding: 24, overflowY: "auto" }}>
            <AgentDetail agent={selectedAgent} />
          </div>
        </div>
      </div>
    </>
  );
}
