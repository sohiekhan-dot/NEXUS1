import { useState, useEffect, useRef, useCallback } from "react";

// ─── MEDICAL DATA ENGINE ──────────────────────────────────────────────────────
// Realistic vital sign simulation using physiological ranges
class PatientEngine {
  constructor(id, name, age, condition, severity) {
    this.id = id;
    this.name = name;
    this.age = age;
    this.condition = condition;
    this.severity = severity; // 'stable' | 'watch' | 'critical'
    this.hr  = 60 + Math.random() * 40;
    this.spo2 = 94 + Math.random() * 5;
    this.sbp = 110 + Math.random() * 40;
    this.dbp = 65 + Math.random() * 20;
    this.rr  = 12 + Math.random() * 8;
    this.temp = 36.2 + Math.random() * 1.5;
    this.etco2 = 35 + Math.random() * 8;
    this.gcs  = severity === 'critical' ? 8 + Math.floor(Math.random()*5) : 13 + Math.floor(Math.random()*3);
    this.hrHistory   = Array.from({length:60}, () => this.hr   + (Math.random()-0.5)*8);
    this.spo2History = Array.from({length:60}, () => this.spo2 + (Math.random()-0.5)*2);
    this.sbpHistory  = Array.from({length:60}, () => this.sbp  + (Math.random()-0.5)*12);
    this.ecgBuffer   = [];
    this.alerts      = [];
    this.trend = severity === 'critical' ? 'deteriorating' : severity === 'watch' ? 'monitoring' : 'stable';
  }

  tick() {
    const jitter = (range, bias=0) => (Math.random()-0.5+bias)*range;
    const clamp  = (v, mn, mx) => Math.max(mn, Math.min(mx, v));

    // Drift vitals toward physiological reality
    const severityBias = this.severity === 'critical' ? 0.15 : this.severity === 'watch' ? 0.05 : 0;

    this.hr   = clamp(this.hr   + jitter(3, severityBias*0.3), 40, 200);
    this.spo2 = clamp(this.spo2 + jitter(1, -severityBias*0.2), 70, 100);
    this.sbp  = clamp(this.sbp  + jitter(5, severityBias*0.2), 60, 220);
    this.dbp  = clamp(this.dbp  + jitter(3), 40, 130);
    this.rr   = clamp(this.rr   + jitter(1, severityBias*0.1), 6, 40);
    this.temp = clamp(this.temp + jitter(0.1), 34, 42);
    this.etco2= clamp(this.etco2+ jitter(1), 20, 60);

    this.hrHistory  .push(this.hr);   if(this.hrHistory.length>60)   this.hrHistory.shift();
    this.spo2History.push(this.spo2); if(this.spo2History.length>60) this.spo2History.shift();
    this.sbpHistory .push(this.sbp);  if(this.sbpHistory.length>60)  this.sbpHistory.shift();

    // Generate alerts
    this.alerts = [];
    if(this.hr  > 120) this.alerts.push({type:'TACHYCARDIA', sev:'warn', val:`HR ${this.hr.toFixed(0)}`});
    if(this.hr  < 50)  this.alerts.push({type:'BRADYCARDIA', sev:'crit', val:`HR ${this.hr.toFixed(0)}`});
    if(this.spo2< 92)  this.alerts.push({type:'HYPOXIA',     sev:'crit', val:`SpO₂ ${this.spo2.toFixed(1)}%`});
    if(this.sbp > 180) this.alerts.push({type:'HYPERTENSIVE CRISIS', sev:'crit', val:`BP ${this.sbp.toFixed(0)}`});
    if(this.sbp < 90)  this.alerts.push({type:'HYPOTENSION', sev:'crit', val:`SBP ${this.sbp.toFixed(0)}`});
    if(this.rr  > 25)  this.alerts.push({type:'TACHYPNEA',   sev:'warn', val:`RR ${this.rr.toFixed(0)}`});
    if(this.temp> 38.5)this.alerts.push({type:'FEVER',       sev:'warn', val:`${this.temp.toFixed(1)}°C`});

    return this;
  }

  ecgPoint(t) {
    // Simplified ECG waveform using sum of Gaussians
    const bpm = this.hr;
    const period = 60/bpm;
    const phase = (t % period) / period;
    let v = 0;
    // P wave
    v += 0.15 * Math.exp(-Math.pow((phase-0.15)*20,2));
    // QRS complex
    v -= 0.10 * Math.exp(-Math.pow((phase-0.30)*60,2));
    v += 1.00 * Math.exp(-Math.pow((phase-0.33)*80,2));
    v -= 0.25 * Math.exp(-Math.pow((phase-0.36)*60,2));
    // T wave
    v += 0.35 * Math.exp(-Math.pow((phase-0.55)*18,2));
    return v;
  }
}

const PATIENTS = [
  new PatientEngine(1,"James Okafor",    58,"Post-Op Craniotomy",   "critical"),
  new PatientEngine(2,"Maria Santos",    42,"Acute MI — Cath Lab",  "critical"),
  new PatientEngine(3,"David Chen",      71,"Septic Shock",         "watch"),
  new PatientEngine(4,"Aisha Patel",     35,"Traumatic Brain Injury","watch"),
  new PatientEngine(5,"Robert Williams", 65,"CHF Exacerbation",     "stable"),
  new PatientEngine(6,"Elena Kovacs",    29,"Post-Op Appendectomy", "stable"),
];

// ─── AI AGENTS ────────────────────────────────────────────────────────────────
const AI_AGENTS = [
  {
    id:"sentinel", name:"SENTINEL", role:"Vital Monitor",
    color:"#00d4ff", dept:"MONITORING",
    desc:"Continuous multiparameter monitoring. Detects deterioration patterns 8–12 minutes before clinical threshold breach.",
    icon:"◈",
  },
  {
    id:"oracle", name:"ORACLE", role:"Diagnostic Intelligence",
    color:"#a78bfa", dept:"DIAGNOSTICS",
    desc:"Cross-references symptoms, labs, imaging findings, and patient history against 2.4M clinical cases for differential diagnosis.",
    icon:"⬡",
  },
  {
    id:"aegis", name:"AEGIS", role:"Emergency Response",
    color:"#f43f5e", dept:"EMERGENCY",
    desc:"Emergent response agent. Activates rapid response protocols, routes alerts to clinical staff, and suggests immediate interventions.",
    icon:"▲",
  },
  {
    id:"atlas2", name:"ATLAS", role:"Treatment Planner",
    color:"#10b981", dept:"PLANNING",
    desc:"Evidence-based treatment optimization. Drug interaction screening, dosage calculations, and protocol adherence monitoring.",
    icon:"◉",
  },
];

// ─── HELPERS ──────────────────────────────────────────────────────────────────
function hexToRgb(hex) {
  const r = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return r ? `${parseInt(r[1],16)},${parseInt(r[2],16)},${parseInt(r[3],16)}` : "255,255,255";
}

function sevColor(sev) {
  return sev === 'critical' ? '#f43f5e' : sev === 'watch' ? '#f59e0b' : '#10b981';
}

function vitalStatus(val, type) {
  const ranges = {
    hr:   {low:50,  high:100, crit_low:40,  crit_high:150},
    spo2: {low:95,  high:100, crit_low:90,  crit_high:100},
    sbp:  {low:90,  high:140, crit_low:70,  crit_high:180},
    rr:   {low:12,  high:20,  crit_low:8,   crit_high:30},
    temp: {low:36.0,high:37.5,crit_low:34,  crit_high:39.5},
  };
  const r = ranges[type];
  if(!r) return 'normal';
  if(val < r.crit_low || val > r.crit_high) return 'critical';
  if(val < r.low       || val > r.high)      return 'warning';
  return 'normal';
}

const vitalColors = { normal:'#10b981', warning:'#f59e0b', critical:'#f43f5e' };

// ─── ECG CANVAS ───────────────────────────────────────────────────────────────
function ECGMonitor({ patient, color="#00d4ff" }) {
  const canvasRef = useRef(null);
  const tRef = useRef(0);
  const rafRef = useRef(null);
  const bufRef = useRef([]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if(!canvas) return;
    const ctx = canvas.getContext("2d");
    const W = canvas.offsetWidth, H = canvas.offsetHeight;
    const dpr = window.devicePixelRatio || 1;
    canvas.width = W * dpr; canvas.height = H * dpr;
    ctx.scale(dpr, dpr);

    const BUF = 200;
    bufRef.current = Array(BUF).fill(0);

    function draw() {
      tRef.current += 0.008;
      const newPt = patient.ecgPoint(tRef.current);
      bufRef.current.push(newPt);
      if(bufRef.current.length > BUF) bufRef.current.shift();

      ctx.clearRect(0,0,W,H);

      // Grid
      ctx.strokeStyle = "rgba(0,212,255,0.06)";
      ctx.lineWidth = 1;
      for(let x=0; x<W; x+=20){ ctx.beginPath(); ctx.moveTo(x,0); ctx.lineTo(x,H); ctx.stroke(); }
      for(let y=0; y<H; y+=10){ ctx.beginPath(); ctx.moveTo(0,y); ctx.lineTo(W,y); ctx.stroke(); }

      // ECG trace
      const mid = H/2;
      const amp = H * 0.35;
      ctx.beginPath();
      bufRef.current.forEach((v,i) => {
        const x = (i/(BUF-1))*W;
        const y = mid - v*amp;
        i===0 ? ctx.moveTo(x,y) : ctx.lineTo(x,y);
      });
      ctx.strokeStyle = color;
      ctx.lineWidth = 1.8;
      ctx.shadowColor = color;
      ctx.shadowBlur = 6;
      ctx.stroke();
      ctx.shadowBlur = 0;

      // Sweep line
      const sweepX = ((bufRef.current.length-1)/(BUF-1))*W;
      const grad = ctx.createLinearGradient(sweepX-30,0,sweepX,0);
      grad.addColorStop(0,"rgba(0,0,0,0)");
      grad.addColorStop(1,"rgba(3,7,18,0.9)");
      ctx.fillStyle = grad;
      ctx.fillRect(sweepX-30,0,30,H);

      rafRef.current = requestAnimationFrame(draw);
    }
    draw();
    return () => cancelAnimationFrame(rafRef.current);
  }, [patient.id, color]);

  return <canvas ref={canvasRef} style={{width:"100%",height:"100%",display:"block"}}/>;
}

// ─── VITAL SPARKLINE ─────────────────────────────────────────────────────────
function VitalLine({ data, color, w=80, h=28 }) {
  if(!data||data.length<2) return null;
  const mn=Math.min(...data),mx=Math.max(...data),rng=mx-mn||1;
  const pts=data.slice(-30).map((v,i,a)=>`${(i/(a.length-1))*w},${h-((v-mn)/rng)*(h-4)-2}`).join(" ");
  return (
    <svg width={w} height={h} style={{flexShrink:0}}>
      <polyline points={pts} fill="none" stroke={color} strokeWidth="1.5"
        style={{filter:`drop-shadow(0 0 3px ${color})`}}/>
    </svg>
  );
}

// ─── RADIAL GAUGE ─────────────────────────────────────────────────────────────
function RadialGauge({ value, min, max, label, unit, color, size=90 }) {
  const pct = Math.max(0, Math.min(1, (value-min)/(max-min)));
  const angle = pct * 240 - 120; // -120 to +120 degrees
  const cx=size/2, cy=size/2, r=size/2-10;
  const toXY = (deg, rad) => {
    const a = (deg-90)*Math.PI/180;
    return { x: cx+Math.cos(a)*rad, y: cy+Math.sin(a)*rad };
  };
  const arcPath = (startDeg, endDeg, radius) => {
    const s=toXY(startDeg,radius), e=toXY(endDeg,radius);
    const large=endDeg-startDeg>180?1:0;
    return `M ${s.x} ${s.y} A ${radius} ${radius} 0 ${large} 1 ${e.x} ${e.y}`;
  };
  const needleEnd = toXY(angle, r*0.7);

  return (
    <div style={{display:"flex",flexDirection:"column",alignItems:"center",gap:2}}>
      <svg width={size} height={size*0.75} viewBox={`0 0 ${size} ${size*0.75}`}>
        <path d={arcPath(-120,120,r)} fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="6" strokeLinecap="round"/>
        <path d={arcPath(-120,-120+pct*240,r)} fill="none" stroke={color} strokeWidth="6" strokeLinecap="round"
          style={{filter:`drop-shadow(0 0 4px ${color})`}}/>
        <line x1={cx} y1={cy} x2={needleEnd.x} y2={needleEnd.y}
          stroke={color} strokeWidth="2" strokeLinecap="round"/>
        <circle cx={cx} cy={cy} r="3" fill={color}/>
        <text x={cx} y={cy+16} textAnchor="middle" fill="white" fontSize="13"
          fontFamily="'Orbitron',monospace" fontWeight="700">{value.toFixed(0)}</text>
        <text x={cx} y={cy+26} textAnchor="middle" fill="rgba(255,255,255,0.35)"
          fontSize="7" fontFamily="monospace">{unit}</text>
      </svg>
      <span style={{color:"rgba(255,255,255,0.3)",fontSize:8,fontFamily:"monospace",letterSpacing:1.5}}>{label}</span>
    </div>
  );
}

// ─── PATIENT CARD ─────────────────────────────────────────────────────────────
function PatientCard({ patient, selected, onClick }) {
  const sc = sevColor(patient.severity);
  const hrSt  = vitalStatus(patient.hr,  'hr');
  const spo2St= vitalStatus(patient.spo2,'spo2');
  const sbpSt = vitalStatus(patient.sbp, 'sbp');

  return (
    <div onClick={onClick} style={{
      background: selected
        ? `rgba(${hexToRgb(sc)},0.1)`
        : "rgba(5,10,24,0.85)",
      border:`1px solid ${selected ? sc : "rgba(255,255,255,0.06)"}`,
      borderRadius:12, padding:"14px 16px", cursor:"pointer",
      transition:"all 0.2s", position:"relative", overflow:"hidden",
      boxShadow: selected ? `0 0 24px rgba(${hexToRgb(sc)},0.15)` : "none",
    }}>
      {selected && <div style={{position:"absolute",top:0,left:0,right:0,height:2,background:`linear-gradient(90deg,transparent,${sc},transparent)`}}/>}
      {patient.alerts.length > 0 && (
        <div style={{position:"absolute",top:10,right:10,width:8,height:8,borderRadius:"50%",
          background:"#f43f5e",boxShadow:"0 0 10px #f43f5e",animation:"medPulse 1s infinite"}}/>
      )}
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:10}}>
        <div>
          <div style={{fontFamily:"'Exo 2',sans-serif",fontWeight:700,fontSize:13,color:"white",marginBottom:2}}>{patient.name}</div>
          <div style={{color:"rgba(255,255,255,0.35)",fontSize:9,fontFamily:"monospace",letterSpacing:1}}>
            {patient.age}y · {patient.condition}
          </div>
        </div>
        <span style={{
          background:`rgba(${hexToRgb(sc)},0.12)`,
          border:`1px solid rgba(${hexToRgb(sc)},0.35)`,
          borderRadius:20, padding:"2px 8px",
          fontSize:8, color:sc, fontFamily:"monospace", letterSpacing:1,
          textTransform:"uppercase",
        }}>{patient.severity}</span>
      </div>
      <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:8}}>
        {[
          {l:"HR",v:patient.hr.toFixed(0), u:"bpm", st:hrSt,   hist:patient.hrHistory},
          {l:"SpO₂",v:patient.spo2.toFixed(1),u:"%", st:spo2St, hist:patient.spo2History},
          {l:"SBP",v:patient.sbp.toFixed(0), u:"mmHg",st:sbpSt,  hist:patient.sbpHistory},
        ].map(vt=>(
          <div key={vt.l} style={{background:"rgba(0,0,0,0.3)",borderRadius:7,padding:"6px 8px"}}>
            <div style={{color:"rgba(255,255,255,0.3)",fontSize:7,fontFamily:"monospace",letterSpacing:1,marginBottom:3}}>{vt.l}</div>
            <div style={{fontFamily:"'Orbitron',monospace",fontSize:12,fontWeight:700,
              color:vitalColors[vt.st]}}>{vt.v}<span style={{fontSize:8,opacity:0.6}}> {vt.u}</span></div>
            <VitalLine data={vt.hist} color={vitalColors[vt.st]} w={60} h={18}/>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── VITALS DETAIL ────────────────────────────────────────────────────────────
function VitalsDetail({ patient }) {
  const vitals = [
    {l:"HEART RATE",    v:patient.hr,   unit:"bpm",  min:40, max:160, type:'hr'},
    {l:"SpO₂",          v:patient.spo2, unit:"%",    min:80, max:100, type:'spo2'},
    {l:"SYS BP",        v:patient.sbp,  unit:"mmHg", min:60, max:220, type:'sbp'},
    {l:"DIA BP",        v:patient.dbp,  unit:"mmHg", min:40, max:130, type:null},
    {l:"RESP RATE",     v:patient.rr,   unit:"/min", min:6,  max:40,  type:'rr'},
    {l:"TEMPERATURE",   v:patient.temp, unit:"°C",   min:34, max:41,  type:'temp'},
  ];

  return (
    <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:10}}>
      {vitals.map(vt=>{
        const st = vt.type ? vitalStatus(vt.v, vt.type) : 'normal';
        const c  = vitalColors[st];
        return (
          <div key={vt.l} style={{background:"rgba(5,10,24,0.8)",border:`1px solid rgba(${hexToRgb(c)},0.2)`,
            borderRadius:10,padding:"12px 14px",textAlign:"center"}}>
            <div style={{color:"rgba(255,255,255,0.28)",fontSize:8,fontFamily:"monospace",letterSpacing:1.5,marginBottom:8}}>{vt.l}</div>
            <div style={{fontFamily:"'Orbitron',monospace",fontSize:20,fontWeight:700,color:c,
              textShadow:`0 0 12px ${c}55`}}>{vt.v.toFixed(vt.unit==="°C"?1:0)}</div>
            <div style={{color:"rgba(255,255,255,0.3)",fontSize:10,fontFamily:"monospace",marginTop:2}}>{vt.unit}</div>
            {st!=='normal' && <div style={{fontSize:8,color:c,fontFamily:"monospace",marginTop:5,
              letterSpacing:1,textTransform:"uppercase"}}>⚠ {st}</div>}
          </div>
        );
      })}
    </div>
  );
}

// ─── ALERT FEED ───────────────────────────────────────────────────────────────
function AlertFeed({ patients }) {
  const allAlerts = patients.flatMap(p =>
    p.alerts.map(a => ({ ...a, patient: p.name, room: `ICU-${p.id}`, time: new Date().toLocaleTimeString() }))
  ).sort((a,b) => (a.sev==='crit'?0:1)-(b.sev==='crit'?0:1));

  if(allAlerts.length===0) return (
    <div style={{textAlign:"center",color:"rgba(255,255,255,0.2)",fontSize:11,fontFamily:"monospace",padding:"20px 0"}}>
      ◈ All patients within normal parameters
    </div>
  );

  return (
    <div style={{display:"flex",flexDirection:"column",gap:6}}>
      {allAlerts.slice(0,8).map((a,i)=>(
        <div key={i} style={{
          display:"flex",justifyContent:"space-between",alignItems:"center",
          background:a.sev==='crit'?"rgba(244,63,94,0.07)":"rgba(245,158,11,0.06)",
          border:`1px solid ${a.sev==='crit'?"rgba(244,63,94,0.2)":"rgba(245,158,11,0.15)"}`,
          borderRadius:8, padding:"8px 12px",
          borderLeft:`3px solid ${a.sev==='crit'?"#f43f5e":"#f59e0b"}`,
          animation: a.sev==='crit' ? "alertPulse 2s ease-in-out infinite" : "none",
        }}>
          <div style={{display:"flex",gap:10,alignItems:"center"}}>
            <span style={{fontSize:10,color:a.sev==='crit'?"#f43f5e":"#f59e0b",fontFamily:"monospace",fontWeight:700}}>{a.type}</span>
            <span style={{color:"rgba(255,255,255,0.4)",fontSize:10,fontFamily:"monospace"}}>{a.patient}</span>
            <span style={{color:"rgba(255,255,255,0.25)",fontSize:9,fontFamily:"monospace"}}>{a.room}</span>
          </div>
          <div style={{display:"flex",gap:10,alignItems:"center"}}>
            <span style={{fontFamily:"'Orbitron',monospace",fontSize:10,color:a.sev==='crit'?"#f43f5e":"#f59e0b"}}>{a.val}</span>
            <span style={{color:"rgba(255,255,255,0.2)",fontSize:8,fontFamily:"monospace"}}>{a.time}</span>
          </div>
        </div>
      ))}
    </div>
  );
}

// ─── BRAIN ACTIVITY VISUALIZATION ─────────────────────────────────────────────
function BrainActivityMap({ patient }) {
  const canvasRef = useRef(null);
  const rafRef = useRef(null);
  const t = useRef(0);

  useEffect(()=>{
    const canvas = canvasRef.current;
    if(!canvas) return;
    const ctx = canvas.getContext("2d");
    const dpr = window.devicePixelRatio||1;
    canvas.width = canvas.offsetWidth*dpr;
    canvas.height = canvas.offsetHeight*dpr;
    ctx.scale(dpr,dpr);
    const W=canvas.offsetWidth, H=canvas.offsetHeight;

    // Brain regions with activity levels
    const regions = [
      {name:"Frontal",   x:W*0.5,  y:H*0.22, r:32, base:0.7},
      {name:"Parietal",  x:W*0.5,  y:H*0.42, r:28, base:0.6},
      {name:"Temporal L",x:W*0.22, y:H*0.55, r:22, base:0.5},
      {name:"Temporal R",x:W*0.78, y:H*0.55, r:22, base:0.5},
      {name:"Occipital", x:W*0.5,  y:H*0.72, r:24, base:0.4},
      {name:"Cerebellum",x:W*0.5,  y:H*0.86, r:18, base:0.55},
      {name:"Broca",     x:W*0.28, y:H*0.40, r:14, base:0.65},
      {name:"Motor",     x:W*0.5,  y:H*0.32, r:16, base:0.72},
    ];

    // Severity affects activity — critical patients show abnormal patterns
    const sevMult = patient.severity==='critical' ? 1.4 : patient.severity==='watch' ? 1.1 : 0.9;

    function draw() {
      t.current += 0.02;
      ctx.clearRect(0,0,W,H);

      // Draw brain outline
      ctx.beginPath();
      ctx.ellipse(W/2, H*0.45, W*0.38, H*0.42, 0, 0, Math.PI*2);
      ctx.strokeStyle = "rgba(0,212,255,0.1)";
      ctx.lineWidth = 1;
      ctx.stroke();

      // Brain midline
      ctx.beginPath();
      ctx.moveTo(W/2, H*0.05); ctx.lineTo(W/2, H*0.85);
      ctx.strokeStyle = "rgba(0,212,255,0.06)";
      ctx.setLineDash([4,4]); ctx.stroke(); ctx.setLineDash([]);

      // Draw regions
      regions.forEach((reg, i) => {
        const activity = reg.base * sevMult * (0.8 + 0.4*Math.sin(t.current*1.2 + i*0.8));
        const clampedActivity = Math.max(0, Math.min(1, activity));

        // Color: blue=low, green=normal, yellow=elevated, red=high
        const r2 = clampedActivity > 0.85 ? 244 : clampedActivity > 0.7 ? 245 : 16;
        const g2 = clampedActivity > 0.85 ? 63  : clampedActivity > 0.7 ? 158 : 185;
        const b2 = clampedActivity > 0.85 ? 94  : clampedActivity > 0.7 ? 11  : 129;
        const alpha = 0.15 + clampedActivity * 0.35;

        // Glow
        const grd = ctx.createRadialGradient(reg.x,reg.y,0,reg.x,reg.y,reg.r*1.5);
        grd.addColorStop(0, `rgba(${r2},${g2},${b2},${alpha})`);
        grd.addColorStop(1, "rgba(0,0,0,0)");
        ctx.fillStyle = grd;
        ctx.beginPath();
        ctx.arc(reg.x, reg.y, reg.r*1.5, 0, Math.PI*2);
        ctx.fill();

        // Region circle
        ctx.beginPath();
        ctx.arc(reg.x, reg.y, reg.r, 0, Math.PI*2);
        ctx.strokeStyle = `rgba(${r2},${g2},${b2},${0.4+clampedActivity*0.4})`;
        ctx.lineWidth = 1.5;
        ctx.stroke();

        // Label
        ctx.fillStyle = `rgba(${r2},${g2},${b2},0.7)`;
        ctx.font = `${7*dpr/dpr}px monospace`;
        ctx.textAlign = "center";
        ctx.fillText(reg.name, reg.x, reg.y+reg.r+10);

        // Activity value
        ctx.fillStyle = `rgba(255,255,255,0.5)`;
        ctx.font = `bold ${8*dpr/dpr}px 'Orbitron',monospace`;
        ctx.fillText((clampedActivity*100).toFixed(0)+"%", reg.x, reg.y+4);
      });

      // Connection lines between regions
      const connections = [[0,7],[7,1],[1,2],[1,3],[1,4],[4,5]];
      connections.forEach(([a,b])=>{
        const ra=regions[a], rb=regions[b];
        const strength = (ra.base+rb.base)/2 * (0.7+0.3*Math.sin(t.current+a));
        ctx.beginPath();
        ctx.moveTo(ra.x,ra.y); ctx.lineTo(rb.x,rb.y);
        ctx.strokeStyle = `rgba(0,212,255,${strength*0.15})`;
        ctx.lineWidth = strength*2;
        ctx.stroke();
      });

      rafRef.current = requestAnimationFrame(draw);
    }
    draw();
    return () => cancelAnimationFrame(rafRef.current);
  }, [patient.id, patient.severity]);

  return <canvas ref={canvasRef} style={{width:"100%",height:"100%",display:"block"}}/>;
}

// ─── AI AGENT CARD ────────────────────────────────────────────────────────────
function AgentStatusCard({ agent, activeCount }) {
  const isActive = Math.random() > 0.2;
  return (
    <div style={{
      background:`rgba(${hexToRgb(agent.color)},0.06)`,
      border:`1px solid rgba(${hexToRgb(agent.color)},0.2)`,
      borderRadius:12, padding:"14px 16px",
      position:"relative", overflow:"hidden",
    }}>
      <div style={{position:"absolute",top:0,left:0,right:0,height:2,
        background:`linear-gradient(90deg,transparent,${agent.color},transparent)`}}/>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:10}}>
        <div style={{display:"flex",gap:8,alignItems:"center"}}>
          <span style={{fontSize:18,color:agent.color,textShadow:`0 0 10px ${agent.color}`}}>{agent.icon}</span>
          <div>
            <div style={{fontFamily:"'Orbitron',monospace",fontWeight:900,fontSize:12,
              color:agent.color,letterSpacing:2}}>{agent.name}</div>
            <div style={{color:"rgba(255,255,255,0.3)",fontSize:8,fontFamily:"monospace"}}>{agent.role}</div>
          </div>
        </div>
        <div style={{display:"flex",alignItems:"center",gap:5,
          background:`rgba(${hexToRgb(agent.color)},0.08)`,
          border:`1px solid rgba(${hexToRgb(agent.color)},0.2)`,
          borderRadius:20, padding:"3px 8px"}}>
          <div style={{width:5,height:5,borderRadius:"50%",background:agent.color,
            animation:"medPulse 1.5s infinite",boxShadow:`0 0 6px ${agent.color}`}}/>
          <span style={{fontSize:7,color:agent.color,fontFamily:"monospace",letterSpacing:1}}>ACTIVE</span>
        </div>
      </div>
      <div style={{color:"rgba(255,255,255,0.35)",fontSize:10,lineHeight:1.6,
        fontFamily:"'Exo 2',sans-serif",marginBottom:10}}>{agent.desc}</div>
      <div style={{display:"flex",gap:8}}>
        <div style={{background:"rgba(0,0,0,0.3)",borderRadius:6,padding:"5px 10px",flex:1,textAlign:"center"}}>
          <div style={{fontFamily:"'Orbitron',monospace",fontSize:13,color:agent.color,fontWeight:700}}>
            {activeCount}
          </div>
          <div style={{color:"rgba(255,255,255,0.25)",fontSize:7,fontFamily:"monospace",letterSpacing:1}}>MONITORING</div>
        </div>
        <div style={{background:"rgba(0,0,0,0.3)",borderRadius:6,padding:"5px 10px",flex:1,textAlign:"center"}}>
          <div style={{fontFamily:"'Orbitron',monospace",fontSize:13,color:"#10b981",fontWeight:700}}>99.8%</div>
          <div style={{color:"rgba(255,255,255,0.25)",fontSize:7,fontFamily:"monospace",letterSpacing:1}}>UPTIME</div>
        </div>
      </div>
    </div>
  );
}

// ─── MAIN DASHBOARD ───────────────────────────────────────────────────────────
export default function AETHERDashboard() {
  const [patients, setPatients] = useState(() => PATIENTS);
  const [selectedId, setSelectedId] = useState(1);
  const [activeTab, setActiveTab] = useState("vitals");
  const [tick, setTick] = useState(0);
  const [time, setTime] = useState(new Date());
  const [emergencyLog, setEmergencyLog] = useState([]);

  const selected = patients.find(p => p.id === selectedId);

  // Drive all patient engines
  useEffect(() => {
    const iv = setInterval(() => {
      setPatients(prev => prev.map(p => { p.tick(); return {...p}; }));
      setTick(t => t+1);
      setTime(new Date());
    }, 800);
    return () => clearInterval(iv);
  }, []);

  // Emergency log generation
  useEffect(() => {
    const iv = setInterval(() => {
      const critPatients = patients.filter(p => p.alerts.some(a => a.sev==='crit'));
      if(critPatients.length > 0 && Math.random() < 0.3) {
        const p = critPatients[Math.floor(Math.random()*critPatients.length)];
        const alert = p.alerts.find(a => a.sev==='crit');
        if(alert) {
          const responses = [
            `AEGIS: Rapid Response Team notified for ${p.name} — ${alert.type}`,
            `ORACLE: Differential updated — ${alert.type} in ${p.name}, reviewing etiology`,
            `ATLAS: Protocol initiated — ${alert.type} management for ${p.name}`,
            `SENTINEL: Threshold breach detected — ${p.name} ICU-${p.id}, escalating`,
          ];
          const msg = responses[Math.floor(Math.random()*responses.length)];
          setEmergencyLog(prev => [{
            id:Date.now(), msg, time: new Date().toLocaleTimeString(), type:'alert'
          }, ...prev.slice(0,12)]);
        }
      }
    }, 4000);
    return () => clearInterval(iv);
  }, [patients]);

  const critCount = patients.filter(p => p.severity==='critical').length;
  const watchCount = patients.filter(p => p.severity==='watch').length;
  const allAlerts = patients.flatMap(p => p.alerts);

  const TABS = [
    {id:"vitals",   label:"VITALS",     icon:"◈"},
    {id:"neuro",    label:"NEURO MAP",  icon:"⬡"},
    {id:"agents",   label:"AI AGENTS",  icon:"▦"},
    {id:"alerts",   label:"ALERTS",     icon:"▲"},
  ];

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@400;600;700;900&family=Exo+2:wght@300;400;500;600;700&family=Share+Tech+Mono&display=swap');
        *{box-sizing:border-box;margin:0;padding:0;}
        html,body{height:100%;background:#020b18;overflow:hidden;}
        ::-webkit-scrollbar{width:3px;}
        ::-webkit-scrollbar-thumb{background:rgba(0,212,255,0.15);border-radius:2px;}
        @keyframes medPulse{0%,100%{opacity:1;box-shadow:0 0 8px currentColor}50%{opacity:0.3;box-shadow:0 0 16px currentColor}}
        @keyframes alertPulse{0%,100%{background:rgba(244,63,94,0.07)}50%{background:rgba(244,63,94,0.13)}}
        @keyframes scanH{0%{top:-1px}100%{top:100%}}
        @keyframes fadeUp{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}
        @keyframes spin{to{transform:rotate(360deg)}}
        .fadein{animation:fadeUp 0.3s ease both;}
        select option{background:#020b18;color:white;}
      `}</style>

      <div style={{
        width:"100vw", height:"100vh",
        background:"radial-gradient(ellipse at 20% 0%,rgba(0,212,255,0.05) 0%,transparent 50%),radial-gradient(ellipse at 80% 100%,rgba(16,185,129,0.04) 0%,transparent 50%),#020b18",
        display:"flex", flexDirection:"column", color:"white",
        fontFamily:"'Exo 2',sans-serif", overflow:"hidden", position:"relative",
      }}>
        {/* Grid overlay */}
        <div style={{position:"fixed",inset:0,backgroundImage:"linear-gradient(rgba(0,212,255,0.015) 1px,transparent 1px),linear-gradient(90deg,rgba(0,212,255,0.015) 1px,transparent 1px)",backgroundSize:"44px 44px",pointerEvents:"none",zIndex:0}}/>
        {/* Scanline */}
        <div style={{position:"fixed",left:0,right:0,height:1,background:"linear-gradient(90deg,transparent,rgba(0,212,255,0.07),transparent)",animation:"scanH 8s linear infinite",pointerEvents:"none",zIndex:9999}}/>

        {/* ── HEADER ── */}
        <div style={{position:"relative",zIndex:10,flexShrink:0,background:"rgba(2,11,24,0.96)",backdropFilter:"blur(20px)",borderBottom:"1px solid rgba(0,212,255,0.1)",height:56,display:"flex",alignItems:"center",padding:"0 20px",gap:20}}>
          {/* Logo */}
          <div style={{display:"flex",alignItems:"center",gap:10,flexShrink:0}}>
            <div style={{position:"relative",width:34,height:34}}>
              <svg width="34" height="34" viewBox="0 0 34 34">
                <polygon points="17,2 32,10 32,24 17,32 2,24 2,10" fill="none" stroke="#00d4ff" strokeWidth="1.5" style={{filter:"drop-shadow(0 0 6px #00d4ff)"}}/>
                <polygon points="17,8 26,13 26,21 17,26 8,21 8,13" fill="rgba(0,212,255,0.08)" stroke="rgba(0,212,255,0.4)" strokeWidth="1"/>
                <text x="17" y="21" textAnchor="middle" fill="#00d4ff" fontSize="10" fontFamily="'Orbitron',monospace" fontWeight="900">✚</text>
              </svg>
            </div>
            <div>
              <div style={{fontFamily:"'Orbitron',monospace",fontWeight:900,fontSize:14,letterSpacing:4,color:"#00d4ff",textShadow:"0 0 20px rgba(0,212,255,0.5)"}}>AETHER</div>
              <div style={{fontFamily:"monospace",fontSize:7,color:"rgba(255,255,255,0.25)",letterSpacing:3}}>MEDICAL AI · CLINICAL INTELLIGENCE</div>
            </div>
          </div>

          {/* Tabs */}
          <div style={{display:"flex",gap:2,background:"rgba(2,11,24,0.8)",border:"1px solid rgba(255,255,255,0.07)",borderRadius:10,padding:3}}>
            {TABS.map(t=>(
              <button key={t.id} onClick={()=>setActiveTab(t.id)} style={{
                background:activeTab===t.id?"rgba(0,212,255,0.1)":"transparent",
                border:`1px solid ${activeTab===t.id?"rgba(0,212,255,0.3)":"transparent"}`,
                borderRadius:8, padding:"6px 14px", cursor:"pointer",
                color:activeTab===t.id?"#00d4ff":"rgba(255,255,255,0.35)",
                fontFamily:"'Orbitron',monospace", fontSize:9, letterSpacing:2,
                transition:"all 0.18s", display:"flex", alignItems:"center", gap:5,
              }}>
                <span style={{fontSize:11}}>{t.icon}</span>{t.label}
                {t.id==="alerts" && allAlerts.length>0 && (
                  <span style={{background:"rgba(244,63,94,0.2)",color:"#f43f5e",border:"1px solid rgba(244,63,94,0.4)",borderRadius:4,padding:"1px 5px",fontSize:8}}>{allAlerts.length}</span>
                )}
              </button>
            ))}
          </div>

          {/* Header stats */}
          <div style={{marginLeft:"auto",display:"flex",gap:20,alignItems:"center"}}>
            {[
              {l:"CRITICAL",v:critCount,  c:"#f43f5e"},
              {l:"WATCH",   v:watchCount, c:"#f59e0b"},
              {l:"STABLE",  v:patients.length-critCount-watchCount, c:"#10b981"},
              {l:"ALERTS",  v:allAlerts.length, c:"#f43f5e"},
            ].map(s=>(
              <div key={s.l} style={{textAlign:"right"}}>
                <div style={{fontFamily:"'Orbitron',monospace",fontSize:16,fontWeight:700,color:s.c}}>{s.v}</div>
                <div style={{color:"rgba(255,255,255,0.2)",fontSize:7,fontFamily:"monospace",letterSpacing:2}}>{s.l}</div>
              </div>
            ))}
            <div style={{borderLeft:"1px solid rgba(255,255,255,0.08)",paddingLeft:16}}>
              <div style={{fontFamily:"'Orbitron',monospace",fontSize:12,color:"rgba(255,255,255,0.5)",letterSpacing:1}}>{time.toLocaleTimeString()}</div>
              <div style={{color:"rgba(255,255,255,0.2)",fontSize:7,fontFamily:"monospace",letterSpacing:1}}>SYSTEM TIME</div>
            </div>
            <div style={{display:"flex",alignItems:"center",gap:6,background:"rgba(16,185,129,0.06)",border:"1px solid rgba(16,185,129,0.2)",borderRadius:7,padding:"5px 10px"}}>
              <div style={{width:6,height:6,borderRadius:"50%",background:"#10b981",animation:"medPulse 2s infinite",boxShadow:"0 0 8px #10b981"}}/>
              <span style={{fontSize:8,color:"rgba(16,185,129,0.8)",fontFamily:"monospace",letterSpacing:1.5}}>ALL SYSTEMS NOMINAL</span>
            </div>
          </div>
        </div>

        {/* ── MAIN CONTENT ── */}
        <div style={{flex:1,display:"grid",gridTemplateColumns:"240px 1fr 260px",overflow:"hidden",position:"relative",zIndex:1}}>

          {/* ── LEFT: Patient Roster ── */}
          <div style={{borderRight:"1px solid rgba(0,212,255,0.08)",display:"flex",flexDirection:"column",overflow:"hidden",background:"rgba(2,11,24,0.6)"}}>
            <div style={{padding:"10px 12px 6px",flexShrink:0,borderBottom:"1px solid rgba(255,255,255,0.04)"}}>
              <div style={{fontFamily:"'Orbitron',monospace",fontSize:8,color:"rgba(255,255,255,0.2)",letterSpacing:3}}>PATIENT ROSTER · {patients.length} MONITORED</div>
            </div>
            <div style={{flex:1,overflowY:"auto",padding:"10px 10px",display:"flex",flexDirection:"column",gap:8}}>
              {patients.map(p=>(
                <PatientCard key={p.id} patient={p} selected={selectedId===p.id} onClick={()=>setSelectedId(p.id)}/>
              ))}
            </div>
          </div>

          {/* ── CENTER: Main View ── */}
          <div style={{display:"flex",flexDirection:"column",overflow:"hidden"}}>

            {/* Patient header */}
            {selected && (
              <div style={{flexShrink:0,padding:"12px 20px",borderBottom:"1px solid rgba(255,255,255,0.05)",background:`rgba(${hexToRgb(sevColor(selected.severity))},0.04)`,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                <div>
                  <div style={{display:"flex",alignItems:"center",gap:12,marginBottom:4}}>
                    <span style={{fontFamily:"'Exo 2',sans-serif",fontWeight:700,fontSize:18,color:"white"}}>{selected.name}</span>
                    <span style={{fontFamily:"'Orbitron',monospace",fontSize:11,color:sevColor(selected.severity),letterSpacing:2}}>ICU-{selected.id}</span>
                    <span style={{background:`rgba(${hexToRgb(sevColor(selected.severity))},0.12)`,border:`1px solid rgba(${hexToRgb(sevColor(selected.severity))},0.3)`,borderRadius:20,padding:"2px 10px",fontSize:8,color:sevColor(selected.severity),fontFamily:"monospace",letterSpacing:1,textTransform:"uppercase"}}>{selected.severity}</span>
                  </div>
                  <div style={{color:"rgba(255,255,255,0.35)",fontSize:11,fontFamily:"monospace"}}>
                    {selected.age} years old · {selected.condition} · GCS {selected.gcs}
                  </div>
                </div>
                <div style={{display:"flex",gap:12,alignItems:"center"}}>
                  {selected.alerts.length > 0 && (
                    <div style={{background:"rgba(244,63,94,0.08)",border:"1px solid rgba(244,63,94,0.25)",borderRadius:8,padding:"6px 14px",display:"flex",alignItems:"center",gap:6}}>
                      <div style={{width:6,height:6,borderRadius:"50%",background:"#f43f5e",animation:"medPulse 1s infinite"}}/>
                      <span style={{color:"#f43f5e",fontSize:9,fontFamily:"'Orbitron',monospace",letterSpacing:1}}>{selected.alerts.length} ACTIVE ALERT{selected.alerts.length>1?"S":""}</span>
                    </div>
                  )}
                  <div style={{display:"flex",gap:6}}>
                    {["trend","BP","SpO₂"].map(b=>(
                      <div key={b} style={{background:"rgba(0,212,255,0.06)",border:"1px solid rgba(0,212,255,0.15)",borderRadius:6,padding:"4px 10px",fontSize:9,color:"rgba(0,212,255,0.7)",fontFamily:"monospace",cursor:"pointer"}}>{b}</div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Tab content */}
            <div style={{flex:1,overflow:"hidden"}}>

              {/* VITALS TAB */}
              {activeTab==="vitals" && selected && (
                <div style={{height:"100%",display:"flex",flexDirection:"column",gap:0}}>
                  {/* ECG */}
                  <div style={{flexShrink:0,height:"38%",padding:"10px 16px",borderBottom:"1px solid rgba(255,255,255,0.04)",background:"rgba(2,11,24,0.7)"}}>
                    <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:6}}>
                      <span style={{fontFamily:"'Orbitron',monospace",fontSize:8,color:"rgba(0,212,255,0.5)",letterSpacing:2}}>ECG · LEAD II</span>
                      <div style={{display:"flex",gap:12}}>
                        <span style={{fontFamily:"'Orbitron',monospace",fontSize:10,color:"#00d4ff"}}>{selected.hr.toFixed(0)} <span style={{fontSize:8,opacity:0.5}}>BPM</span></span>
                        <span style={{fontFamily:"'Orbitron',monospace",fontSize:10,color:vitalColors[vitalStatus(selected.hr,'hr')]}}>{vitalStatus(selected.hr,'hr').toUpperCase()}</span>
                      </div>
                    </div>
                    <div style={{height:"calc(100% - 28px)"}}>
                      <ECGMonitor patient={selected} color="#00d4ff"/>
                    </div>
                  </div>

                  {/* Gauges + vitals */}
                  <div style={{flex:1,padding:"14px 16px",display:"flex",flexDirection:"column",gap:14,overflowY:"auto"}}>
                    <div style={{display:"flex",justifyContent:"space-around",alignItems:"center"}}>
                      <RadialGauge value={selected.hr}   min={40} max={200} label="HEART RATE" unit="bpm"  color={vitalColors[vitalStatus(selected.hr,'hr')]}/>
                      <RadialGauge value={selected.spo2} min={80} max={100} label="SpO₂"       unit="%"    color={vitalColors[vitalStatus(selected.spo2,'spo2')]}/>
                      <RadialGauge value={selected.sbp}  min={60} max={220} label="SYSTOLIC BP" unit="mmHg" color={vitalColors[vitalStatus(selected.sbp,'sbp')]}/>
                      <RadialGauge value={selected.rr}   min={6}  max={40}  label="RESP RATE"  unit="/min" color={vitalColors[vitalStatus(selected.rr,'rr')]}/>
                      <RadialGauge value={selected.etco2}min={20} max={60}  label="EtCO₂"      unit="mmHg" color="#a78bfa"/>
                    </div>
                    <VitalsDetail patient={selected}/>
                  </div>
                </div>
              )}

              {/* NEURO MAP TAB */}
              {activeTab==="neuro" && selected && (
                <div style={{height:"100%",display:"grid",gridTemplateColumns:"1fr 1fr",overflow:"hidden"}}>
                  <div style={{borderRight:"1px solid rgba(255,255,255,0.05)",padding:16,display:"flex",flexDirection:"column",gap:10}}>
                    <div style={{fontFamily:"'Orbitron',monospace",fontSize:8,color:"rgba(0,212,255,0.5)",letterSpacing:2}}>NEURAL ACTIVITY MAP · {selected.name.toUpperCase()}</div>
                    <div style={{flex:1}}>
                      <BrainActivityMap patient={selected}/>
                    </div>
                  </div>
                  <div style={{padding:16,display:"flex",flexDirection:"column",gap:12,overflowY:"auto"}}>
                    <div style={{fontFamily:"'Orbitron',monospace",fontSize:8,color:"rgba(0,212,255,0.5)",letterSpacing:2}}>NEURO ASSESSMENT</div>
                    {[
                      {l:"GLASGOW COMA SCALE",v:`${selected.gcs}/15`,  c:selected.gcs<9?"#f43f5e":selected.gcs<13?"#f59e0b":"#10b981"},
                      {l:"PUPILLARY RESPONSE",v:"Reactive bilateral",   c:"#10b981"},
                      {l:"MOTOR RESPONSE",    v:selected.severity==="critical"?"Abnormal flexion":"Obeys commands", c:selected.severity==="critical"?"#f43f5e":"#10b981"},
                      {l:"ICP ESTIMATE",      v:selected.severity==="critical"?"22 mmHg ⚠":"12 mmHg", c:selected.severity==="critical"?"#f43f5e":"#10b981"},
                      {l:"CEREBRAL PERFUSION",v:selected.severity==="critical"?"68 mmHg":"82 mmHg",   c:selected.severity==="critical"?"#f59e0b":"#10b981"},
                      {l:"EEG PATTERN",       v:selected.severity==="critical"?"Burst suppression":"Normal cortical", c:selected.severity==="critical"?"#f43f5e":"#10b981"},
                    ].map(n=>(
                      <div key={n.l} style={{background:"rgba(5,10,24,0.8)",border:"1px solid rgba(255,255,255,0.05)",borderRadius:9,padding:"10px 14px",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                        <span style={{color:"rgba(255,255,255,0.35)",fontSize:10,fontFamily:"monospace",letterSpacing:1}}>{n.l}</span>
                        <span style={{fontFamily:"'Orbitron',monospace",fontSize:11,color:n.c,fontWeight:700}}>{n.v}</span>
                      </div>
                    ))}
                    {selected.severity==="critical" && (
                      <div style={{background:"rgba(244,63,94,0.07)",border:"1px solid rgba(244,63,94,0.2)",borderRadius:10,padding:"12px 14px",animation:"alertPulse 2s infinite"}}>
                        <div style={{color:"#f43f5e",fontSize:9,fontFamily:"'Orbitron',monospace",letterSpacing:2,marginBottom:6}}>▲ AEGIS ALERT</div>
                        <div style={{color:"rgba(255,255,255,0.5)",fontSize:11,lineHeight:1.6}}>Elevated ICP detected. Recommending immediate neurosurgical consultation. Head of bed at 30°. Osmotherapy protocol initiated.</div>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* AI AGENTS TAB */}
              {activeTab==="agents" && (
                <div style={{padding:"18px 20px",overflowY:"auto",height:"100%",display:"flex",flexDirection:"column",gap:16}}>
                  <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:14}}>
                    {AI_AGENTS.map(a=><AgentStatusCard key={a.id} agent={a} activeCount={patients.length}/>)}
                  </div>
                  {/* Emergency log */}
                  <div style={{background:"rgba(5,10,24,0.85)",border:"1px solid rgba(255,255,255,0.07)",borderRadius:14,padding:18}}>
                    <div style={{fontFamily:"'Orbitron',monospace",fontSize:8,color:"rgba(255,255,255,0.2)",letterSpacing:3,marginBottom:14,display:"flex",alignItems:"center",gap:6}}>
                      <div style={{width:5,height:5,borderRadius:"50%",background:"#f43f5e",animation:"medPulse 1.2s infinite"}}/>
                      AGENT ACTIVITY LOG
                    </div>
                    {emergencyLog.length===0 && <div style={{color:"rgba(255,255,255,0.2)",fontSize:10,fontFamily:"monospace",textAlign:"center",padding:"10px 0"}}>No recent agent activity</div>}
                    {emergencyLog.map(e=>(
                      <div key={e.id} className="fadein" style={{display:"flex",gap:12,alignItems:"flex-start",padding:"7px 0",borderBottom:"1px solid rgba(255,255,255,0.04)"}}>
                        <span style={{color:"rgba(0,212,255,0.4)",fontSize:9,fontFamily:"monospace",flexShrink:0,marginTop:2}}>{e.time}</span>
                        <span style={{color:"rgba(255,255,255,0.55)",fontSize:11,lineHeight:1.5}}>{e.msg}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* ALERTS TAB */}
              {activeTab==="alerts" && (
                <div style={{padding:"18px 20px",overflowY:"auto",height:"100%",display:"flex",flexDirection:"column",gap:14}}>
                  <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:12}}>
                    {[
                      {l:"CRITICAL ALERTS",v:allAlerts.filter(a=>a.sev==='crit').length, c:"#f43f5e"},
                      {l:"WARNINGS",       v:allAlerts.filter(a=>a.sev==='warn').length, c:"#f59e0b"},
                      {l:"PATIENTS AT RISK",v:patients.filter(p=>p.alerts.length>0).length,c:"#f43f5e"},
                      {l:"AI INTERVENTIONS",v:emergencyLog.length,c:"#00d4ff"},
                    ].map(s=>(
                      <div key={s.l} style={{background:"rgba(5,10,24,0.85)",border:`1px solid rgba(${hexToRgb(s.c)},0.2)`,borderRadius:12,padding:"14px 16px",textAlign:"center"}}>
                        <div style={{fontFamily:"'Orbitron',monospace",fontSize:22,fontWeight:700,color:s.c,marginBottom:4}}>{s.v}</div>
                        <div style={{color:"rgba(255,255,255,0.25)",fontSize:8,fontFamily:"monospace",letterSpacing:1.5}}>{s.l}</div>
                      </div>
                    ))}
                  </div>
                  <div style={{background:"rgba(5,10,24,0.85)",border:"1px solid rgba(255,255,255,0.07)",borderRadius:14,padding:18,flex:1}}>
                    <div style={{fontFamily:"'Orbitron',monospace",fontSize:8,color:"rgba(255,255,255,0.2)",letterSpacing:3,marginBottom:14}}>ACTIVE ALERTS — ALL PATIENTS</div>
                    <AlertFeed patients={patients}/>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* ── RIGHT: AI Feed + Alerts ── */}
          <div style={{borderLeft:"1px solid rgba(0,212,255,0.08)",display:"flex",flexDirection:"column",overflow:"hidden",background:"rgba(2,11,24,0.5)"}}>
            {/* AEGIS emergency agent */}
            <div style={{flexShrink:0,padding:"12px 14px",borderBottom:"1px solid rgba(244,63,94,0.1)",background:"rgba(244,63,94,0.04)"}}>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:8}}>
                <div style={{display:"flex",gap:8,alignItems:"center"}}>
                  <span style={{fontSize:14,color:"#f43f5e"}}>▲</span>
                  <div>
                    <div style={{fontFamily:"'Orbitron',monospace",fontSize:11,color:"#f43f5e",letterSpacing:2,fontWeight:900}}>AEGIS</div>
                    <div style={{color:"rgba(255,255,255,0.25)",fontSize:8,fontFamily:"monospace"}}>Emergency Response</div>
                  </div>
                </div>
                <div style={{display:"flex",alignItems:"center",gap:5,background:"rgba(244,63,94,0.08)",border:"1px solid rgba(244,63,94,0.2)",borderRadius:20,padding:"3px 8px"}}>
                  <div style={{width:5,height:5,borderRadius:"50%",background:"#f43f5e",animation:"medPulse 1s infinite"}}/>
                  <span style={{fontSize:7,color:"#f43f5e",fontFamily:"monospace",letterSpacing:1}}>ARMED</span>
                </div>
              </div>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:6}}>
                {[
                  {l:"RRT AVAILABLE",v:"3 TEAMS",c:"#10b981"},
                  {l:"OR STATUS",    v:"1 OPEN",  c:"#10b981"},
                  {l:"ICU BEDS",     v:"2 FREE",  c:"#f59e0b"},
                  {l:"BLOOD BANK",   v:"STOCKED", c:"#10b981"},
                ].map(s=>(
                  <div key={s.l} style={{background:"rgba(0,0,0,0.3)",borderRadius:7,padding:"6px 8px"}}>
                    <div style={{color:"rgba(255,255,255,0.25)",fontSize:7,fontFamily:"monospace",letterSpacing:1,marginBottom:2}}>{s.l}</div>
                    <div style={{fontFamily:"'Orbitron',monospace",fontSize:10,color:s.c,fontWeight:700}}>{s.v}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Alert feed */}
            <div style={{flexShrink:0,padding:"10px 12px",borderBottom:"1px solid rgba(255,255,255,0.05)"}}>
              <div style={{fontFamily:"'Orbitron',monospace",fontSize:7,color:"rgba(255,255,255,0.2)",letterSpacing:3,marginBottom:10}}>LIVE ALERTS</div>
              <AlertFeed patients={patients}/>
            </div>

            {/* AI Intelligence feed */}
            <div style={{flex:1,overflow:"hidden",display:"flex",flexDirection:"column"}}>
              <div style={{padding:"8px 12px 6px",flexShrink:0,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                <div style={{fontFamily:"'Orbitron',monospace",fontSize:7,color:"rgba(255,255,255,0.2)",letterSpacing:3}}>AI INTELLIGENCE FEED</div>
                <div style={{display:"flex",alignItems:"center",gap:4}}>
                  <div style={{width:4,height:4,borderRadius:"50%",background:"#10b981",animation:"medPulse 1.5s infinite"}}/>
                  <span style={{fontSize:7,color:"rgba(16,185,129,0.6)",fontFamily:"monospace"}}>LIVE</span>
                </div>
              </div>
              <div style={{flex:1,overflowY:"auto",padding:"0 10px 10px",display:"flex",flexDirection:"column",gap:6}}>
                {emergencyLog.length===0 && (
                  <div style={{textAlign:"center",color:"rgba(255,255,255,0.15)",fontSize:10,fontFamily:"monospace",marginTop:20}}>Monitoring all patients...</div>
                )}
                {emergencyLog.map(e=>(
                  <div key={e.id} className="fadein" style={{background:"rgba(5,10,24,0.8)",border:"1px solid rgba(0,212,255,0.1)",borderRadius:8,padding:"9px 11px",borderLeft:"2px solid #00d4ff"}}>
                    <div style={{color:"rgba(0,212,255,0.5)",fontSize:8,fontFamily:"monospace",marginBottom:4}}>{e.time}</div>
                    <div style={{color:"rgba(255,255,255,0.6)",fontSize:10,lineHeight:1.5}}>{e.msg}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Bottom: quick stats */}
            <div style={{flexShrink:0,padding:"10px 12px",borderTop:"1px solid rgba(255,255,255,0.05)",background:"rgba(2,11,24,0.8)"}}>
              <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:6}}>
                {[
                  {l:"UPTIME",    v:"99.98%", c:"#10b981"},
                  {l:"LATENCY",  v:"12ms",   c:"#00d4ff"},
                  {l:"AI LOAD",  v:"42%",    c:"#a78bfa"},
                ].map(s=>(
                  <div key={s.l} style={{textAlign:"center",background:"rgba(0,0,0,0.3)",borderRadius:7,padding:"7px"}}>
                    <div style={{fontFamily:"'Orbitron',monospace",fontSize:12,color:s.c,fontWeight:700}}>{s.v}</div>
                    <div style={{color:"rgba(255,255,255,0.2)",fontSize:7,fontFamily:"monospace",letterSpacing:1,marginTop:2}}>{s.l}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        <style>{`@keyframes ticker{0%{transform:translateX(0)}100%{transform:translateX(-50%)}}`}</style>
      </div>
    </>
  );
}
