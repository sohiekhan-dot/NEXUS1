import { useState, useEffect, useRef } from "react";

// ─── REAL 2026 PRICES ─────────────────────────────────────────────────────────
const ASSETS = [
  { sym:"BTC",  name:"Bitcoin",     price:78244, vol:0.62, color:"#F7931A", cat:"Crypto"   },
  { sym:"ETH",  name:"Ethereum",    price:2295,  vol:0.71, color:"#627EEA", cat:"Crypto"   },
  { sym:"SOL",  name:"Solana",      price:83.74, vol:0.88, color:"#9945FF", cat:"Crypto"   },
  { sym:"XRP",  name:"XRP",         price:1.39,  vol:0.82, color:"#00AAE4", cat:"Crypto"   },
  { sym:"TAO",  name:"Bittensor",   price:312,   vol:1.15, color:"#7FBA00", cat:"AI"       },
  { sym:"ONDO", name:"Ondo",        price:0.89,  vol:0.95, color:"#00C2FF", cat:"RWA"      },
  { sym:"SPY",  name:"S&P 500",     price:542,   vol:0.16, color:"#10B981", cat:"Equities" },
  { sym:"GOLD", name:"Gold",        price:3245,  vol:0.13, color:"#F59E0B", cat:"Commodity"},
];

// Simple GBM price engine
class PriceEngine {
  constructor(a) {
    this.a = a;
    this.price = a.price;
    this.sigma = a.vol / Math.sqrt(252 * 390);
    this.history = Array.from({length:80}, (_,i) => {
      return a.price * (1 + (Math.random()-0.5) * a.vol * 0.08 * (i/80));
    });
  }
  tick() {
    const z = this._rn();
    this.price = Math.max(this.price * Math.exp(this.sigma * z), 0.001);
    this.history.push(this.price);
    if (this.history.length > 80) this.history.shift();
  }
  _rn() {
    let u=0,v=0;
    while(!u) u=Math.random(); while(!v) v=Math.random();
    return Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*v);
  }
  get change() {
    const p = this.history[this.history.length-2]||this.price;
    return (this.price-p)/p*100;
  }
  get change24h() {
    const p = this.history[0]||this.price;
    return (this.price-p)/p*100;
  }
}

const ENGINES = {};
ASSETS.forEach(a => { ENGINES[a.sym] = new PriceEngine(a); });

// Format helpers
const fmt = (p) => {
  if (p >= 10000) return "$" + p.toLocaleString("en",{maximumFractionDigits:0});
  if (p >= 100)   return "$" + p.toFixed(2);
  if (p >= 1)     return "$" + p.toFixed(3);
  return "$" + p.toFixed(4);
};
const fmtPct = (v) => (v>=0?"+":"")+v.toFixed(2)+"%";
const hexRgb = h => { const r=/^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(h); return r?`${parseInt(r[1],16)},${parseInt(r[2],16)},${parseInt(r[3],16)}`:"255,255,255"; };

// Sparkline component
function Spark({ data, color, up }) {
  const mn=Math.min(...data), mx=Math.max(...data), rng=mx-mn||1;
  const pts = data.slice(-30).map((v,i,a)=>`${(i/(a.length-1))*80},${26-((v-mn)/rng)*22-2}`).join(" ");
  const fill = `0,28 ${pts} 80,28`;
  return (
    <svg width="80" height="28" style={{flexShrink:0}}>
      <polygon points={fill} fill={`rgba(${hexRgb(color)},0.15)`}/>
      <polyline points={pts} fill="none" stroke={color} strokeWidth="1.8"
        style={{filter:`drop-shadow(0 0 3px ${color})`}}/>
    </svg>
  );
}

// Mini chart on canvas
function MiniChart({ symKey, height=200 }) {
  const ref = useRef(null);
  const [t, setT] = useState(0);
  useEffect(()=>{ const iv=setInterval(()=>setT(x=>x+1),600); return()=>clearInterval(iv); },[]);

  useEffect(()=>{
    const c = ref.current; if(!c) return;
    const dpr = window.devicePixelRatio||1;
    const W=c.offsetWidth, H=c.offsetHeight;
    c.width=W*dpr; c.height=H*dpr;
    const ctx=c.getContext("2d"); ctx.scale(dpr,dpr);
    const eng = ENGINES[symKey]; if(!eng) return;
    const hist = eng.history;
    const mn=Math.min(...hist)*0.999, mx=Math.max(...hist)*1.001, rng=mx-mn||1;
    const toX=i=>(i/(hist.length-1))*(W-4)+2;
    const toY=v=>H-4-((v-mn)/rng)*(H-8);
    const up = hist[hist.length-1]>=hist[0];
    const lc = up?"#00C97A":"#F43F5E";

    ctx.clearRect(0,0,W,H);

    // Grid
    [0,0.25,0.5,0.75,1].forEach(f=>{
      const y=4+(1-f)*(H-8);
      ctx.strokeStyle="rgba(255,255,255,0.04)"; ctx.lineWidth=1;
      ctx.beginPath(); ctx.moveTo(0,y); ctx.lineTo(W,y); ctx.stroke();
      const pv = mn+f*rng;
      ctx.fillStyle="rgba(255,255,255,0.25)"; ctx.font=`9px monospace`;
      ctx.fillText(fmt(pv).replace("$",""), W-44, y-2);
    });

    // Fill
    ctx.beginPath();
    hist.forEach((p,i)=>{ const x=toX(i),y=toY(p); i===0?ctx.moveTo(x,y):ctx.lineTo(x,y); });
    ctx.lineTo(toX(hist.length-1),H); ctx.lineTo(toX(0),H); ctx.closePath();
    const g=ctx.createLinearGradient(0,0,0,H);
    g.addColorStop(0,`rgba(${hexRgb(lc)},0.18)`); g.addColorStop(1,"rgba(0,0,0,0)");
    ctx.fillStyle=g; ctx.fill();

    // Line
    ctx.beginPath();
    hist.forEach((p,i)=>{ const x=toX(i),y=toY(p); i===0?ctx.moveTo(x,y):ctx.lineTo(x,y); });
    ctx.strokeStyle=lc; ctx.lineWidth=2; ctx.shadowColor=lc; ctx.shadowBlur=6; ctx.stroke(); ctx.shadowBlur=0;

    // Last dot
    const lx=toX(hist.length-1), ly=toY(hist[hist.length-1]);
    ctx.beginPath(); ctx.arc(lx,ly,4,0,Math.PI*2);
    ctx.fillStyle=lc; ctx.shadowColor=lc; ctx.shadowBlur=12; ctx.fill(); ctx.shadowBlur=0;
  },[t, symKey]);

  return <canvas ref={ref} style={{width:"100%",height,display:"block"}}/>;
}

// Order panel
function OrderPanel({ asset, onClose }) {
  const [side, setSide] = useState("BUY");
  const [type, setType] = useState("MARKET");
  const [qty, setQty] = useState("");
  const [price, setPrice] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const eng = ENGINES[asset.sym];

  const total = parseFloat(qty||0) * (type==="LIMIT" ? parseFloat(price||eng.price) : eng.price);

  function submit() {
    if (!qty || parseFloat(qty)<=0) return;
    setSubmitted(true);
    setTimeout(()=>{ setSubmitted(false); setQty(""); setPrice(""); onClose(); }, 1800);
  }

  const isBuy = side==="BUY";
  const ac = isBuy ? "#00C97A" : "#F43F5E";

  return (
    <div style={{
      background:"rgba(8,14,30,0.98)", border:`1px solid rgba(${hexRgb(ac)},0.3)`,
      borderRadius:16, padding:24, width:320,
    }}>
      {/* Header */}
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:20}}>
        <div>
          <div style={{fontFamily:"'Orbitron',monospace",fontWeight:700,fontSize:16,color:"white",letterSpacing:2}}>{asset.sym}</div>
          <div style={{color:"rgba(255,255,255,0.4)",fontSize:11,marginTop:2}}>{asset.name}</div>
        </div>
        <button onClick={onClose} style={{background:"rgba(255,255,255,0.06)",border:"1px solid rgba(255,255,255,0.1)",borderRadius:8,width:30,height:30,cursor:"pointer",color:"rgba(255,255,255,0.5)",fontSize:16}}>×</button>
      </div>

      {/* Current price */}
      <div style={{background:"rgba(255,255,255,0.04)",borderRadius:10,padding:"10px 14px",marginBottom:18,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
        <span style={{color:"rgba(255,255,255,0.4)",fontSize:11,fontFamily:"monospace"}}>MARKET PRICE</span>
        <div style={{textAlign:"right"}}>
          <div style={{fontFamily:"'Orbitron',monospace",fontSize:16,fontWeight:700,color:"white"}}>{fmt(eng.price)}</div>
          <div style={{fontSize:10,color:eng.change24h>=0?"#00C97A":"#F43F5E",fontFamily:"monospace"}}>{fmtPct(eng.change24h)}</div>
        </div>
      </div>

      {/* Buy / Sell toggle */}
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:6,marginBottom:16}}>
        {["BUY","SELL"].map(s=>(
          <button key={s} onClick={()=>setSide(s)} style={{
            background: side===s ? (s==="BUY"?"rgba(0,201,122,0.15)":"rgba(244,63,94,0.15)") : "rgba(255,255,255,0.04)",
            border:`1px solid ${side===s?(s==="BUY"?"rgba(0,201,122,0.5)":"rgba(244,63,94,0.5)"):"rgba(255,255,255,0.08)"}`,
            borderRadius:8, padding:"10px", cursor:"pointer",
            color: side===s?(s==="BUY"?"#00C97A":"#F43F5E"):"rgba(255,255,255,0.35)",
            fontFamily:"'Orbitron',monospace", fontSize:12, fontWeight:700, letterSpacing:2,
            transition:"all 0.15s",
          }}>{s}</button>
        ))}
      </div>

      {/* Market / Limit */}
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:6,marginBottom:16}}>
        {["MARKET","LIMIT"].map(t2=>(
          <button key={t2} onClick={()=>setType(t2)} style={{
            background: type===t2?"rgba(255,255,255,0.08)":"rgba(255,255,255,0.03)",
            border:`1px solid ${type===t2?"rgba(255,255,255,0.2)":"rgba(255,255,255,0.06)"}`,
            borderRadius:7, padding:"7px", cursor:"pointer",
            color: type===t2?"white":"rgba(255,255,255,0.3)",
            fontFamily:"monospace", fontSize:10, letterSpacing:1, transition:"all 0.15s",
          }}>{t2}</button>
        ))}
      </div>

      {/* Inputs */}
      <div style={{display:"flex",flexDirection:"column",gap:10,marginBottom:16}}>
        {type==="LIMIT" && (
          <div>
            <div style={{color:"rgba(255,255,255,0.35)",fontSize:9,fontFamily:"monospace",letterSpacing:2,marginBottom:5}}>LIMIT PRICE</div>
            <input type="number" value={price} onChange={e=>setPrice(e.target.value)}
              placeholder={eng.price.toFixed(2)}
              style={{width:"100%",background:"rgba(255,255,255,0.05)",border:"1px solid rgba(255,255,255,0.12)",borderRadius:8,padding:"10px 12px",color:"white",fontFamily:"monospace",fontSize:13,outline:"none"}}/>
          </div>
        )}
        <div>
          <div style={{display:"flex",justifyContent:"space-between",marginBottom:5}}>
            <span style={{color:"rgba(255,255,255,0.35)",fontSize:9,fontFamily:"monospace",letterSpacing:2}}>QUANTITY</span>
            <span style={{color:"rgba(255,255,255,0.25)",fontSize:9,fontFamily:"monospace"}}>{asset.sym}</span>
          </div>
          <input type="number" value={qty} onChange={e=>setQty(e.target.value)}
            placeholder="0.00"
            style={{width:"100%",background:"rgba(255,255,255,0.05)",border:`1px solid rgba(${hexRgb(ac)},0.25)`,borderRadius:8,padding:"10px 12px",color:"white",fontFamily:"'Orbitron',monospace",fontSize:16,fontWeight:700,outline:"none"}}/>
        </div>

        {/* Quick qty buttons */}
        <div style={{display:"flex",gap:5}}>
          {["25%","50%","75%","MAX"].map(p=>(
            <button key={p} onClick={()=>{
              const maxQty = 10000 / eng.price;
              const mult = p==="MAX"?1:parseFloat(p)/100;
              setQty((maxQty*mult).toFixed(4));
            }} style={{flex:1,background:"rgba(255,255,255,0.04)",border:"1px solid rgba(255,255,255,0.08)",borderRadius:6,padding:"5px 0",cursor:"pointer",color:"rgba(255,255,255,0.35)",fontSize:9,fontFamily:"monospace",transition:"all 0.15s"}}>{p}</button>
          ))}
        </div>
      </div>

      {/* Order total */}
      {total > 0 && (
        <div style={{background:"rgba(255,255,255,0.04)",borderRadius:8,padding:"10px 12px",marginBottom:14,display:"flex",justifyContent:"space-between"}}>
          <span style={{color:"rgba(255,255,255,0.35)",fontSize:11,fontFamily:"monospace"}}>TOTAL</span>
          <span style={{fontFamily:"'Orbitron',monospace",fontSize:13,color:"white",fontWeight:600}}>${total.toLocaleString("en",{maximumFractionDigits:2})}</span>
        </div>
      )}

      {/* Submit */}
      <button onClick={submit} disabled={!qty||parseFloat(qty)<=0} style={{
        width:"100%",
        background: submitted ? "rgba(0,201,122,0.2)" : `linear-gradient(135deg,${isBuy?"#00C97A,#008844":"#F43F5E,#BE123C"})`,
        border:"none", borderRadius:10, padding:"14px",
        cursor: !qty||parseFloat(qty)<=0 ? "not-allowed":"pointer",
        color: submitted ? "#00C97A" : "#fff",
        fontFamily:"'Orbitron',monospace", fontWeight:900, fontSize:12, letterSpacing:3,
        opacity: !qty||parseFloat(qty)<=0 ? 0.4 : 1,
        transition:"all 0.2s",
        display:"flex", alignItems:"center", justifyContent:"center", gap:8,
      }}>
        {submitted ? <>
          <span style={{width:14,height:14,border:"2px solid #00C97A",borderTopColor:"transparent",borderRadius:"50%",display:"inline-block",animation:"spin 0.6s linear infinite"}}/>
          EXECUTING...
        </> : `${side} ${asset.sym}`}
      </button>
    </div>
  );
}

// ─── MAIN APP ─────────────────────────────────────────────────────────────────
export default function SimpleTrader() {
  const [tick, setTick]           = useState(0);
  const [selected, setSelected]   = useState("BTC");
  const [orderAsset, setOrderAsset] = useState(null);
  const [tab, setTab]             = useState("markets"); // markets | portfolio | withdraw
  const [wAmount, setWAmount]     = useState("");
  const [wAddress, setWAddress]   = useState("");
  const [wStep, setWStep]         = useState(1);
  const [portfolio] = useState([
    { sym:"BTC", qty:0.42,  avgPrice:71200 },
    { sym:"ETH", qty:4.8,   avgPrice:2180  },
    { sym:"SOL", qty:24,    avgPrice:72    },
  ]);

  // Drive engines
  useEffect(()=>{
    const iv=setInterval(()=>{ Object.values(ENGINES).forEach(e=>e.tick()); setTick(t=>t+1); },700);
    return()=>clearInterval(iv);
  },[]);

  const selEng = ENGINES[selected];
  const totalPortfolio = portfolio.reduce((s,p)=>{
    const e=ENGINES[p.sym]; return s+(e?e.price*p.qty:0);
  },0);
  const totalCost = portfolio.reduce((s,p)=>s+p.qty*p.avgPrice,0);
  const totalPnl = totalPortfolio - totalCost;

  const TABS = [{id:"markets",label:"Markets",icon:"📈"},{id:"portfolio",label:"Portfolio",icon:"💼"},{id:"withdraw",label:"Withdraw",icon:"↗"}];

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@600;700;900&family=Inter:wght@400;500;600&display=swap');
        *{box-sizing:border-box;margin:0;padding:0;}
        html,body{height:100%;background:#0D1117;}
        ::-webkit-scrollbar{width:4px;} ::-webkit-scrollbar-thumb{background:rgba(255,255,255,0.1);border-radius:2px;}
        @keyframes spin{to{transform:rotate(360deg)}}
        @keyframes fadeIn{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}
        @keyframes blink{0%,100%{opacity:1}50%{opacity:0.4}}
        .card{animation:fadeIn 0.3s ease both;}
        input::placeholder{color:rgba(255,255,255,0.2);}
        input[type=number]{-moz-appearance:textfield;}
        input::-webkit-outer-spin-button,input::-webkit-inner-spin-button{-webkit-appearance:none;}
        button:hover{filter:brightness(1.1);}
      `}</style>

      <div style={{
        minHeight:"100vh", background:"#0D1117",
        color:"white", fontFamily:"'Inter',sans-serif",
        display:"flex", flexDirection:"column",
      }}>

        {/* ── TOP BAR ── */}
        <div style={{background:"#161B22",borderBottom:"1px solid rgba(255,255,255,0.08)",padding:"0 20px",height:56,display:"flex",alignItems:"center",justifyContent:"space-between",flexShrink:0}}>
          <div style={{display:"flex",alignItems:"center",gap:10}}>
            <div style={{width:30,height:30,background:"linear-gradient(135deg,#00C97A,#00664A)",borderRadius:8,display:"flex",alignItems:"center",justifyContent:"center",fontSize:16,boxShadow:"0 0 16px rgba(0,201,122,0.35)"}}>◈</div>
            <div>
              <div style={{fontFamily:"'Orbitron',monospace",fontWeight:700,fontSize:13,color:"#00C97A",letterSpacing:3}}>NEXUS</div>
              <div style={{fontSize:8,color:"rgba(255,255,255,0.25)",letterSpacing:2,fontFamily:"monospace"}}>TRADER · 2026</div>
            </div>
          </div>

          {/* Tab bar */}
          <div style={{display:"flex",gap:2,background:"rgba(255,255,255,0.04)",borderRadius:10,padding:3}}>
            {TABS.map(t=>(
              <button key={t.id} onClick={()=>setTab(t.id)} style={{
                background:tab===t.id?"rgba(255,255,255,0.1)":"transparent",
                border:`1px solid ${tab===t.id?"rgba(255,255,255,0.15)":"transparent"}`,
                borderRadius:8, padding:"6px 16px", cursor:"pointer",
                color:tab===t.id?"white":"rgba(255,255,255,0.4)",
                fontSize:13, fontWeight:tab===t.id?600:400,
                transition:"all 0.15s", display:"flex", alignItems:"center", gap:6,
              }}>
                <span>{t.icon}</span>{t.label}
              </button>
            ))}
          </div>

          {/* Balance */}
          <div style={{textAlign:"right"}}>
            <div style={{fontFamily:"'Orbitron',monospace",fontSize:15,fontWeight:700,color:"#00C97A"}}>${totalPortfolio.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g,",")}</div>
            <div style={{fontSize:11,color:totalPnl>=0?"#00C97A":"#F43F5E",fontFamily:"monospace"}}>{totalPnl>=0?"+":""}{fmtPct((totalPnl/totalCost)*100)} total P&L</div>
          </div>
        </div>

        {/* ── CONTENT ── */}
        <div style={{flex:1,display:"flex",overflow:"hidden",position:"relative"}}>

          {/* ─ MARKETS TAB ─ */}
          {tab==="markets" && (
            <div style={{display:"grid",gridTemplateColumns:"1fr 380px",width:"100%",overflow:"hidden"}}>

              {/* Asset list */}
              <div style={{overflowY:"auto",padding:"16px"}}>
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:14}}>
                  <h2 style={{fontSize:16,fontWeight:600,color:"white"}}>Markets</h2>
                  <div style={{display:"flex",alignItems:"center",gap:6,background:"rgba(0,201,122,0.08)",border:"1px solid rgba(0,201,122,0.2)",borderRadius:20,padding:"4px 10px"}}>
                    <div style={{width:6,height:6,borderRadius:"50%",background:"#00C97A",animation:"blink 1.5s infinite"}}/>
                    <span style={{fontSize:10,color:"#00C97A",fontFamily:"monospace"}}>LIVE</span>
                  </div>
                </div>

                {/* Stats strip */}
                <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:10,marginBottom:16}}>
                  {[
                    {l:"Fear & Greed",v:"26 — FEAR", c:"#F59E0B"},
                    {l:"BTC Dominance",v:"58.5%",    c:"#F7931A"},
                    {l:"Market Cap",  v:"$2.68T",    c:"#00C97A"},
                    {l:"ETF Inflows", v:"$630M/day", c:"#627EEA"},
                  ].map(s=>(
                    <div key={s.l} style={{background:"#161B22",border:"1px solid rgba(255,255,255,0.07)",borderRadius:10,padding:"10px 12px"}}>
                      <div style={{color:"rgba(255,255,255,0.35)",fontSize:10,marginBottom:4}}>{s.l}</div>
                      <div style={{fontFamily:"'Orbitron',monospace",fontSize:13,fontWeight:700,color:s.c}}>{s.v}</div>
                    </div>
                  ))}
                </div>

                {/* Asset cards */}
                <div style={{display:"flex",flexDirection:"column",gap:8}}>
                  {ASSETS.map(a => {
                    const e = ENGINES[a.sym];
                    const chg = e.change24h;
                    const up = chg>=0;
                    const isSelected = selected===a.sym;
                    return (
                      <div key={a.sym} className="card" onClick={()=>setSelected(a.sym)} style={{
                        background: isSelected ? `rgba(${hexRgb(a.color)},0.08)` : "#161B22",
                        border:`1px solid ${isSelected?`rgba(${hexRgb(a.color)},0.35)`:"rgba(255,255,255,0.07)"}`,
                        borderRadius:12, padding:"14px 16px", cursor:"pointer",
                        transition:"all 0.15s", display:"flex", alignItems:"center", gap:14,
                      }}>
                        {/* Icon */}
                        <div style={{width:40,height:40,borderRadius:10,background:`rgba(${hexRgb(a.color)},0.12)`,border:`1px solid rgba(${hexRgb(a.color)},0.25)`,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>
                          <span style={{fontFamily:"'Orbitron',monospace",fontSize:10,fontWeight:700,color:a.color}}>{a.sym.slice(0,3)}</span>
                        </div>

                        {/* Name + cat */}
                        <div style={{flex:1,minWidth:0}}>
                          <div style={{fontWeight:600,fontSize:14,color:"white"}}>{a.name}</div>
                          <div style={{display:"flex",alignItems:"center",gap:6,marginTop:2}}>
                            <span style={{background:`rgba(${hexRgb(a.color)},0.1)`,color:a.color,fontSize:9,fontFamily:"monospace",padding:"1px 6px",borderRadius:4}}>{a.cat}</span>
                          </div>
                        </div>

                        {/* Sparkline */}
                        <Spark data={e.history} color={up?"#00C97A":"#F43F5E"} up={up}/>

                        {/* Price + change */}
                        <div style={{textAlign:"right",minWidth:90}}>
                          <div style={{fontFamily:"'Orbitron',monospace",fontSize:14,fontWeight:700,color:"white"}}>{fmt(e.price)}</div>
                          <div style={{fontSize:12,color:up?"#00C97A":"#F43F5E",fontFamily:"monospace",marginTop:2,fontWeight:600}}>{fmtPct(chg)}</div>
                        </div>

                        {/* Trade button */}
                        <button onClick={ev=>{ev.stopPropagation();setOrderAsset(a);}} style={{
                          background:`rgba(${hexRgb(a.color)},0.1)`,
                          border:`1px solid rgba(${hexRgb(a.color)},0.3)`,
                          borderRadius:8, padding:"8px 14px", cursor:"pointer",
                          color:a.color, fontWeight:600, fontSize:12,
                          whiteSpace:"nowrap", transition:"all 0.15s", flexShrink:0,
                        }}>Trade →</button>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Chart + order panel */}
              <div style={{borderLeft:"1px solid rgba(255,255,255,0.07)",display:"flex",flexDirection:"column",background:"#0D1117",overflow:"hidden"}}>
                {/* Chart */}
                <div style={{flex:1,padding:"14px 14px 8px",borderBottom:"1px solid rgba(255,255,255,0.06)",display:"flex",flexDirection:"column"}}>
                  <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:10}}>
                    <div style={{display:"flex",alignItems:"center",gap:10}}>
                      <div style={{width:8,height:8,borderRadius:"50%",background:ASSETS.find(a=>a.sym===selected)?.color,boxShadow:`0 0 8px ${ASSETS.find(a=>a.sym===selected)?.color}`}}/>
                      <span style={{fontFamily:"'Orbitron',monospace",fontWeight:700,fontSize:14,color:"white",letterSpacing:2}}>{selected}</span>
                      <span style={{fontFamily:"'Orbitron',monospace",fontSize:18,fontWeight:700,color:selEng.change24h>=0?"#00C97A":"#F43F5E"}}>{fmt(selEng.price)}</span>
                      <span style={{fontSize:12,color:selEng.change24h>=0?"#00C97A":"#F43F5E",fontFamily:"monospace"}}>{fmtPct(selEng.change24h)}</span>
                    </div>
                  </div>
                  <div style={{flex:1}}>
                    <MiniChart key={selected} symKey={selected} height="100%"/>
                  </div>
                </div>

                {/* Quick order */}
                <div style={{padding:"14px",flexShrink:0}}>
                  <OrderPanel asset={ASSETS.find(a=>a.sym===selected)} onClose={()=>{}}/>
                </div>
              </div>
            </div>
          )}

          {/* ─ PORTFOLIO TAB ─ */}
          {tab==="portfolio" && (
            <div style={{flex:1,padding:"20px",overflowY:"auto"}}>
              <h2 style={{fontSize:16,fontWeight:600,marginBottom:6}}>Portfolio</h2>
              <div style={{color:"rgba(255,255,255,0.4)",fontSize:13,marginBottom:20}}>Live positions based on current market prices</div>

              {/* Summary cards */}
              <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:12,marginBottom:20}}>
                {[
                  {l:"Total Value",   v:`$${totalPortfolio.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g,",")}`, c:"#00C97A"},
                  {l:"Total P&L",     v:`${totalPnl>=0?"+":""}$${Math.abs(totalPnl).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g,",")}`, c:totalPnl>=0?"#00C97A":"#F43F5E"},
                  {l:"Return",        v:fmtPct((totalPnl/totalCost)*100), c:totalPnl>=0?"#00C97A":"#F43F5E"},
                ].map(s=>(
                  <div key={s.l} style={{background:"#161B22",border:`1px solid rgba(${hexRgb(s.c)},0.2)`,borderRadius:12,padding:"16px 18px"}}>
                    <div style={{color:"rgba(255,255,255,0.4)",fontSize:11,marginBottom:8}}>{s.l}</div>
                    <div style={{fontFamily:"'Orbitron',monospace",fontSize:20,fontWeight:700,color:s.c}}>{s.v}</div>
                  </div>
                ))}
              </div>

              {/* Positions */}
              <div style={{display:"flex",flexDirection:"column",gap:10}}>
                {portfolio.map(p=>{
                  const e=ENGINES[p.sym];
                  const a=ASSETS.find(a=>a.sym===p.sym);
                  const val=e.price*p.qty;
                  const cost=p.qty*p.avgPrice;
                  const pnl=val-cost;
                  const pct=(pnl/cost)*100;
                  return (
                    <div key={p.sym} style={{background:"#161B22",border:"1px solid rgba(255,255,255,0.07)",borderRadius:14,padding:"18px 20px",display:"flex",alignItems:"center",gap:16}}>
                      <div style={{width:44,height:44,borderRadius:10,background:`rgba(${hexRgb(a.color)},0.12)`,border:`1px solid rgba(${hexRgb(a.color)},0.25)`,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>
                        <span style={{fontFamily:"'Orbitron',monospace",fontSize:10,fontWeight:700,color:a.color}}>{p.sym}</span>
                      </div>
                      <div style={{flex:1}}>
                        <div style={{fontWeight:600,fontSize:15,color:"white",marginBottom:4}}>{a.name}</div>
                        <div style={{color:"rgba(255,255,255,0.35)",fontSize:12}}>
                          {p.qty} {p.sym} · avg {fmt(p.avgPrice)}
                        </div>
                      </div>
                      <div style={{textAlign:"center"}}>
                        <div style={{color:"rgba(255,255,255,0.4)",fontSize:10,marginBottom:4}}>Current Price</div>
                        <div style={{fontFamily:"'Orbitron',monospace",fontSize:14,color:"white",fontWeight:600}}>{fmt(e.price)}</div>
                      </div>
                      <div style={{textAlign:"center"}}>
                        <div style={{color:"rgba(255,255,255,0.4)",fontSize:10,marginBottom:4}}>Value</div>
                        <div style={{fontFamily:"'Orbitron',monospace",fontSize:14,color:"white",fontWeight:600}}>${val.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g,",")}</div>
                      </div>
                      <div style={{textAlign:"right",minWidth:90}}>
                        <div style={{fontFamily:"'Orbitron',monospace",fontSize:14,fontWeight:700,color:pnl>=0?"#00C97A":"#F43F5E"}}>{pnl>=0?"+":""}${Math.abs(pnl).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g,",")}</div>
                        <div style={{fontSize:11,color:pnl>=0?"#00C97A":"#F43F5E",fontFamily:"monospace",marginTop:2}}>{fmtPct(pct)}</div>
                      </div>
                      <button onClick={()=>{setOrderAsset(a); setTab("markets");}} style={{background:`rgba(${hexRgb(a.color)},0.08)`,border:`1px solid rgba(${hexRgb(a.color)},0.25)`,borderRadius:8,padding:"8px 14px",cursor:"pointer",color:a.color,fontWeight:600,fontSize:12,flexShrink:0}}>Trade →</button>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* ─ WITHDRAW TAB ─ */}
          {tab==="withdraw" && (
            <div style={{flex:1,padding:"20px",overflowY:"auto",display:"flex",gap:20}}>
              {/* Form */}
              <div style={{flex:1,maxWidth:480}}>
                <h2 style={{fontSize:16,fontWeight:600,marginBottom:6}}>Withdraw Funds</h2>
                <div style={{color:"rgba(255,255,255,0.4)",fontSize:13,marginBottom:20}}>Send to your personal wallet or bank account</div>

                {wStep===1 && (
                  <div style={{display:"flex",flexDirection:"column",gap:14}}>
                    {/* Balance */}
                    <div style={{background:"rgba(0,201,122,0.06)",border:"1px solid rgba(0,201,122,0.2)",borderRadius:12,padding:"14px 16px"}}>
                      <div style={{color:"rgba(255,255,255,0.4)",fontSize:11,marginBottom:4}}>Available Balance</div>
                      <div style={{fontFamily:"'Orbitron',monospace",fontSize:24,fontWeight:700,color:"#00C97A"}}>${totalPortfolio.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g,",")}</div>
                    </div>

                    {/* Amount */}
                    <div>
                      <div style={{color:"rgba(255,255,255,0.5)",fontSize:12,fontWeight:500,marginBottom:6}}>Amount (USD)</div>
                      <div style={{display:"flex",gap:8}}>
                        <input type="number" value={wAmount} onChange={e=>setWAmount(e.target.value)} placeholder="0.00"
                          style={{flex:1,background:"#161B22",border:`1px solid ${wAmount?"rgba(0,201,122,0.3)":"rgba(255,255,255,0.1)"}`,borderRadius:10,padding:"12px 14px",color:"white",fontFamily:"'Orbitron',monospace",fontSize:20,fontWeight:700,outline:"none"}}/>
                        <button onClick={()=>setWAmount((totalPortfolio*0.95).toFixed(2))} style={{background:"rgba(0,201,122,0.08)",border:"1px solid rgba(0,201,122,0.2)",borderRadius:10,padding:"0 14px",cursor:"pointer",color:"#00C97A",fontSize:12,fontWeight:600}}>MAX</button>
                      </div>
                    </div>

                    {/* Destination */}
                    <div>
                      <div style={{color:"rgba(255,255,255,0.5)",fontSize:12,fontWeight:500,marginBottom:6}}>Bitcoin Address</div>
                      <input value={wAddress} onChange={e=>setWAddress(e.target.value)} placeholder="bc1q... or 0x..."
                        style={{width:"100%",background:"#161B22",border:"1px solid rgba(255,255,255,0.1)",borderRadius:10,padding:"12px 14px",color:"white",fontFamily:"monospace",fontSize:13,outline:"none"}}/>
                    </div>

                    {/* Fee breakdown */}
                    {parseFloat(wAmount)>0 && (
                      <div style={{background:"#161B22",borderRadius:10,padding:"14px 16px",display:"flex",flexDirection:"column",gap:8}}>
                        {[["Amount",`$${parseFloat(wAmount).toFixed(2)}`,"white"],["Network Fee (0.1%)",`-$${(parseFloat(wAmount)*0.001+2.5).toFixed(2)}`,"#F43F5E"],["You Receive",`$${(parseFloat(wAmount)-parseFloat(wAmount)*0.001-2.5).toFixed(2)}`,"#00C97A"]].map(([l,v,c])=>(
                          <div key={l} style={{display:"flex",justifyContent:"space-between"}}>
                            <span style={{color:"rgba(255,255,255,0.4)",fontSize:12}}>{l}</span>
                            <span style={{fontFamily:"'Orbitron',monospace",fontSize:12,color:c,fontWeight:600}}>{v}</span>
                          </div>
                        ))}
                      </div>
                    )}

                    <button onClick={()=>setWStep(2)} disabled={!wAmount||parseFloat(wAmount)<=0} style={{
                      background:!wAmount||parseFloat(wAmount)<=0?"rgba(255,255,255,0.06)":"linear-gradient(135deg,#00C97A,#008844)",
                      border:"none", borderRadius:10, padding:"14px",
                      cursor:!wAmount||parseFloat(wAmount)<=0?"not-allowed":"pointer",
                      color:!wAmount||parseFloat(wAmount)<=0?"rgba(255,255,255,0.3)":"#0D1117",
                      fontWeight:700, fontSize:14, transition:"all 0.2s",
                    }}>Review Withdrawal →</button>
                  </div>
                )}

                {wStep===2 && (
                  <div style={{background:"#161B22",borderRadius:14,padding:20,display:"flex",flexDirection:"column",gap:14}}>
                    <div style={{color:"#F59E0B",fontSize:13,fontWeight:600}}>⚠ Review carefully — this cannot be undone</div>
                    {[["Amount",`$${parseFloat(wAmount||0).toFixed(2)}`],["Network Fee",`-$${(parseFloat(wAmount||0)*0.001+2.5).toFixed(2)}`],["Net Receive",`$${(parseFloat(wAmount||0)*0.999-2.5).toFixed(2)}`],["Address",wAddress.slice(0,16)+"..."]].map(([l,v])=>(
                      <div key={l} style={{display:"flex",justifyContent:"space-between",padding:"8px 0",borderBottom:"1px solid rgba(255,255,255,0.05)"}}>
                        <span style={{color:"rgba(255,255,255,0.4)",fontSize:12}}>{l}</span>
                        <span style={{color:"white",fontSize:12,fontFamily:"monospace"}}>{v}</span>
                      </div>
                    ))}
                    <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
                      <button onClick={()=>setWStep(1)} style={{background:"rgba(255,255,255,0.05)",border:"1px solid rgba(255,255,255,0.1)",borderRadius:10,padding:"12px",cursor:"pointer",color:"rgba(255,255,255,0.5)",fontWeight:600,fontSize:13}}>← Back</button>
                      <button onClick={()=>setWStep(3)} style={{background:"linear-gradient(135deg,#00C97A,#008844)",border:"none",borderRadius:10,padding:"12px",cursor:"pointer",color:"#0D1117",fontWeight:700,fontSize:13}}>Confirm ✓</button>
                    </div>
                  </div>
                )}

                {wStep===3 && (
                  <div style={{background:"rgba(0,201,122,0.06)",border:"1px solid rgba(0,201,122,0.2)",borderRadius:14,padding:32,textAlign:"center"}}>
                    <div style={{fontSize:52,marginBottom:14,color:"#00C97A",textShadow:"0 0 24px rgba(0,201,122,0.4)"}}>✓</div>
                    <div style={{fontFamily:"'Orbitron',monospace",fontSize:18,fontWeight:700,color:"#00C97A",marginBottom:10}}>Withdrawal Initiated</div>
                    <div style={{color:"rgba(255,255,255,0.45)",fontSize:13,lineHeight:1.8,marginBottom:20}}>
                      ${(parseFloat(wAmount||0)*0.999-2.5).toFixed(2)} processing on-chain<br/>
                      Reference: WD-{Math.floor(Math.random()*9000)+1000}<br/>
                      ETA: 10–30 minutes
                    </div>
                    <button onClick={()=>{setWStep(1);setWAmount("");setWAddress("");}} style={{background:"rgba(0,201,122,0.1)",border:"1px solid rgba(0,201,122,0.3)",borderRadius:10,padding:"10px 24px",cursor:"pointer",color:"#00C97A",fontWeight:600,fontSize:13}}>New Withdrawal</button>
                  </div>
                )}
              </div>

              {/* History */}
              <div style={{width:320,flexShrink:0}}>
                <div style={{color:"rgba(255,255,255,0.4)",fontSize:12,fontWeight:500,marginBottom:14}}>Recent Withdrawals</div>
                {[
                  {id:"WD-8821",amount:"$12,500",asset:"USDT",status:"Completed",time:"Apr 28"},
                  {id:"WD-8734",amount:"$50,000",asset:"BTC", status:"Completed",time:"Apr 21"},
                  {id:"WD-8601",amount:"$8,200", asset:"ETH", status:"Completed",time:"Apr 14"},
                  {id:"WD-8512",amount:"$31,000",asset:"BTC", status:"Failed",   time:"Apr 7"},
                ].map(h=>(
                  <div key={h.id} style={{background:"#161B22",border:"1px solid rgba(255,255,255,0.07)",borderRadius:12,padding:"14px 16px",marginBottom:8,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                    <div>
                      <div style={{fontWeight:600,fontSize:13,color:"white",marginBottom:3}}>{h.id}</div>
                      <div style={{color:"rgba(255,255,255,0.35)",fontSize:11}}>{h.asset} · {h.time}</div>
                    </div>
                    <div style={{textAlign:"right"}}>
                      <div style={{fontWeight:600,fontSize:13,color:"white",marginBottom:3}}>{h.amount}</div>
                      <span style={{background:h.status==="Completed"?"rgba(0,201,122,0.1)":"rgba(244,63,94,0.1)",color:h.status==="Completed"?"#00C97A":"#F43F5E",border:`1px solid ${h.status==="Completed"?"rgba(0,201,122,0.3)":"rgba(244,63,94,0.3)"}`,borderRadius:5,padding:"2px 8px",fontSize:10,fontFamily:"monospace"}}>{h.status}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* ── ORDER MODAL ── */}
        {orderAsset && (
          <div onClick={e=>{if(e.target===e.currentTarget)setOrderAsset(null);}} style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.7)",backdropFilter:"blur(8px)",display:"flex",alignItems:"center",justifyContent:"center",zIndex:100}}>
            <OrderPanel asset={orderAsset} onClose={()=>setOrderAsset(null)}/>
          </div>
        )}
      </div>
    </>
  );
}
