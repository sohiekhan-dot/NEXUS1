import { useState } from "react";
import NexusMerged2026 from "./NexusMerged2026.jsx";
import QuantumDashboard2026 from "./QuantumDashboard2026.jsx";
import SimpleTrader2026 from "./SimpleTrader2026.jsx";
import PropTrackDashboard from "./PropTrackDashboard.jsx";
import NexusMarketingDept from "./NexusMarketingDept.jsx";
import NexusCybersuite from "./NexusCybersuite.jsx";

const APPS = [
  { id:"nexus",    label:"NEXUS Merged",      icon:"◈", desc:"Quantum charts + prop firms + connections unified", color:"#00F5A0", component:NexusMerged2026 },
  { id:"quantum",  label:"Quantum Dashboard", icon:"⬡", desc:"Full quantum probability cloud trading OS 2026",    color:"#A78BFA", component:QuantumDashboard2026 },
  { id:"simple",   label:"Simple Trader",     icon:"▦", desc:"Clean easy-execution trader with order panel",      color:"#F59E0B", component:SimpleTrader2026 },
  { id:"prop",     label:"PropTrack",         icon:"🎯", desc:"Prop firm evaluation tracker & payout manager",    color:"#00D4FF", component:PropTrackDashboard },
  { id:"marketing",label:"Marketing OS",      icon:"⚡", desc:"AI sales & marketing department agents",           color:"#FF6B35", component:NexusMarketingDept },
  { id:"cyber",    label:"Cybersuite",        icon:"◉", desc:"Original full cyberpunk trading suite",            color:"#F43F5E", component:NexusCybersuite },
];

const rgb = h => { const r=/^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(h); return r?`${parseInt(r[1],16)},${parseInt(r[2],16)},${parseInt(r[3],16)}`:"255,255,255"; };

export default function App() {
  const [active, setActive] = useState(null);

  if (active) {
    const app = APPS.find(a => a.id === active);
    const Component = app.component;
    return (
      <div style={{ position:"relative" }}>
        <button onClick={() => setActive(null)} style={{
          position:"fixed", top:10, right:10, zIndex:9999,
          background:"rgba(0,0,0,0.8)", border:"1px solid rgba(255,255,255,0.2)",
          borderRadius:8, padding:"6px 14px", cursor:"pointer",
          color:"white", fontFamily:"monospace", fontSize:11, letterSpacing:1,
        }}>← HOME</button>
        <Component />
      </div>
    );
  }

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@700;900&family=Inter:wght@400;500;600&display=swap');
        *{box-sizing:border-box;margin:0;padding:0;}
        body{background:#0D1117;color:white;font-family:'Inter',sans-serif;}
        @keyframes fadeIn{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:translateY(0)}}
        @keyframes pulse{0%,100%{opacity:1}50%{opacity:.4}}
        .card{animation:fadeIn .4s ease both;transition:all .2s;}
        .card:hover{transform:translateY(-3px);}
      `}</style>
      <div style={{ minHeight:"100vh", background:"radial-gradient(ellipse at 20% 0%,rgba(0,245,160,0.05) 0%,transparent 50%),radial-gradient(ellipse at 80% 100%,rgba(167,139,250,0.04) 0%,transparent 50%),#0D1117", display:"flex", flexDirection:"column", alignItems:"center", padding:"60px 24px" }}>
        {/* Grid bg */}
        <div style={{ position:"fixed", inset:0, backgroundImage:"linear-gradient(rgba(0,245,160,0.012) 1px,transparent 1px),linear-gradient(90deg,rgba(0,245,160,0.012) 1px,transparent 1px)", backgroundSize:"48px 48px", pointerEvents:"none", zIndex:0 }}/>

        {/* Header */}
        <div style={{ position:"relative", zIndex:1, textAlign:"center", marginBottom:56 }}>
          <div style={{ display:"flex", alignItems:"center", justifyContent:"center", gap:14, marginBottom:20 }}>
            <div style={{ width:48, height:48, background:"linear-gradient(135deg,#00C97A,#005F38)", borderRadius:14, display:"flex", alignItems:"center", justifyContent:"center", fontSize:24, boxShadow:"0 0 30px rgba(0,201,122,0.4)" }}>◈</div>
            <div style={{ textAlign:"left" }}>
              <div style={{ fontFamily:"'Orbitron',monospace", fontWeight:900, fontSize:28, color:"#00C97A", letterSpacing:6, textShadow:"0 0 30px rgba(0,245,160,0.35)" }}>NEXUS</div>
              <div style={{ fontFamily:"monospace", fontSize:10, color:"rgba(255,255,255,0.3)", letterSpacing:4, marginTop:2 }}>QUANTUM TRADING PLATFORM · 2026</div>
            </div>
          </div>
          <p style={{ color:"rgba(255,255,255,0.4)", fontSize:15, maxWidth:520, lineHeight:1.7, margin:"0 auto" }}>
            Complete trading platform — quantum dashboards, prop firm tracker, AI marketing agents, auto-delivery server, and sales page. Select a module to launch.
          </p>
          <div style={{ display:"flex", gap:8, justifyContent:"center", marginTop:20, flexWrap:"wrap" }}>
            {[`${APPS.length} Modules`, "2026 Market Data", "Prop Firm Ready", "BTC Payment", "AI Agents"].map(tag => (
              <span key={tag} style={{ background:"rgba(0,245,160,0.07)", border:"1px solid rgba(0,245,160,0.2)", borderRadius:20, padding:"4px 12px", fontSize:11, color:"rgba(0,245,160,0.7)", fontFamily:"monospace" }}>{tag}</span>
            ))}
          </div>
        </div>

        {/* Module grid */}
        <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:16, maxWidth:900, width:"100%", position:"relative", zIndex:1 }}>
          {APPS.map((app, i) => (
            <div key={app.id} className="card" onClick={() => setActive(app.id)} style={{
              background:`rgba(${rgb(app.color)},0.06)`,
              border:`1px solid rgba(${rgb(app.color)},0.2)`,
              borderRadius:16, padding:"24px 22px", cursor:"pointer",
              animationDelay:`${i*0.07}s`,
              boxShadow:`0 4px 24px rgba(${rgb(app.color)},0.08)`,
            }}>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:14 }}>
                <span style={{ fontSize:28, color:app.color, textShadow:`0 0 16px ${app.color}` }}>{app.icon}</span>
                <span style={{ background:`rgba(${rgb(app.color)},0.1)`, border:`1px solid rgba(${rgb(app.color)},0.25)`, borderRadius:6, padding:"2px 8px", fontSize:8, color:app.color, fontFamily:"monospace", letterSpacing:1 }}>LAUNCH →</span>
              </div>
              <div style={{ fontFamily:"'Orbitron',monospace", fontWeight:700, fontSize:13, color:"white", letterSpacing:2, marginBottom:8 }}>{app.label}</div>
              <div style={{ color:"rgba(255,255,255,0.4)", fontSize:12, lineHeight:1.6 }}>{app.desc}</div>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div style={{ marginTop:56, textAlign:"center", color:"rgba(255,255,255,0.15)", fontSize:11, fontFamily:"monospace", letterSpacing:1, position:"relative", zIndex:1, lineHeight:2 }}>
          NEXUS QUANTUM TRADING PLATFORM · v1.0.0 · 2026<br/>
          FOR EDUCATIONAL AND PERSONAL USE · NOT FINANCIAL ADVICE
        </div>
      </div>
    </>
  );
}
