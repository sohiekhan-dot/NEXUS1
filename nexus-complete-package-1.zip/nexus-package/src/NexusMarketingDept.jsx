import { useState, useEffect, useRef, useCallback } from "react";

// ─── ANTHROPIC API CALL ───────────────────────────────────────────────────────
async function callClaude(systemPrompt, userMessage, maxTokens = 900) {
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: maxTokens,
      system: systemPrompt,
      messages: [{ role: "user", content: userMessage }],
    }),
  });
  const data = await res.json();
  return data.content?.[0]?.text || "";
}

// ─── AGENT DEFINITIONS ────────────────────────────────────────────────────────
const DEPT_AGENTS = [
  {
    id: "zara",
    name: "ZARA",
    role: "Ad Copy Writer",
    dept: "ADVERTISING",
    color: "#00f5a0",
    glow: "#00f5a055",
    icon: "◈",
    status: "READY",
    description: "Generates high-converting ad copy for Twitter/X, Reddit, Telegram, and crypto forums. Knows the trader psychology.",
    systemPrompt: `You are ZARA, an elite crypto trading software ad copywriter. You write punchy, high-converting ad copy for NEXUS Quantum Trading OS — a premium AI trading dashboard that traders pay for in Bitcoin.

NEXUS features: 4 AI agents (APEX, VEGA, NOVA, ARES), quantum probability clouds, order flow heatmap, Binance API integration, withdrawal portal. Prices: Starter 0.003 BTC, Pro 0.009 BTC, Elite 0.025 BTC.

RULES:
- Never make specific profit guarantees ("make $X", "guaranteed returns")
- Always frame as "software tool" not "trading signals"
- Target: independent crypto/stock traders, algo traders, quant enthusiasts
- Tone: bold, technical, confident, cyberpunk-edgy
- Include a clear CTA

Output ONLY valid JSON. No markdown, no explanation. Format:
{
  "platform": "platform name",
  "headline": "the hook",
  "body": "main copy text",
  "cta": "call to action",
  "hashtags": ["tag1","tag2"],
  "characterCount": 280
}`,
  },
  {
    id: "rex",
    name: "REX",
    role: "Outreach Specialist",
    dept: "SALES",
    color: "#f59e0b",
    glow: "#f59e0b55",
    icon: "⬡",
    status: "READY",
    description: "Crafts personalized cold outreach DMs for crypto Twitter, Discord servers, and trading communities. Converts lurkers to buyers.",
    systemPrompt: `You are REX, a sales outreach specialist for NEXUS Quantum Trading OS. You write personalized, non-spammy DM/outreach messages that feel genuine.

NEXUS is a premium AI trading dashboard: 4 autonomous agents, quantum probability cloud charts, order flow heatmap, Binance integration. Priced in BTC. Software tool only — no managed funds.

Target audiences: algo traders on crypto Twitter, members of trading Discord servers, Reddit communities (r/algotrading, r/CryptoCurrency, r/stocks), Telegram trading groups.

RULES:
- Sound human, not robotic
- Reference something specific about their community/interest
- No spam language
- Never promise profits
- Soft CTA — invite curiosity, not pressure
- Keep it concise (under 120 words for DMs)

Output ONLY valid JSON:
{
  "channel": "platform/community",
  "subject": "opening line or DM subject",
  "message": "full outreach message",
  "followUp": "follow-up message if no reply in 3 days",
  "tone": "casual|professional|technical"
}`,
  },
  {
    id: "nova2",
    name: "LYRA",
    role: "Content Strategist",
    dept: "MARKETING",
    color: "#c084fc",
    glow: "#c084fc55",
    icon: "▦",
    status: "READY",
    description: "Plans viral content threads, YouTube scripts, and blog posts that educate the market and funnel traders to the product.",
    systemPrompt: `You are LYRA, a content strategist for NEXUS Quantum Trading OS. You plan and write viral educational content that attracts traders organically.

NEXUS features quantum probability cloud charts (Monte Carlo simulation), 4 AI trading agents with different strategies, real-time order flow heatmap, Binance API integration. Pay in Bitcoin.

Content philosophy: educate first, sell second. Create content that teaches traders real concepts (GBM, Monte Carlo, order flow, agent-based trading) and naturally positions NEXUS as the tool that makes it accessible.

Output ONLY valid JSON:
{
  "contentType": "twitter_thread|youtube_script|blog_post|reddit_post",
  "title": "content title",
  "hook": "opening line that stops the scroll",
  "outline": ["point 1", "point 2", "point 3"],
  "fullContent": "the actual content text",
  "estimatedReach": "low|medium|high|viral",
  "publishTime": "best time to post"
}`,
  },
  {
    id: "atlas",
    name: "ATLAS",
    role: "Analytics & Growth",
    dept: "GROWTH",
    color: "#f43f5e",
    glow: "#f43f5e55",
    icon: "◉",
    status: "READY",
    description: "Analyzes campaign performance, identifies growth opportunities, tracks competitor moves, and generates strategy reports.",
    systemPrompt: `You are ATLAS, a growth analytics agent for NEXUS Quantum Trading OS. You analyze marketing performance, identify opportunities, and generate strategic growth recommendations.

Context: NEXUS is a premium trading software sold for BTC. Current channels: crypto Twitter, Reddit, Telegram, organic SEO. Three pricing tiers. Target: independent traders, algo devs, quant enthusiasts.

When given data or a question, you provide sharp, actionable intelligence — not generic advice. Think like a Y Combinator growth advisor who deeply understands the crypto trader market.

Output ONLY valid JSON:
{
  "analysisType": "campaign_review|competitor_analysis|growth_strategy|channel_audit",
  "summary": "2-sentence executive summary",
  "keyFindings": ["finding 1", "finding 2", "finding 3"],
  "opportunities": ["opportunity 1", "opportunity 2"],
  "recommendations": [{"action": "what to do", "priority": "high|medium|low", "effort": "low|medium|high", "impact": "low|medium|high"}],
  "nextSteps": ["step 1", "step 2", "step 3"]
}`,
  },
];

// ─── SIMULATED METRICS ────────────────────────────────────────────────────────
const PLATFORMS = ["Twitter/X", "Reddit", "Telegram", "Discord", "YouTube", "Medium"];
const AD_TYPES = ["Banner", "Thread", "DM Blast", "Forum Post", "Video Script", "Email"];

function useMetrics() {
  const [metrics, setMetrics] = useState({
    impressions: 48200,
    clicks: 1840,
    conversions: 23,
    revenue: 0.009 * 14 + 0.003 * 6 + 0.025 * 3,
    ctr: 3.81,
    cpc: 0.000012,
    campaigns: [
      { id: 1, name: "Crypto Twitter Blitz", platform: "Twitter/X", status: "LIVE", impressions: 18200, clicks: 742, conv: 9, spend: 0.0004 },
      { id: 2, name: "r/algotrading Organic", platform: "Reddit", status: "LIVE", impressions: 12400, clicks: 580, conv: 7, spend: 0 },
      { id: 3, name: "Telegram DM Campaign", platform: "Telegram", status: "PAUSED", impressions: 8800, clicks: 310, conv: 4, spend: 0.0002 },
      { id: 4, name: "Discord Server Drops", platform: "Discord", status: "LIVE", impressions: 6200, clicks: 142, conv: 2, spend: 0.0001 },
      { id: 5, name: "YouTube Short Series", platform: "YouTube", status: "SCHEDULED", impressions: 2600, clicks: 66, conv: 1, spend: 0 },
    ],
    funnelData: [
      { stage: "AWARENESS", count: 48200, color: "#00f5a0" },
      { stage: "INTEREST", count: 8400, color: "#f59e0b" },
      { stage: "CONSIDERATION", count: 1840, color: "#c084fc" },
      { stage: "PURCHASE", count: 23, color: "#f43f5e" },
    ],
    recentSales: [
      { tier: "PRO", btc: "0.009", time: "2m ago", country: "🇺🇸" },
      { tier: "ELITE", btc: "0.025", time: "18m ago", country: "🇸🇬" },
      { tier: "STARTER", btc: "0.003", time: "41m ago", country: "🇳🇬" },
      { tier: "PRO", btc: "0.009", time: "1h ago", country: "🇰🇷" },
      { tier: "PRO", btc: "0.009", time: "2h ago", country: "🇩🇪" },
    ],
  });

  useEffect(() => {
    const iv = setInterval(() => {
      setMetrics(prev => {
        const newImpressions = prev.impressions + Math.floor(Math.random() * 80 + 20);
        const newClicks = prev.clicks + Math.floor(Math.random() * 4);
        const shouldConvert = Math.random() < 0.04;
        const tiers = [{ t: "PRO", b: "0.009" }, { t: "STARTER", b: "0.003" }, { t: "ELITE", b: "0.025" }];
        const flags = ["🇺🇸", "🇬🇧", "🇸🇬", "🇩🇪", "🇳🇬", "🇰🇷", "🇧🇷", "🇦🇺", "🇨🇦", "🇯🇵", "🇿🇦", "🇮🇳"];
        const newSales = shouldConvert ? [
          { tier: tiers[Math.floor(Math.random() * tiers.length)].t, btc: tiers[Math.floor(Math.random() * tiers.length)].b, time: "just now", country: flags[Math.floor(Math.random() * flags.length)] },
          ...prev.recentSales.slice(0, 4).map(s => ({ ...s, time: s.time === "just now" ? "1m ago" : s.time }))
        ] : prev.recentSales;
        return {
          ...prev,
          impressions: newImpressions,
          clicks: newClicks,
          conversions: prev.conversions + (shouldConvert ? 1 : 0),
          ctr: ((newClicks / newImpressions) * 100),
          recentSales: newSales,
        };
      });
    }, 2200);
    return () => clearInterval(iv);
  }, []);

  return metrics;
}

// ─── HELPERS ──────────────────────────────────────────────────────────────────
function hexToRgb(hex) {
  const r = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return r ? `${parseInt(r[1],16)},${parseInt(r[2],16)},${parseInt(r[3],16)}` : "255,255,255";
}

function GlowDot({ color, pulse = false, size = 7 }) {
  return <span style={{ width: size, height: size, borderRadius: "50%", background: color, boxShadow: `0 0 8px ${color}`, display: "inline-block", flexShrink: 0, animation: pulse ? "agentPulse 1.4s ease-in-out infinite" : "none" }} />;
}

// ─── FUNNEL CHART ─────────────────────────────────────────────────────────────
function FunnelChart({ data }) {
  const max = data[0]?.count || 1;
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
      {data.map((d, i) => {
        const pct = (d.count / max) * 100;
        const convRate = i > 0 ? ((d.count / data[i - 1].count) * 100).toFixed(1) : "—";
        return (
          <div key={d.stage}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
              <span style={{ color: "rgba(255,255,255,0.35)", fontSize: 9, fontFamily: "monospace", letterSpacing: 1.5 }}>{d.stage}</span>
              <span style={{ color: "rgba(255,255,255,0.4)", fontSize: 9, fontFamily: "monospace" }}>
                {d.count.toLocaleString()} {i > 0 && <span style={{ color: d.color }}>({convRate}%)</span>}
              </span>
            </div>
            <div style={{ height: 10, background: "rgba(255,255,255,0.04)", borderRadius: 5, overflow: "hidden" }}>
              <div style={{ height: "100%", width: `${pct}%`, background: `linear-gradient(90deg, ${d.color}, ${d.color}88)`, borderRadius: 5, boxShadow: `0 0 8px ${d.color}55`, transition: "width 0.8s ease" }} />
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ─── SPARKLINE ────────────────────────────────────────────────────────────────
function Sparkline({ data, color, w = 80, h = 28 }) {
  if (!data || data.length < 2) return null;
  const mn = Math.min(...data), mx = Math.max(...data), rng = mx - mn || 1;
  const pts = data.map((v, i) => `${(i / (data.length - 1)) * w},${h - ((v - mn) / rng) * (h - 4) - 2}`).join(" ");
  return (
    <svg width={w} height={h} style={{ flexShrink: 0 }}>
      <polyline points={pts} fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round" style={{ filter: `drop-shadow(0 0 3px ${color})` }} />
    </svg>
  );
}

// ─── AGENT CARD ───────────────────────────────────────────────────────────────
function AgentCard({ agent, isRunning, onSelect, isSelected }) {
  return (
    <div onClick={() => onSelect(agent)} style={{
      background: isSelected ? `rgba(${hexToRgb(agent.color)},0.1)` : "rgba(6,6,20,0.85)",
      border: `1px solid ${isSelected ? agent.color : "rgba(255,255,255,0.07)"}`,
      borderRadius: 14, padding: "16px 18px", cursor: "pointer",
      transition: "all 0.22s", position: "relative", overflow: "hidden",
      boxShadow: isSelected ? `0 0 24px ${agent.glow}` : "none",
    }}>
      {isSelected && <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: 2, background: `linear-gradient(90deg,transparent,${agent.color},transparent)` }} />}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10 }}>
        <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
          <span style={{ fontSize: 20, color: agent.color, textShadow: `0 0 12px ${agent.color}` }}>{agent.icon}</span>
          <div>
            <div style={{ fontFamily: "'Orbitron',monospace", fontWeight: 900, fontSize: 14, color: agent.color, letterSpacing: 3 }}>{agent.name}</div>
            <div style={{ color: "rgba(255,255,255,0.3)", fontSize: 9, fontFamily: "monospace", letterSpacing: 1 }}>{agent.role}</div>
          </div>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 5, background: `rgba(${hexToRgb(isRunning ? agent.color : "#4b5563")},0.1)`, border: `1px solid rgba(${hexToRgb(isRunning ? agent.color : "#4b5563")},0.25)`, borderRadius: 20, padding: "3px 9px" }}>
          <GlowDot color={isRunning ? agent.color : "#4b5563"} pulse={isRunning} size={5} />
          <span style={{ fontSize: 7, color: isRunning ? agent.color : "#4b5563", fontFamily: "monospace", letterSpacing: 1 }}>{isRunning ? "RUNNING" : agent.status}</span>
        </div>
      </div>
      <div style={{ color: "rgba(255,255,255,0.35)", fontSize: 11, lineHeight: 1.5, fontFamily: "'Rajdhani',sans-serif" }}>{agent.description}</div>
      <div style={{ marginTop: 10, display: "inline-block", background: `rgba(${hexToRgb(agent.color)},0.08)`, border: `1px solid rgba(${hexToRgb(agent.color)},0.2)`, borderRadius: 4, padding: "2px 8px", fontSize: 8, color: agent.color, fontFamily: "monospace", letterSpacing: 1.5 }}>{agent.dept}</div>
    </div>
  );
}

// ─── OUTPUT RENDERER ─────────────────────────────────────────────────────────
function OutputRenderer({ output, agent }) {
  if (!output) return null;
  let parsed = null;
  try { parsed = JSON.parse(output); } catch { return <pre style={{ color: "rgba(255,255,255,0.6)", fontSize: 11, fontFamily: "monospace", whiteSpace: "pre-wrap", lineHeight: 1.7 }}>{output}</pre>; }

  if (agent.id === "zara") {
    return (
      <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
        <div style={{ background: "rgba(0,245,160,0.05)", border: "1px solid rgba(0,245,160,0.15)", borderRadius: 12, padding: 18 }}>
          <div style={{ color: "rgba(255,255,255,0.3)", fontSize: 8, fontFamily: "monospace", letterSpacing: 2, marginBottom: 8 }}>PLATFORM · {parsed.platform}</div>
          <div style={{ fontFamily: "'Orbitron',monospace", fontSize: 15, fontWeight: 700, color: "#00f5a0", marginBottom: 10, lineHeight: 1.4 }}>{parsed.headline}</div>
          <div style={{ color: "rgba(255,255,255,0.65)", fontSize: 13, lineHeight: 1.7, marginBottom: 12 }}>{parsed.body}</div>
          <div style={{ color: "#f59e0b", fontSize: 12, fontWeight: 600, marginBottom: 10 }}>→ {parsed.cta}</div>
          <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
            {parsed.hashtags?.map(h => <span key={h} style={{ background: "rgba(0,245,160,0.08)", border: "1px solid rgba(0,245,160,0.2)", borderRadius: 4, padding: "2px 8px", fontSize: 9, color: "#00f5a0", fontFamily: "monospace" }}>#{h}</span>)}
          </div>
        </div>
        <div style={{ color: "rgba(255,255,255,0.2)", fontSize: 9, fontFamily: "monospace" }}>CHARACTER COUNT: {parsed.characterCount}</div>
      </div>
    );
  }

  if (agent.id === "rex") {
    return (
      <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
        <div style={{ background: "rgba(245,158,11,0.05)", border: "1px solid rgba(245,158,11,0.15)", borderRadius: 12, padding: 18 }}>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 12 }}>
            <div style={{ color: "rgba(255,255,255,0.3)", fontSize: 8, fontFamily: "monospace", letterSpacing: 2 }}>CHANNEL · {parsed.channel}</div>
            <span style={{ background: "rgba(245,158,11,0.1)", border: "1px solid rgba(245,158,11,0.25)", borderRadius: 4, padding: "2px 8px", fontSize: 8, color: "#f59e0b", fontFamily: "monospace" }}>{parsed.tone?.toUpperCase()}</span>
          </div>
          <div style={{ color: "#f59e0b", fontSize: 11, fontFamily: "monospace", marginBottom: 8 }}>OPENING: {parsed.subject}</div>
          <div style={{ color: "rgba(255,255,255,0.65)", fontSize: 13, lineHeight: 1.8, background: "rgba(4,4,16,0.6)", borderRadius: 8, padding: "12px 14px", marginBottom: 12 }}>{parsed.message}</div>
          {parsed.followUp && <div>
            <div style={{ color: "rgba(255,255,255,0.2)", fontSize: 8, fontFamily: "monospace", letterSpacing: 2, marginBottom: 6 }}>FOLLOW-UP (3 DAYS)</div>
            <div style={{ color: "rgba(255,255,255,0.45)", fontSize: 12, lineHeight: 1.7, background: "rgba(4,4,16,0.4)", borderRadius: 8, padding: "10px 12px", borderLeft: "2px solid rgba(245,158,11,0.3)" }}>{parsed.followUp}</div>
          </div>}
        </div>
      </div>
    );
  }

  if (agent.id === "nova2") {
    return (
      <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
        <div style={{ background: "rgba(192,132,252,0.05)", border: "1px solid rgba(192,132,252,0.15)", borderRadius: 12, padding: 18 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
            <span style={{ color: "rgba(255,255,255,0.3)", fontSize: 8, fontFamily: "monospace", letterSpacing: 2 }}>{parsed.contentType?.replace(/_/g, " ").toUpperCase()}</span>
            <span style={{ background: parsed.estimatedReach === "viral" ? "rgba(244,63,94,0.1)" : "rgba(192,132,252,0.1)", border: `1px solid ${parsed.estimatedReach === "viral" ? "rgba(244,63,94,0.3)" : "rgba(192,132,252,0.25)"}`, borderRadius: 4, padding: "2px 8px", fontSize: 8, color: parsed.estimatedReach === "viral" ? "#f43f5e" : "#c084fc", fontFamily: "monospace" }}>
              {parsed.estimatedReach?.toUpperCase()} REACH
            </span>
          </div>
          <div style={{ fontFamily: "'Orbitron',monospace", fontSize: 14, color: "#c084fc", marginBottom: 8, lineHeight: 1.4 }}>{parsed.title}</div>
          <div style={{ color: "#00f5a0", fontSize: 12, fontStyle: "italic", marginBottom: 14, lineHeight: 1.6 }}>"{parsed.hook}"</div>
          <div style={{ marginBottom: 14 }}>
            <div style={{ color: "rgba(255,255,255,0.2)", fontSize: 8, fontFamily: "monospace", letterSpacing: 2, marginBottom: 8 }}>OUTLINE</div>
            {parsed.outline?.map((p, i) => <div key={i} style={{ display: "flex", gap: 8, marginBottom: 5 }}>
              <span style={{ color: "#c084fc", fontSize: 10, flexShrink: 0 }}>{i + 1}.</span>
              <span style={{ color: "rgba(255,255,255,0.55)", fontSize: 12 }}>{p}</span>
            </div>)}
          </div>
          <div style={{ color: "rgba(255,255,255,0.6)", fontSize: 12, lineHeight: 1.8, background: "rgba(4,4,16,0.6)", borderRadius: 8, padding: "12px 14px", maxHeight: 200, overflowY: "auto" }}>{parsed.fullContent}</div>
          <div style={{ marginTop: 10, color: "rgba(255,255,255,0.3)", fontSize: 9, fontFamily: "monospace" }}>BEST TIME: {parsed.publishTime}</div>
        </div>
      </div>
    );
  }

  if (agent.id === "atlas") {
    const priColor = { high: "#f43f5e", medium: "#f59e0b", low: "#00f5a0" };
    return (
      <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
        <div style={{ background: "rgba(244,63,94,0.05)", border: "1px solid rgba(244,63,94,0.15)", borderRadius: 12, padding: 18 }}>
          <div style={{ color: "rgba(255,255,255,0.3)", fontSize: 8, fontFamily: "monospace", letterSpacing: 2, marginBottom: 8 }}>{parsed.analysisType?.replace(/_/g, " ").toUpperCase()}</div>
          <div style={{ color: "rgba(255,255,255,0.7)", fontSize: 13, lineHeight: 1.7, marginBottom: 14 }}>{parsed.summary}</div>
          {parsed.keyFindings?.length > 0 && <div style={{ marginBottom: 14 }}>
            <div style={{ color: "rgba(255,255,255,0.2)", fontSize: 8, fontFamily: "monospace", letterSpacing: 2, marginBottom: 8 }}>KEY FINDINGS</div>
            {parsed.keyFindings.map((f, i) => <div key={i} style={{ display: "flex", gap: 8, marginBottom: 6 }}>
              <span style={{ color: "#f43f5e", fontSize: 9, flexShrink: 0, marginTop: 2 }}>◈</span>
              <span style={{ color: "rgba(255,255,255,0.55)", fontSize: 12, lineHeight: 1.5 }}>{f}</span>
            </div>)}
          </div>}
          {parsed.recommendations?.length > 0 && <div>
            <div style={{ color: "rgba(255,255,255,0.2)", fontSize: 8, fontFamily: "monospace", letterSpacing: 2, marginBottom: 8 }}>RECOMMENDATIONS</div>
            {parsed.recommendations.map((r, i) => <div key={i} style={{ background: "rgba(4,4,16,0.7)", border: "1px solid rgba(255,255,255,0.05)", borderRadius: 8, padding: "10px 12px", marginBottom: 6, display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 12 }}>
              <div style={{ color: "rgba(255,255,255,0.6)", fontSize: 12, flex: 1 }}>{r.action}</div>
              <div style={{ display: "flex", gap: 4, flexShrink: 0 }}>
                <span style={{ background: `rgba(${hexToRgb(priColor[r.priority] || "#00f5a0")},0.1)`, color: priColor[r.priority] || "#00f5a0", border: `1px solid rgba(${hexToRgb(priColor[r.priority] || "#00f5a0")},0.25)`, borderRadius: 3, padding: "1px 6px", fontSize: 7, fontFamily: "monospace" }}>{r.priority?.toUpperCase()}</span>
              </div>
            </div>)}
          </div>}
        </div>
      </div>
    );
  }

  return <pre style={{ color: "rgba(255,255,255,0.6)", fontSize: 11, fontFamily: "monospace", whiteSpace: "pre-wrap" }}>{JSON.stringify(parsed, null, 2)}</pre>;
}

// ─── CAMPAIGN TABLE ────────────────────────────────────────────────────────────
function CampaignTable({ campaigns }) {
  const statusColor = { LIVE: "#00f5a0", PAUSED: "#f59e0b", SCHEDULED: "#c084fc", ENDED: "#4b5563" };
  return (
    <div style={{ overflow: "auto" }}>
      <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 11 }}>
        <thead>
          <tr>{["CAMPAIGN", "PLATFORM", "IMPR.", "CLICKS", "CONV.", "STATUS"].map(h => (
            <th key={h} style={{ color: "rgba(255,255,255,0.2)", fontSize: 8, fontFamily: "monospace", letterSpacing: 2, padding: "6px 10px", textAlign: "left", borderBottom: "1px solid rgba(255,255,255,0.05)", whiteSpace: "nowrap" }}>{h}</th>
          ))}</tr>
        </thead>
        <tbody>
          {campaigns.map(c => (
            <tr key={c.id} style={{ borderBottom: "1px solid rgba(255,255,255,0.03)" }}>
              <td style={{ padding: "9px 10px", color: "rgba(255,255,255,0.7)", fontFamily: "monospace", fontSize: 11 }}>{c.name}</td>
              <td style={{ padding: "9px 10px", color: "rgba(255,255,255,0.4)", fontSize: 10, fontFamily: "monospace" }}>{c.platform}</td>
              <td style={{ padding: "9px 10px", fontFamily: "'Orbitron',monospace", fontSize: 10, color: "white" }}>{c.impressions.toLocaleString()}</td>
              <td style={{ padding: "9px 10px", fontFamily: "'Orbitron',monospace", fontSize: 10, color: "#f59e0b" }}>{c.clicks.toLocaleString()}</td>
              <td style={{ padding: "9px 10px", fontFamily: "'Orbitron',monospace", fontSize: 10, color: "#00f5a0" }}>{c.conv}</td>
              <td style={{ padding: "9px 10px" }}>
                <span style={{ background: `rgba(${hexToRgb(statusColor[c.status])},0.08)`, color: statusColor[c.status], border: `1px solid rgba(${hexToRgb(statusColor[c.status])},0.25)`, borderRadius: 4, padding: "2px 8px", fontSize: 8, fontFamily: "monospace", letterSpacing: 1 }}>{c.status}</span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// ─── MAIN COMPONENT ───────────────────────────────────────────────────────────
export default function MarketingDept() {
  const [selectedAgent, setSelectedAgent] = useState(DEPT_AGENTS[0]);
  const [prompt, setPrompt] = useState("");
  const [output, setOutput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [runningAgents, setRunningAgents] = useState(new Set());
  const [activeTab, setActiveTab] = useState("workspace");
  const [history, setHistory] = useState([]);
  const [autoMode, setAutoMode] = useState(false);
  const metrics = useMetrics();
  const autoRef = useRef(null);

  // Default prompts per agent
  const defaultPrompts = {
    zara: "Write a Twitter/X ad for our NEXUS Pro tier (0.009 BTC) targeting algo traders who are frustrated with expensive institutional platforms",
    rex: "Write a DM for r/algotrading community members who post about building their own trading bots",
    nova2: "Create a viral Twitter thread about how quantum Monte Carlo simulation can be used to visualize price probability — and tie it to our dashboard",
    atlas: "Analyze our current marketing channels and give me the top 3 growth opportunities we're missing, plus a prioritized action plan",
  };

  useEffect(() => {
    setPrompt(defaultPrompts[selectedAgent.id] || "");
    setOutput("");
  }, [selectedAgent.id]);

  // AUTO MODE — cycles through agents and generates content automatically
  useEffect(() => {
    if (!autoMode) { clearInterval(autoRef.current); return; }
    const agentQueue = [...DEPT_AGENTS];
    let idx = 0;
    autoRef.current = setInterval(async () => {
      const agent = agentQueue[idx % agentQueue.length];
      idx++;
      setRunningAgents(prev => new Set([...prev, agent.id]));
      try {
        const p = defaultPrompts[agent.id];
        const result = await callClaude(agent.systemPrompt, p);
        setHistory(prev => [{
          id: Date.now(),
          agentName: agent.name,
          agentColor: agent.color,
          dept: agent.dept,
          prompt: p,
          output: result,
          time: new Date().toLocaleTimeString(),
          agent,
        }, ...prev.slice(0, 19)]);
      } catch (e) { console.error(e); }
      finally { setRunningAgents(prev => { const n = new Set(prev); n.delete(agent.id); return n; }); }
    }, 12000);
    return () => clearInterval(autoRef.current);
  }, [autoMode]);

  async function runAgent() {
    if (!prompt.trim() || isLoading) return;
    setIsLoading(true);
    setRunningAgents(prev => new Set([...prev, selectedAgent.id]));
    setOutput("");
    try {
      const result = await callClaude(selectedAgent.systemPrompt, prompt);
      setOutput(result);
      setHistory(prev => [{
        id: Date.now(),
        agentName: selectedAgent.name,
        agentColor: selectedAgent.color,
        dept: selectedAgent.dept,
        prompt,
        output: result,
        time: new Date().toLocaleTimeString(),
        agent: selectedAgent,
      }, ...prev.slice(0, 19)]);
    } catch (e) {
      setOutput(`Error: ${e.message}`);
    } finally {
      setIsLoading(false);
      setRunningAgents(prev => { const n = new Set(prev); n.delete(selectedAgent.id); return n; });
    }
  }

  const TABS = [
    { id: "workspace", label: "WORKSPACE", icon: "◈" },
    { id: "analytics", label: "ANALYTICS", icon: "⬡" },
    { id: "campaigns", label: "CAMPAIGNS", icon: "▦" },
    { id: "history", label: "HISTORY", icon: "◉" },
  ];

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@400;600;700;900&family=Rajdhani:wght@300;400;500;600;700&family=Share+Tech+Mono&display=swap');
        *{box-sizing:border-box;margin:0;padding:0;}
        html,body{height:100%;background:#010108;overflow:hidden;}
        ::-webkit-scrollbar{width:3px;height:3px;}
        ::-webkit-scrollbar-thumb{background:rgba(0,245,160,0.15);border-radius:2px;}
        @keyframes agentPulse{0%,100%{opacity:1;box-shadow:0 0 8px currentColor}50%{opacity:0.3;box-shadow:0 0 18px currentColor}}
        @keyframes scanH{0%{top:-1px}100%{top:100%}}
        @keyframes fadeUp{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:translateY(0)}}
        @keyframes spin{to{transform:rotate(360deg)}}
        @keyframes shimmer{0%{background-position:-200% 0}100%{background-position:200% 0}}
        .fadein{animation:fadeUp 0.3s ease both}
        textarea{resize:none;}
        textarea::placeholder{color:rgba(255,255,255,0.2);}
      `}</style>

      <div style={{
        width: "100vw", height: "100vh", display: "flex", flexDirection: "column",
        background: "radial-gradient(ellipse at 15% 0%,rgba(0,245,160,0.04) 0%,transparent 55%),radial-gradient(ellipse at 85% 100%,rgba(192,132,252,0.03) 0%,transparent 55%),#010108",
        color: "white", fontFamily: "'Rajdhani',sans-serif", overflow: "hidden", position: "relative",
      }}>
        {/* Grid */}
        <div style={{ position: "fixed", inset: 0, backgroundImage: "linear-gradient(rgba(0,245,160,0.012) 1px,transparent 1px),linear-gradient(90deg,rgba(0,245,160,0.012) 1px,transparent 1px)", backgroundSize: "52px 52px", pointerEvents: "none", zIndex: 0 }} />
        {/* Scanline */}
        <div style={{ position: "fixed", left: 0, right: 0, height: 1, background: "linear-gradient(90deg,transparent,rgba(0,245,160,0.06),transparent)", animation: "scanH 7s linear infinite", pointerEvents: "none", zIndex: 9999 }} />

        {/* ── HEADER ── */}
        <div style={{ position: "relative", zIndex: 10, flexShrink: 0, background: "rgba(1,1,8,0.95)", backdropFilter: "blur(20px)", borderBottom: "1px solid rgba(255,255,255,0.055)", height: 56, display: "flex", alignItems: "center", padding: "0 20px", gap: 20 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10, flexShrink: 0 }}>
            <div style={{ width: 32, height: 32, background: "linear-gradient(135deg,#f59e0b,#d97706)", borderRadius: 9, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16, boxShadow: "0 0 20px rgba(245,158,11,0.4)" }}>⬡</div>
            <div>
              <div style={{ fontFamily: "'Orbitron',monospace", fontWeight: 900, fontSize: 13, letterSpacing: 4, color: "#f59e0b", textShadow: "0 0 16px rgba(245,158,11,0.4)" }}>NEXUS</div>
              <div style={{ fontFamily: "monospace", fontSize: 7, color: "rgba(255,255,255,0.2)", letterSpacing: 3 }}>SALES & MARKETING OS</div>
            </div>
          </div>

          {/* Tabs */}
          <div style={{ display: "flex", gap: 2, background: "rgba(4,4,12,0.7)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 10, padding: 3 }}>
            {TABS.map(t => (
              <button key={t.id} onClick={() => setActiveTab(t.id)} style={{
                background: activeTab === t.id ? "rgba(245,158,11,0.1)" : "transparent",
                border: `1px solid ${activeTab === t.id ? "rgba(245,158,11,0.3)" : "transparent"}`,
                borderRadius: 8, padding: "6px 14px", cursor: "pointer",
                color: activeTab === t.id ? "#f59e0b" : "rgba(255,255,255,0.35)",
                fontFamily: "'Orbitron',monospace", fontSize: 9, letterSpacing: 2,
                transition: "all 0.18s", display: "flex", alignItems: "center", gap: 5,
              }}>
                <span style={{ fontSize: 11 }}>{t.icon}</span>{t.label}
              </button>
            ))}
          </div>

          {/* Live metrics */}
          <div style={{ marginLeft: "auto", display: "flex", gap: 20, alignItems: "center" }}>
            {[
              { l: "IMPRESSIONS", v: metrics.impressions.toLocaleString(), c: "#00f5a0" },
              { l: "CONVERSIONS", v: metrics.conversions, c: "#f59e0b" },
              { l: "CTR", v: metrics.ctr.toFixed(2) + "%", c: "#c084fc" },
            ].map(m => (
              <div key={m.l} style={{ textAlign: "right" }}>
                <div style={{ fontFamily: "'Orbitron',monospace", fontSize: 13, fontWeight: 700, color: m.c }}>{m.v}</div>
                <div style={{ color: "rgba(255,255,255,0.2)", fontSize: 7, fontFamily: "monospace", letterSpacing: 2 }}>{m.l}</div>
              </div>
            ))}

            {/* AUTO MODE toggle */}
            <div style={{ display: "flex", alignItems: "center", gap: 8, background: autoMode ? "rgba(0,245,160,0.06)" : "rgba(255,255,255,0.03)", border: `1px solid ${autoMode ? "rgba(0,245,160,0.3)" : "rgba(255,255,255,0.08)"}`, borderRadius: 8, padding: "6px 12px", cursor: "pointer" }} onClick={() => setAutoMode(p => !p)}>
              <div style={{ width: 28, height: 16, borderRadius: 8, background: autoMode ? "rgba(0,245,160,0.2)" : "rgba(255,255,255,0.08)", border: `1px solid ${autoMode ? "#00f5a0" : "rgba(255,255,255,0.15)"}`, position: "relative", transition: "all 0.2s" }}>
                <div style={{ position: "absolute", top: 2, left: autoMode ? 13 : 2, width: 10, height: 10, borderRadius: "50%", background: autoMode ? "#00f5a0" : "rgba(255,255,255,0.3)", transition: "all 0.2s", boxShadow: autoMode ? "0 0 6px #00f5a0" : "none" }} />
              </div>
              <span style={{ fontFamily: "'Orbitron',monospace", fontSize: 8, color: autoMode ? "#00f5a0" : "rgba(255,255,255,0.35)", letterSpacing: 1.5 }}>AUTO</span>
            </div>
          </div>
        </div>

        {/* ── CONTENT ── */}
        <div style={{ flex: 1, overflow: "hidden", position: "relative", zIndex: 1 }}>

          {/* WORKSPACE TAB */}
          {activeTab === "workspace" && (
            <div style={{ display: "grid", gridTemplateColumns: "260px 1fr", height: "100%", overflow: "hidden" }}>
              {/* Left: agent roster */}
              <div style={{ borderRight: "1px solid rgba(255,255,255,0.055)", padding: "14px 12px", display: "flex", flexDirection: "column", gap: 10, overflowY: "auto", background: "rgba(1,1,8,0.5)" }}>
                <div style={{ color: "rgba(255,255,255,0.2)", fontSize: 8, fontFamily: "monospace", letterSpacing: 3, padding: "0 4px", flexShrink: 0 }}>DEPARTMENT AGENTS</div>
                {DEPT_AGENTS.map(a => (
                  <AgentCard key={a.id} agent={a} isRunning={runningAgents.has(a.id)} onSelect={setSelectedAgent} isSelected={selectedAgent.id === a.id} />
                ))}
                {/* Recent sales feed */}
                <div style={{ background: "rgba(6,6,20,0.8)", border: "1px solid rgba(255,255,255,0.06)", borderRadius: 12, padding: "12px 14px", marginTop: 4, flexShrink: 0 }}>
                  <div style={{ color: "rgba(255,255,255,0.2)", fontSize: 8, fontFamily: "monospace", letterSpacing: 2, marginBottom: 10, display: "flex", alignItems: "center", gap: 6 }}>
                    <GlowDot color="#00f5a0" pulse size={5} /> LIVE SALES
                  </div>
                  {metrics.recentSales.slice(0, 4).map((s, i) => (
                    <div key={i} className="fadein" style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "5px 0", borderBottom: "1px solid rgba(255,255,255,0.03)" }}>
                      <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
                        <span style={{ fontSize: 12 }}>{s.country}</span>
                        <span style={{ background: s.tier === "ELITE" ? "rgba(192,132,252,0.1)" : s.tier === "PRO" ? "rgba(245,158,11,0.1)" : "rgba(0,245,160,0.1)", color: s.tier === "ELITE" ? "#c084fc" : s.tier === "PRO" ? "#f59e0b" : "#00f5a0", border: `1px solid ${s.tier === "ELITE" ? "rgba(192,132,252,0.3)" : s.tier === "PRO" ? "rgba(245,158,11,0.3)" : "rgba(0,245,160,0.3)"}`, borderRadius: 4, padding: "1px 6px", fontSize: 7, fontFamily: "monospace" }}>{s.tier}</span>
                      </div>
                      <div style={{ textAlign: "right" }}>
                        <div style={{ fontFamily: "'Orbitron',monospace", fontSize: 9, color: "#f59e0b" }}>₿ {s.btc}</div>
                        <div style={{ color: "rgba(255,255,255,0.2)", fontSize: 7, fontFamily: "monospace" }}>{s.time}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Right: workspace */}
              <div style={{ display: "flex", flexDirection: "column", overflow: "hidden" }}>
                {/* Agent header */}
                <div style={{ flexShrink: 0, padding: "14px 20px", borderBottom: "1px solid rgba(255,255,255,0.055)", background: `rgba(${hexToRgb(selectedAgent.color)},0.04)`, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
                    <span style={{ fontSize: 24, color: selectedAgent.color, textShadow: `0 0 16px ${selectedAgent.color}` }}>{selectedAgent.icon}</span>
                    <div>
                      <div style={{ fontFamily: "'Orbitron',monospace", fontSize: 16, fontWeight: 900, color: selectedAgent.color, letterSpacing: 3 }}>{selectedAgent.name}</div>
                      <div style={{ color: "rgba(255,255,255,0.35)", fontSize: 10, fontFamily: "monospace" }}>{selectedAgent.role} · {selectedAgent.dept}</div>
                    </div>
                  </div>
                  {runningAgents.has(selectedAgent.id) && (
                    <div style={{ display: "flex", alignItems: "center", gap: 8, color: selectedAgent.color, fontSize: 11, fontFamily: "monospace" }}>
                      <span style={{ width: 14, height: 14, border: `2px solid ${selectedAgent.color}`, borderTopColor: "transparent", borderRadius: "50%", display: "inline-block", animation: "spin 0.7s linear infinite" }} />
                      GENERATING...
                    </div>
                  )}
                </div>

                <div style={{ flex: 1, display: "grid", gridTemplateColumns: "1fr 1fr", overflow: "hidden" }}>
                  {/* Input panel */}
                  <div style={{ borderRight: "1px solid rgba(255,255,255,0.055)", padding: 18, display: "flex", flexDirection: "column", gap: 14, overflow: "hidden" }}>
                    <div style={{ color: "rgba(255,255,255,0.2)", fontSize: 8, fontFamily: "monospace", letterSpacing: 3 }}>TASK INPUT</div>
                    <textarea
                      value={prompt}
                      onChange={e => setPrompt(e.target.value)}
                      placeholder={`Describe what you need ${selectedAgent.name} to create...`}
                      style={{
                        flex: 1, background: "rgba(4,4,16,0.9)", border: `1px solid rgba(${hexToRgb(selectedAgent.color)},0.2)`, borderRadius: 12, padding: "14px 16px", color: "white", fontFamily: "monospace", fontSize: 12, lineHeight: 1.7, outline: "none", transition: "border-color 0.2s",
                      }}
                      onFocus={e => e.target.style.borderColor = selectedAgent.color}
                      onBlur={e => e.target.style.borderColor = `rgba(${hexToRgb(selectedAgent.color)},0.2)`}
                    />
                    {/* Quick prompts */}
                    <div>
                      <div style={{ color: "rgba(255,255,255,0.2)", fontSize: 8, fontFamily: "monospace", letterSpacing: 2, marginBottom: 8 }}>QUICK TASKS</div>
                      <div style={{ display: "flex", flexDirection: "column", gap: 5 }}>
                        {({
                          zara: ["Twitter ad for Pro tier", "Reddit native ad for r/algotrading", "Telegram promo blast", "Discord announcement copy"],
                          rex: ["DM for r/algotrading member", "Twitter DM for quant devs", "Discord server intro message", "Telegram group drop"],
                          nova2: ["Viral thread on Monte Carlo trading", "YouTube script: AI trading agents explained", "Blog post: Why traders use probability clouds", "Reddit educational post"],
                          atlas: ["Growth strategy for next 30 days", "Competitor analysis: trading software market", "Channel performance audit", "Pricing optimization analysis"],
                        }[selectedAgent.id] || []).map(q => (
                          <button key={q} onClick={() => setPrompt(q)} style={{ background: "rgba(4,4,16,0.7)", border: "1px solid rgba(255,255,255,0.06)", borderRadius: 7, padding: "7px 12px", cursor: "pointer", color: "rgba(255,255,255,0.45)", fontFamily: "monospace", fontSize: 10, textAlign: "left", transition: "all 0.15s" }}
                            onMouseEnter={e => { e.target.style.borderColor = `rgba(${hexToRgb(selectedAgent.color)},0.3)`; e.target.style.color = selectedAgent.color; }}
                            onMouseLeave={e => { e.target.style.borderColor = "rgba(255,255,255,0.06)"; e.target.style.color = "rgba(255,255,255,0.45)"; }}>
                            → {q}
                          </button>
                        ))}
                      </div>
                    </div>
                    <button onClick={runAgent} disabled={isLoading || !prompt.trim()} style={{
                      background: isLoading ? `rgba(${hexToRgb(selectedAgent.color)},0.1)` : `linear-gradient(135deg,${selectedAgent.color}cc,${selectedAgent.color}88)`,
                      border: `1px solid rgba(${hexToRgb(selectedAgent.color)},0.5)`,
                      borderRadius: 10, padding: "13px", cursor: isLoading ? "not-allowed" : "pointer",
                      color: isLoading ? selectedAgent.color : "#010108", fontFamily: "'Orbitron',monospace",
                      fontWeight: 900, fontSize: 11, letterSpacing: 2,
                      opacity: !prompt.trim() ? 0.4 : 1, transition: "all 0.2s",
                      display: "flex", alignItems: "center", justifyContent: "center", gap: 8,
                    }}>
                      {isLoading ? <><span style={{ width: 12, height: 12, border: `2px solid ${selectedAgent.color}`, borderTopColor: "transparent", borderRadius: "50%", animation: "spin 0.6s linear infinite", display: "inline-block" }} />GENERATING...</> : `▶ RUN ${selectedAgent.name}`}
                    </button>
                  </div>

                  {/* Output panel */}
                  <div style={{ padding: 18, display: "flex", flexDirection: "column", gap: 12, overflow: "hidden" }}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                      <div style={{ color: "rgba(255,255,255,0.2)", fontSize: 8, fontFamily: "monospace", letterSpacing: 3 }}>OUTPUT</div>
                      {output && <button onClick={() => { navigator.clipboard?.writeText(output); }} style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 5, padding: "3px 10px", cursor: "pointer", color: "rgba(255,255,255,0.35)", fontSize: 8, fontFamily: "monospace", letterSpacing: 1 }}>COPY</button>}
                    </div>
                    <div style={{ flex: 1, overflowY: "auto" }}>
                      {!output && !isLoading && (
                        <div style={{ height: "100%", display: "flex", alignItems: "center", justifyContent: "center", flexDirection: "column", gap: 10, opacity: 0.3 }}>
                          <span style={{ fontSize: 32, color: selectedAgent.color }}>{selectedAgent.icon}</span>
                          <span style={{ fontFamily: "monospace", fontSize: 10, color: "rgba(255,255,255,0.4)", letterSpacing: 2 }}>AWAITING TASK</span>
                        </div>
                      )}
                      {isLoading && (
                        <div style={{ height: "100%", display: "flex", alignItems: "center", justifyContent: "center", flexDirection: "column", gap: 12 }}>
                          <div style={{ width: 36, height: 36, border: `2px solid ${selectedAgent.color}`, borderTopColor: "transparent", borderRadius: "50%", animation: "spin 0.8s linear infinite" }} />
                          <div style={{ color: selectedAgent.color, fontFamily: "monospace", fontSize: 10, letterSpacing: 2, animation: "agentPulse 1.5s ease-in-out infinite" }}>{selectedAgent.name} IS THINKING...</div>
                        </div>
                      )}
                      {output && !isLoading && (
                        <div className="fadein">
                          <OutputRenderer output={output} agent={selectedAgent} />
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ANALYTICS TAB */}
          {activeTab === "analytics" && (
            <div style={{ padding: "20px 22px", overflowY: "auto", height: "100%", display: "flex", flexDirection: "column", gap: 18 }}>
              {/* KPI row */}
              <div style={{ display: "grid", gridTemplateColumns: "repeat(5,1fr)", gap: 14 }}>
                {[
                  { l: "IMPRESSIONS", v: metrics.impressions.toLocaleString(), c: "#00f5a0", delta: "+8.4%" },
                  { l: "CLICKS", v: metrics.clicks.toLocaleString(), c: "#f59e0b", delta: "+12.1%" },
                  { l: "CONVERSIONS", v: metrics.conversions, c: "#c084fc", delta: "+5.8%" },
                  { l: "CTR", v: metrics.ctr.toFixed(2) + "%", c: "#f43f5e", delta: "+0.3%" },
                  { l: "BTC REVENUE", v: (metrics.revenue).toFixed(4) + " ₿", c: "#f59e0b", delta: "+22%" },
                ].map(m => (
                  <div key={m.l} style={{ background: "rgba(6,6,20,0.85)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 14, padding: "16px 18px" }}>
                    <div style={{ color: "rgba(255,255,255,0.25)", fontSize: 8, fontFamily: "monospace", letterSpacing: 2, marginBottom: 8 }}>{m.l}</div>
                    <div style={{ fontFamily: "'Orbitron',monospace", fontSize: 18, fontWeight: 700, color: m.c }}>{m.v}</div>
                    <div style={{ color: "#00f5a0", fontSize: 9, fontFamily: "monospace", marginTop: 5 }}>{m.delta} vs last week</div>
                  </div>
                ))}
              </div>

              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 18 }}>
                {/* Funnel */}
                <div style={{ background: "rgba(6,6,20,0.85)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 14, padding: 20 }}>
                  <div style={{ color: "rgba(255,255,255,0.2)", fontSize: 8, fontFamily: "monospace", letterSpacing: 3, marginBottom: 16 }}>CONVERSION FUNNEL</div>
                  <FunnelChart data={metrics.funnelData} />
                </div>

                {/* Platform breakdown */}
                <div style={{ background: "rgba(6,6,20,0.85)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 14, padding: 20 }}>
                  <div style={{ color: "rgba(255,255,255,0.2)", fontSize: 8, fontFamily: "monospace", letterSpacing: 3, marginBottom: 16 }}>PLATFORM PERFORMANCE</div>
                  {[
                    { name: "Twitter/X", pct: 42, color: "#00f5a0", conv: 12 },
                    { name: "Reddit", pct: 28, color: "#f59e0b", conv: 7 },
                    { name: "Telegram", pct: 18, color: "#c084fc", conv: 3 },
                    { name: "Discord", pct: 8, color: "#f43f5e", conv: 1 },
                    { name: "YouTube", pct: 4, color: "#3b82f6", conv: 0 },
                  ].map(p => (
                    <div key={p.name} style={{ marginBottom: 12 }}>
                      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
                        <span style={{ color: "rgba(255,255,255,0.5)", fontSize: 11, fontFamily: "monospace" }}>{p.name}</span>
                        <span style={{ color: "rgba(255,255,255,0.4)", fontSize: 9, fontFamily: "monospace" }}>{p.pct}% · {p.conv} conv</span>
                      </div>
                      <div style={{ height: 4, background: "rgba(255,255,255,0.04)", borderRadius: 2 }}>
                        <div style={{ height: "100%", width: `${p.pct}%`, background: p.color, borderRadius: 2, boxShadow: `0 0 6px ${p.color}55` }} />
                      </div>
                    </div>
                  ))}
                </div>

                {/* Live sales + tier split */}
                <div style={{ background: "rgba(6,6,20,0.85)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 14, padding: 20 }}>
                  <div style={{ color: "rgba(255,255,255,0.2)", fontSize: 8, fontFamily: "monospace", letterSpacing: 3, marginBottom: 16, display: "flex", alignItems: "center", gap: 6 }}>
                    <GlowDot color="#00f5a0" pulse size={5} /> LIVE SALES FEED
                  </div>
                  {metrics.recentSales.map((s, i) => (
                    <div key={i} className="fadein" style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "8px 0", borderBottom: "1px solid rgba(255,255,255,0.04)" }}>
                      <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                        <span style={{ fontSize: 14 }}>{s.country}</span>
                        <span style={{ background: s.tier === "ELITE" ? "rgba(192,132,252,0.1)" : s.tier === "PRO" ? "rgba(245,158,11,0.1)" : "rgba(0,245,160,0.1)", color: s.tier === "ELITE" ? "#c084fc" : s.tier === "PRO" ? "#f59e0b" : "#00f5a0", border: `1px solid ${s.tier === "ELITE" ? "rgba(192,132,252,0.3)" : s.tier === "PRO" ? "rgba(245,158,11,0.3)" : "rgba(0,245,160,0.3)"}`, borderRadius: 4, padding: "2px 7px", fontSize: 8, fontFamily: "monospace" }}>{s.tier}</span>
                      </div>
                      <div style={{ textAlign: "right" }}>
                        <div style={{ fontFamily: "'Orbitron',monospace", fontSize: 11, color: "#f59e0b" }}>₿ {s.btc}</div>
                        <div style={{ color: "rgba(255,255,255,0.2)", fontSize: 9, fontFamily: "monospace" }}>{s.time}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Agent efficiency table */}
              <div style={{ background: "rgba(6,6,20,0.85)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 14, padding: 20 }}>
                <div style={{ color: "rgba(255,255,255,0.2)", fontSize: 8, fontFamily: "monospace", letterSpacing: 3, marginBottom: 16 }}>AGENT EFFICIENCY</div>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 14 }}>
                  {DEPT_AGENTS.map(a => (
                    <div key={a.id} style={{ background: `rgba(${hexToRgb(a.color)},0.05)`, border: `1px solid rgba(${hexToRgb(a.color)},0.15)`, borderRadius: 10, padding: "14px 16px" }}>
                      <div style={{ fontFamily: "'Orbitron',monospace", fontSize: 12, color: a.color, letterSpacing: 2, marginBottom: 8 }}>{a.name}</div>
                      <div style={{ color: "rgba(255,255,255,0.3)", fontSize: 9, fontFamily: "monospace", marginBottom: 8 }}>{a.dept}</div>
                      {[
                        { l: "TASKS RUN", v: Math.floor(Math.random() * 40 + 10) },
                        { l: "CONTENT PIECES", v: Math.floor(Math.random() * 80 + 20) },
                        { l: "EST. REACH", v: (Math.random() * 10 + 2).toFixed(1) + "K" },
                      ].map(s => (
                        <div key={s.l} style={{ display: "flex", justifyContent: "space-between", padding: "3px 0" }}>
                          <span style={{ fontSize: 8, color: "rgba(255,255,255,0.25)", fontFamily: "monospace" }}>{s.l}</span>
                          <span style={{ fontFamily: "'Orbitron',monospace", fontSize: 9, color: a.color }}>{s.v}</span>
                        </div>
                      ))}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* CAMPAIGNS TAB */}
          {activeTab === "campaigns" && (
            <div style={{ padding: "20px 22px", overflowY: "auto", height: "100%", display: "flex", flexDirection: "column", gap: 18 }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <div style={{ color: "rgba(255,255,255,0.2)", fontSize: 8, fontFamily: "monospace", letterSpacing: 3 }}>ACTIVE CAMPAIGNS · {metrics.campaigns.filter(c => c.status === "LIVE").length} LIVE</div>
                <button style={{ background: "rgba(0,245,160,0.08)", border: "1px solid rgba(0,245,160,0.25)", borderRadius: 8, padding: "7px 16px", cursor: "pointer", color: "#00f5a0", fontFamily: "'Orbitron',monospace", fontSize: 9, letterSpacing: 2 }}>+ NEW CAMPAIGN</button>
              </div>
              <div style={{ background: "rgba(6,6,20,0.85)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 14, padding: 20 }}>
                <CampaignTable campaigns={metrics.campaigns} />
              </div>
              {/* Campaign builder hint */}
              <div style={{ background: "rgba(245,158,11,0.04)", border: "1px solid rgba(245,158,11,0.12)", borderRadius: 14, padding: "18px 20px" }}>
                <div style={{ color: "#f59e0b", fontSize: 9, fontFamily: "monospace", letterSpacing: 2, marginBottom: 8 }}>⬡ PRO TIP · AUTO-GENERATE CAMPAIGN COPY</div>
                <div style={{ color: "rgba(255,255,255,0.4)", fontSize: 12, lineHeight: 1.7 }}>
                  Switch to the <strong style={{ color: "white" }}>Workspace tab</strong> and run <strong style={{ color: "#00f5a0" }}>ZARA</strong> to generate ad copy for any platform, or <strong style={{ color: "#f59e0b" }}>REX</strong> to generate outreach DMs. Enable <strong style={{ color: "#00f5a0" }}>AUTO MODE</strong> in the header to have all 4 agents generate content continuously.
                </div>
              </div>
            </div>
          )}

          {/* HISTORY TAB */}
          {activeTab === "history" && (
            <div style={{ padding: "20px 22px", overflowY: "auto", height: "100%", display: "flex", flexDirection: "column", gap: 12 }}>
              <div style={{ color: "rgba(255,255,255,0.2)", fontSize: 8, fontFamily: "monospace", letterSpacing: 3 }}>GENERATION HISTORY · {history.length} OUTPUTS</div>
              {history.length === 0 && (
                <div style={{ textAlign: "center", color: "rgba(255,255,255,0.15)", fontSize: 12, fontFamily: "monospace", marginTop: 60 }}>No history yet — run an agent to see outputs here</div>
              )}
              {history.map(h => (
                <div key={h.id} className="fadein" style={{ background: "rgba(6,6,20,0.85)", border: `1px solid rgba(${hexToRgb(h.agentColor)},0.15)`, borderRadius: 14, padding: 18, borderLeft: `3px solid ${h.agentColor}` }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
                    <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
                      <span style={{ fontFamily: "'Orbitron',monospace", fontSize: 11, color: h.agentColor, letterSpacing: 2 }}>{h.agentName}</span>
                      <span style={{ background: `rgba(${hexToRgb(h.agentColor)},0.08)`, border: `1px solid rgba(${hexToRgb(h.agentColor)},0.2)`, borderRadius: 4, padding: "1px 7px", fontSize: 7, color: h.agentColor, fontFamily: "monospace" }}>{h.dept}</span>
                    </div>
                    <span style={{ color: "rgba(255,255,255,0.2)", fontSize: 9, fontFamily: "monospace" }}>{h.time}</span>
                  </div>
                  <div style={{ color: "rgba(255,255,255,0.3)", fontSize: 10, fontFamily: "monospace", marginBottom: 12, fontStyle: "italic" }}>"{h.prompt}"</div>
                  <div style={{ maxHeight: 200, overflowY: "auto" }}>
                    <OutputRenderer output={h.output} agent={h.agent} />
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </>
  );
}
