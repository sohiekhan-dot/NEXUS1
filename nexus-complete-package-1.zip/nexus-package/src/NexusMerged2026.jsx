import { useState, useEffect, useRef } from "react";

// ─── REAL 2026 MARKET DATA ────────────────────────────────────────────────────
const ASSETS = [
  { sym:"BTC",  name:"Bitcoin",    price:78244, vol:0.62, color:"#F7931A", cat:"Crypto"   },
  { sym:"ETH",  name:"Ethereum",   price:2295,  vol:0.71, color:"#627EEA", cat:"Crypto"   },
  { sym:"SOL",  name:"Solana",     price:83.74, vol:0.88, color:"#9945FF", cat:"Crypto"   },
  { sym:"XRP",  name:"XRP",        price:1.39,  vol:0.82, color:"#00AAE4", cat:"Crypto"   },
  { sym:"TAO",  name:"Bittensor",  price:312,   vol:1.15, color:"#7FBA00", cat:"AI"       },
  { sym:"ONDO", name:"Ondo",       price:0.89,  vol:0.95, color:"#00C2FF", cat:"RWA"      },
  { sym:"SPY",  name:"S&P 500",    price:542,   vol:0.16, color:"#10B981", cat:"Equities" },
  { sym:"GOLD", name:"Gold",       price:3245,  vol:0.13, color:"#F59E0B", cat:"Commodity"},
];

const MARKET_REGIME = {
  fearGreed: 26, btcDominance: 58.5, marketCap: 2683,
  etfInflow: 630, funding: -0.012, oi: 28.4,
};

// ─── PROP FIRMS ───────────────────────────────────────────────────────────────
const PROP_FIRMS = [
  { id:"ftmo",  name:"FTMO",                color:"#00D4FF", logo:"F",   split:90, profitTarget:10, maxDD:10, dailyDD:5,  fee:540,  size:100000, minDays:10, freq:"Monthly",    instruments:["Forex","Crypto","Indices"],  broker:"MT5",      url:"ftmo.com"               },
  { id:"apex",  name:"Apex Trader Funding", color:"#FF6B35", logo:"A",   split:90, profitTarget:6,  maxDD:6,  dailyDD:3,  fee:167,  size:100000, minDays:7,  freq:"Bi-weekly",  instruments:["Futures (CME)"],             broker:"Rithmic",  url:"apextraderfunding.com"  },
  { id:"topstep",name:"TopStep",            color:"#10B981", logo:"T",   split:90, profitTarget:6,  maxDD:4,  dailyDD:2,  fee:325,  size:100000, minDays:5,  freq:"Weekly",     instruments:["Futures (CME Group)"],       broker:"Rithmic",  url:"topstep.com"            },
  { id:"e8",    name:"E8 Funding",          color:"#A78BFA", logo:"E8",  split:80, profitTarget:8,  maxDD:8,  dailyDD:4,  fee:588,  size:100000, minDays:3,  freq:"Monthly",    instruments:["Forex","Crypto","Metals"],   broker:"MT5",      url:"e8funding.com"          },
];

// ─── MARKET CONNECTIONS (public free APIs) ────────────────────────────────────
const CONNECTIONS = [
  { id:"binance",  name:"Binance",        type:"Exchange",  status:"connected", color:"#F0B90B", logo:"B",  api:"wss://stream.binance.com:9443/ws", note:"WebSocket price feeds — no key needed for public data" },
  { id:"coinbase", name:"Coinbase Adv",   type:"Exchange",  status:"connected", color:"#0052FF", logo:"C",  api:"wss://advanced-trade-ws.coinbase.com", note:"Real-time order book — public feed" },
  { id:"bybit",    name:"Bybit",          type:"Exchange",  status:"connected", color:"#F7A600", logo:"BY", api:"wss://stream.bybit.com/v5/public", note:"Perp funding rates — public WebSocket" },
  { id:"alpaca",   name:"Alpaca Markets", type:"Broker",    status:"key_needed",color:"#FFD700", logo:"AP", api:"wss://stream.data.alpaca.markets/v2", note:"US stocks/ETFs — free key at alpaca.markets" },
  { id:"polygon",  name:"Polygon.io",     type:"Data",      status:"key_needed",color:"#7C3AED", logo:"P",  api:"wss://socket.polygon.io", note:"Stocks, forex, crypto — free tier available" },
  { id:"ftmo_conn",name:"FTMO MT5",       type:"PropFirm",  status:"key_needed",color:"#00D4FF", logo:"F",  api:"MT5 Server",  note:"Credentials emailed after evaluation pass" },
  { id:"apex_conn",name:"Apex Rithmic",   type:"PropFirm",  status:"key_needed",color:"#FF6B35", logo:"A",  api:"Rithmic API", note:"Login from Apex dashboard after funded" },
];

// ─── PRICE ENGINE (GBM) ───────────────────────────────────────────────────────
class PriceEngine {
  constructor(a) {
    this.a = a; this.price = a.price;
    this.sigma = a.vol / Math.sqrt(252 * 390);
    this.history = Array.from({length:80},(_,i)=>a.price*(1+(Math.random()-0.5)*a.vol*0.06*(i/80)));
    this.vol = a.vol;
  }
  tick() {
    const z = this._rn();
    this.price = Math.max(this.price * Math.exp(this.sigma * z), 0.001);
    this.history.push(this.price);
    if (this.history.length > 80) this.history.shift();
  }
  _rn() { let u=0,v=0; while(!u)u=Math.random(); while(!v)v=Math.random(); return Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*v); }
  rsi(p=14) {
    const h=this.history.slice(-(p+1)); if(h.length<2) return 50;
    let g=0,l=0; for(let i=1;i<h.length;i++){const d=h[i]-h[i-1];d>0?g+=d:l+=Math.abs(d);}
    return 100-100/(1+g/(l||1e-9));
  }
  bb(p=20) {
    const h=this.history.slice(-p); const m=h.reduce((a,b)=>a+b,0)/h.length;
    const s=Math.sqrt(h.reduce((a,b)=>a+(b-m)**2,0)/h.length);
    return {upper:m+2*s,lower:m-2*s,mid:m,pct:((this.price-(m-2*s))/(4*s))*100};
  }
  probCloud(steps=24) {
    const paths=Array.from({length:180},()=>{
      let p=this.price;
      return Array.from({length:steps+1},(_,i)=>{if(i===0)return p;p=p*Math.exp(this.sigma*this._rn());return p;});
    });
    return Array.from({length:steps+1},(_,i)=>{
      const v=paths.map(p=>p[i]).sort((a,b)=>a-b),n=v.length;
      return {p5:v[Math.floor(n*.05)],p25:v[Math.floor(n*.25)],p50:v[Math.floor(n*.5)],p75:v[Math.floor(n*.75)],p95:v[Math.floor(n*.95)]};
    });
  }
  get chg()  { const p=this.history[this.history.length-2]||this.price; return (this.price-p)/p*100; }
  get chg24(){ const p=this.history[0]||this.price; return (this.price-p)/p*100; }
}

const ENG = {}; ASSETS.forEach(a=>{ENG[a.sym]=new PriceEngine(a);});

// ─── HELPERS ──────────────────────────────────────────────────────────────────
const fmt$  = p => p>=10000?"$"+p.toLocaleString("en",{maximumFractionDigits:0}):p>=100?"$"+p.toFixed(2):p>=1?"$"+p.toFixed(3):"$"+p.toFixed(4);
const fmtPct= v => (v>=0?"+":"")+v.toFixed(2)+"%";
const fmtK  = v => "$"+(v/1000).toFixed(0)+"K";
const rgb   = h => { const r=/^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(h); return r?`${parseInt(r[1],16)},${parseInt(r[2],16)},${parseInt(r[3],16)}`:"255,255,255"; };

// ─── SPARKLINE ────────────────────────────────────────────────────────────────
function Spark({ data, color }) {
  const d=data.slice(-25); const mn=Math.min(...d),mx=Math.max(...d),rng=mx-mn||1;
  const pts=d.map((v,i,a)=>`${(i/(a.length-1))*72},${24-((v-mn)/rng)*20-2}`).join(" ");
  return <svg width="72" height="24" style={{flexShrink:0}}><polygon points={`0,24 ${pts} 72,24`} fill={`rgba(${rgb(color)},0.15)`}/><polyline points={pts} fill="none" stroke={color} strokeWidth="1.8"/></svg>;
}

// ─── QUANTUM CHART ────────────────────────────────────────────────────────────
function QuantumChart({ symKey, h=180 }) {
  const ref=useRef(null); const [t,setT]=useState(0);
  useEffect(()=>{const iv=setInterval(()=>setT(x=>x+1),700);return()=>clearInterval(iv);},[]);
  useEffect(()=>{
    const c=ref.current; if(!c)return;
    const dpr=window.devicePixelRatio||1,W=c.offsetWidth,H=c.offsetHeight;
    c.width=W*dpr;c.height=H*dpr;
    const ctx=c.getContext("2d");ctx.scale(dpr,dpr);
    const eng=ENG[symKey];if(!eng)return;
    const hist=eng.history,cloud=eng.probCloud(20);
    const allP=[...hist,...cloud.map(b=>b.p95),...cloud.map(b=>b.p5)];
    const mn=Math.min(...allP)*.998,mx=Math.max(...allP)*1.002,rng=mx-mn||1;
    const totPts=hist.length+cloud.length-1;
    const toX=i=>(i/(totPts-1))*(W-46);
    const toY=v=>H-4-((v-mn)/rng)*(H-8);
    const up=hist[hist.length-1]>=hist[0],lc=up?"#00C97A":"#F43F5E";
    ctx.clearRect(0,0,W,H);
    // grid
    for(let i=0;i<=4;i++){const y=4+(i/4)*(H-8);ctx.strokeStyle="rgba(255,255,255,0.035)";ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(W-46,y);ctx.stroke();const pv=mx-(i/4)*rng;ctx.fillStyle="rgba(255,255,255,0.22)";ctx.font=`9px monospace`;ctx.fillText(fmt$(pv).slice(1),W-44,y+3);}
    // cloud
    const cs=hist.length-1;
    [[".p5",".p95",.05],[".p25",".p75",.13]].forEach(([lo,hi,a])=>{
      ctx.beginPath();
      cloud.forEach((b,i)=>{const x=toX(cs+i),y=toY(b[hi.slice(1)]);i===0?ctx.moveTo(x,y):ctx.lineTo(x,y);});
      [...cloud].reverse().forEach((b,i)=>{ctx.lineTo(toX(cs+cloud.length-1-i),toY(b[lo.slice(1)]));});
      ctx.closePath();const g=ctx.createLinearGradient(toX(cs),0,W-46,0);g.addColorStop(0,`rgba(${rgb(lc)},${a*2})`);g.addColorStop(1,`rgba(${rgb(lc)},${a*.3})`);ctx.fillStyle=g;ctx.fill();
    });
    ctx.beginPath();cloud.forEach((b,i)=>{const x=toX(cs+i),y=toY(b.p50);i===0?ctx.moveTo(x,y):ctx.lineTo(x,y);});ctx.strokeStyle=`rgba(${rgb(lc)},.4)`;ctx.lineWidth=1.2;ctx.setLineDash([3,4]);ctx.stroke();ctx.setLineDash([]);
    // fill
    ctx.beginPath();hist.forEach((p,i)=>{const x=toX(i),y=toY(p);i===0?ctx.moveTo(x,y):ctx.lineTo(x,y);});ctx.lineTo(toX(hist.length-1),H);ctx.lineTo(toX(0),H);ctx.closePath();const fg=ctx.createLinearGradient(0,0,0,H);fg.addColorStop(0,`rgba(${rgb(lc)},.18)`);fg.addColorStop(1,"rgba(0,0,0,0)");ctx.fillStyle=fg;ctx.fill();
    // line
    ctx.beginPath();hist.forEach((p,i)=>{const x=toX(i),y=toY(p);i===0?ctx.moveTo(x,y):ctx.lineTo(x,y);});ctx.strokeStyle=lc;ctx.lineWidth=2;ctx.shadowColor=lc;ctx.shadowBlur=7;ctx.stroke();ctx.shadowBlur=0;
    // now line + dot
    const nx=toX(hist.length-1),ly=toY(hist[hist.length-1]);
    ctx.beginPath();ctx.setLineDash([2,3]);ctx.moveTo(nx,0);ctx.lineTo(nx,H);ctx.strokeStyle="rgba(255,255,255,0.12)";ctx.lineWidth=1;ctx.stroke();ctx.setLineDash([]);
    ctx.beginPath();ctx.arc(nx,ly,4,0,Math.PI*2);ctx.fillStyle=lc;ctx.shadowColor=lc;ctx.shadowBlur=12;ctx.fill();ctx.shadowBlur=0;
    ctx.fillStyle=`rgba(${rgb(lc)},.45)`;ctx.font="8px monospace";ctx.fillText("◈ PROB CLOUD →",nx+4,H-5);
  },[t,symKey]);
  return <canvas ref={ref} style={{width:"100%",height:h,display:"block"}}/>;
}

// ─── PROGRESS BAR ─────────────────────────────────────────────────────────────
function Bar({ pct, color, h=8 }) {
  const p=Math.max(0,Math.min(100,pct));
  return <div style={{height:h,background:"rgba(255,255,255,0.06)",borderRadius:h/2,overflow:"hidden"}}><div style={{height:"100%",width:`${p}%`,background:color,borderRadius:h/2,boxShadow:`0 0 8px rgba(${rgb(color)},.4)`,transition:"width .6s ease"}}/></div>;
}

// ─── ORDER MODAL ──────────────────────────────────────────────────────────────
function OrderModal({ asset, onClose }) {
  const [side,setSide]=useState("BUY");
  const [type,setType]=useState("MARKET");
  const [qty,setQty]=useState("");
  const [done,setDone]=useState(false);
  const eng=ENG[asset.sym];
  const total=parseFloat(qty||0)*eng.price;
  const ac=side==="BUY"?"#00C97A":"#F43F5E";

  function submit(){
    if(!qty||parseFloat(qty)<=0)return;
    setDone(true);
    setTimeout(()=>{setDone(false);onClose();},1800);
  }

  return (
    <div onClick={e=>{if(e.target===e.currentTarget)onClose();}} style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.75)",backdropFilter:"blur(8px)",display:"flex",alignItems:"center",justifyContent:"center",zIndex:200}}>
      <div style={{background:"#161B22",border:`1px solid rgba(${rgb(ac)},.35)`,borderRadius:16,padding:24,width:320,position:"relative"}}>
        <div style={{position:"absolute",top:0,left:0,right:0,height:2,background:`linear-gradient(90deg,transparent,${ac},transparent)`,borderRadius:"16px 16px 0 0"}}/>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:18}}>
          <div>
            <div style={{fontFamily:"'Orbitron',monospace",fontWeight:700,fontSize:15,color:"white",letterSpacing:2}}>{asset.sym}</div>
            <div style={{color:"rgba(255,255,255,0.35)",fontSize:11,marginTop:1}}>{fmt$(eng.price)} · {fmtPct(eng.chg24)}</div>
          </div>
          <button onClick={onClose} style={{background:"rgba(255,255,255,0.05)",border:"1px solid rgba(255,255,255,0.1)",borderRadius:8,width:28,height:28,cursor:"pointer",color:"rgba(255,255,255,0.4)",fontSize:14}}>×</button>
        </div>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:6,marginBottom:14}}>
          {["BUY","SELL"].map(s=><button key={s} onClick={()=>setSide(s)} style={{background:side===s?(s==="BUY"?"rgba(0,201,122,.15)":"rgba(244,63,94,.15)"):"rgba(255,255,255,.04)",border:`1px solid ${side===s?(s==="BUY"?"rgba(0,201,122,.5)":"rgba(244,63,94,.5)"):"rgba(255,255,255,.08)"}`,borderRadius:8,padding:"9px",cursor:"pointer",color:side===s?(s==="BUY"?"#00C97A":"#F43F5E"):"rgba(255,255,255,.35)",fontFamily:"'Orbitron',monospace",fontSize:11,fontWeight:700,letterSpacing:2}}>{s}</button>)}
        </div>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:6,marginBottom:14}}>
          {["MARKET","LIMIT"].map(t2=><button key={t2} onClick={()=>setType(t2)} style={{background:type===t2?"rgba(255,255,255,.08)":"rgba(255,255,255,.03)",border:`1px solid ${type===t2?"rgba(255,255,255,.2)":"rgba(255,255,255,.06)"}`,borderRadius:7,padding:"6px",cursor:"pointer",color:type===t2?"white":"rgba(255,255,255,.3)",fontFamily:"monospace",fontSize:10,letterSpacing:1}}>{t2}</button>)}
        </div>
        <div style={{marginBottom:14}}>
          <div style={{color:"rgba(255,255,255,.35)",fontSize:9,fontFamily:"monospace",letterSpacing:2,marginBottom:5}}>QUANTITY ({asset.sym})</div>
          <input type="number" value={qty} onChange={e=>setQty(e.target.value)} placeholder="0.00" style={{width:"100%",background:"rgba(255,255,255,.05)",border:`1px solid rgba(${rgb(ac)},.25)`,borderRadius:8,padding:"10px 12px",color:"white",fontFamily:"'Orbitron',monospace",fontSize:16,fontWeight:700,outline:"none"}}/>
          <div style={{display:"flex",gap:5,marginTop:7}}>
            {["25%","50%","75%","MAX"].map(p=><button key={p} onClick={()=>setQty(((p==="MAX"?1:parseFloat(p)/100)*5000/eng.price).toFixed(4))} style={{flex:1,background:"rgba(255,255,255,.04)",border:"1px solid rgba(255,255,255,.08)",borderRadius:6,padding:"4px",cursor:"pointer",color:"rgba(255,255,255,.35)",fontSize:9,fontFamily:"monospace"}}>{p}</button>)}
          </div>
        </div>
        {total>0&&<div style={{background:"rgba(255,255,255,.04)",borderRadius:8,padding:"9px 12px",marginBottom:12,display:"flex",justifyContent:"space-between"}}><span style={{color:"rgba(255,255,255,.35)",fontSize:11}}>Total</span><span style={{fontFamily:"'Orbitron',monospace",fontSize:12,color:"white",fontWeight:600}}>${total.toLocaleString("en",{maximumFractionDigits:2})}</span></div>}
        <button onClick={submit} disabled={!qty||parseFloat(qty)<=0} style={{width:"100%",background:done?"rgba(0,201,122,.2)":`linear-gradient(135deg,${side==="BUY"?"#00C97A,#008844":"#F43F5E,#BE123C"})`,border:"none",borderRadius:10,padding:"13px",cursor:!qty||parseFloat(qty)<=0?"not-allowed":"pointer",color:done?"#00C97A":"#0D1117",fontFamily:"'Orbitron',monospace",fontWeight:900,fontSize:11,letterSpacing:3,opacity:!qty||parseFloat(qty)<=0?.4:1,transition:"all .2s",display:"flex",alignItems:"center",justifyContent:"center",gap:8}}>
          {done?<><span style={{width:12,height:12,border:`2px solid #00C97A`,borderTopColor:"transparent",borderRadius:"50%",display:"inline-block",animation:"spin .6s linear infinite"}}/>EXECUTING...</>:`${side} ${asset.sym}`}
        </button>
      </div>
    </div>
  );
}

// ─── EVAL PROGRESS CARD ───────────────────────────────────────────────────────
function EvalCard({ ev, firm }) {
  const profit=ev.currentBalance-ev.startBalance;
  const profitPct=(profit/ev.startBalance)*100;
  const toTarget=((ev.currentBalance-ev.startBalance)/(ev.profitTarget-ev.startBalance))*100;
  const ddUsed=((ev.hwm-ev.currentBalance)/ev.startBalance)*100;
  const ddPct=(ddUsed/firm.maxDD)*100;
  const statusColor=ev.status==="active"?"#00D4FF":ev.status==="passed"?"#10B981":"#F43F5E";

  return (
    <div style={{background:"#1C2333",border:`1px solid rgba(${rgb(firm.color)},.2)`,borderRadius:14,padding:"16px 18px",position:"relative",overflow:"hidden"}}>
      <div style={{position:"absolute",top:0,left:0,right:0,height:2,background:`linear-gradient(90deg,transparent,${firm.color},transparent)`}}/>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:12}}>
        <div style={{display:"flex",gap:9,alignItems:"center"}}>
          <div style={{width:32,height:32,borderRadius:8,background:`rgba(${rgb(firm.color)},.12)`,border:`1px solid rgba(${rgb(firm.color)},.3)`,display:"flex",alignItems:"center",justifyContent:"center"}}>
            <span style={{fontFamily:"'Orbitron',monospace",fontSize:8,fontWeight:700,color:firm.color}}>{firm.logo}</span>
          </div>
          <div>
            <div style={{fontWeight:600,fontSize:13,color:"white"}}>{firm.name}</div>
            <div style={{color:"rgba(255,255,255,.35)",fontSize:10,marginTop:1}}>{fmtK(ev.accountSize)} · Phase {ev.phase}</div>
          </div>
        </div>
        <span style={{background:`rgba(${rgb(statusColor)},.1)`,border:`1px solid rgba(${rgb(statusColor)},.35)`,borderRadius:20,padding:"2px 9px",fontSize:8,color:statusColor,fontFamily:"monospace",letterSpacing:1}}>{ev.status.toUpperCase()}</span>
      </div>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginBottom:12}}>
        <div style={{background:"rgba(0,0,0,.25)",borderRadius:8,padding:"8px 10px"}}>
          <div style={{color:"rgba(255,255,255,.3)",fontSize:9,marginBottom:3}}>Balance</div>
          <div style={{fontFamily:"'Orbitron',monospace",fontSize:13,fontWeight:700,color:"white"}}>{fmt$(ev.currentBalance)}</div>
        </div>
        <div style={{background:"rgba(0,0,0,.25)",borderRadius:8,padding:"8px 10px"}}>
          <div style={{color:"rgba(255,255,255,.3)",fontSize:9,marginBottom:3}}>P&L</div>
          <div style={{fontFamily:"'Orbitron',monospace",fontSize:13,fontWeight:700,color:profit>=0?"#00C97A":"#F43F5E"}}>{profit>=0?"+":""}{fmt$(profit)}</div>
        </div>
      </div>
      <div style={{display:"flex",flexDirection:"column",gap:8}}>
        <div>
          <div style={{display:"flex",justifyContent:"space-between",marginBottom:4}}>
            <span style={{color:"rgba(255,255,255,.35)",fontSize:10}}>Profit Target {firm.profitTarget}%</span>
            <span style={{fontFamily:"'Orbitron',monospace",fontSize:10,color:firm.color}}>{profitPct.toFixed(2)}% / {firm.profitTarget}%</span>
          </div>
          <Bar pct={toTarget} color={toTarget>=100?"#10B981":firm.color} h={8}/>
        </div>
        <div>
          <div style={{display:"flex",justifyContent:"space-between",marginBottom:4}}>
            <span style={{color:"rgba(255,255,255,.35)",fontSize:10}}>Drawdown Used</span>
            <span style={{fontFamily:"'Orbitron',monospace",fontSize:10,color:ddPct>70?"#F43F5E":ddPct>50?"#F59E0B":"#10B981"}}>{ddUsed.toFixed(2)}% / {firm.maxDD}%</span>
          </div>
          <Bar pct={ddPct} color={ddPct>70?"#F43F5E":ddPct>50?"#F59E0B":"#10B981"} h={6}/>
        </div>
      </div>
      <div style={{marginTop:10,paddingTop:10,borderTop:"1px solid rgba(255,255,255,.05)",display:"flex",justifyContent:"space-between"}}>
        <span style={{color:"rgba(255,255,255,.3)",fontSize:10}}>Trading Days</span>
        <span style={{fontFamily:"'Orbitron',monospace",fontSize:10,color:ev.days>=firm.minDays?"#10B981":"#F59E0B",fontWeight:600}}>{ev.days}/{firm.minDays} {ev.days>=firm.minDays?"✓":""}</span>
      </div>
    </div>
  );
}

// ─── CONNECTION STATUS ────────────────────────────────────────────────────────
function ConnCard({ conn, onToggle }) {
  const statusColor = conn.status==="connected"?"#00C97A":conn.status==="key_needed"?"#F59E0B":"#F43F5E";
  const statusLabel = conn.status==="connected"?"LIVE":conn.status==="key_needed"?"NEEDS KEY":"OFFLINE";
  return (
    <div style={{background:"#1C2333",border:`1px solid rgba(${rgb(conn.color)},.15)`,borderRadius:12,padding:"14px 16px",transition:"all .2s"}}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:8}}>
        <div style={{display:"flex",gap:9,alignItems:"center"}}>
          <div style={{width:32,height:32,borderRadius:8,background:`rgba(${rgb(conn.color)},.12)`,border:`1px solid rgba(${rgb(conn.color)},.3)`,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>
            <span style={{fontFamily:"'Orbitron',monospace",fontSize:8,fontWeight:700,color:conn.color}}>{conn.logo}</span>
          </div>
          <div>
            <div style={{fontWeight:600,fontSize:13,color:"white"}}>{conn.name}</div>
            <div style={{color:"rgba(255,255,255,.3)",fontSize:9,marginTop:1,fontFamily:"monospace"}}>{conn.type}</div>
          </div>
        </div>
        <div style={{display:"flex",alignItems:"center",gap:5,background:`rgba(${rgb(statusColor)},.08)`,border:`1px solid rgba(${rgb(statusColor)},.25)`,borderRadius:20,padding:"2px 8px"}}>
          <div style={{width:5,height:5,borderRadius:"50%",background:statusColor,animation:conn.status==="connected"?"blink 1.5s infinite":"none"}}/>
          <span style={{fontSize:8,color:statusColor,fontFamily:"monospace",letterSpacing:.5}}>{statusLabel}</span>
        </div>
      </div>
      <div style={{color:"rgba(255,255,255,.3)",fontSize:10,marginBottom:10,lineHeight:1.4}}>{conn.note}</div>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
        <span style={{color:"rgba(255,255,255,.2)",fontSize:9,fontFamily:"monospace"}}>{conn.api}</span>
        {conn.status==="key_needed"&&<button onClick={()=>onToggle(conn.id)} style={{background:`rgba(${rgb(conn.color)},.1)`,border:`1px solid rgba(${rgb(conn.color)},.3)`,borderRadius:7,padding:"5px 12px",cursor:"pointer",color:conn.color,fontSize:11,fontWeight:600}}>Connect</button>}
        {conn.status==="connected"&&<span style={{color:"#00C97A",fontSize:11,fontWeight:600}}>✓ Active</span>}
      </div>
    </div>
  );
}

// ─── MAIN APP ─────────────────────────────────────────────────────────────────
export default function NexusMerged() {
  const [tick,setTick]             = useState(0);
  const [tab,setTab]               = useState("markets");
  const [selSym,setSelSym]         = useState("BTC");
  const [orderAsset,setOrderAsset] = useState(null);
  const [apiKey,setApiKey]         = useState({});
  const [connections,setConns]     = useState(CONNECTIONS);
  const [keyModal,setKeyModal]     = useState(null);
  const [keyInput,setKeyInput]     = useState("");

  // Drive engines
  useEffect(()=>{ const iv=setInterval(()=>{ Object.values(ENG).forEach(e=>e.tick()); setTick(t=>t+1); },700); return()=>clearInterval(iv); },[]);

  // Simulated evaluations
  const [evals,setEvals] = useState([
    { id:"e1", firmId:"ftmo",   accountSize:100000, phase:1, status:"active", currentBalance:105840, startBalance:100000, hwm:106200, profitTarget:110000, maxDrawdown:90000, days:14, minDays:10, trades:47, winRate:62,
      tradesToday:[{sym:"EURUSD",side:"BUY",pnl:340,t:"09:14"},{sym:"BTCUSD",side:"SELL",pnl:-120,t:"10:31"},{sym:"GOLD",side:"BUY",pnl:580,t:"13:45"}] },
    { id:"e2", firmId:"apex",   accountSize:50000,  phase:1, status:"active", currentBalance:51200,  startBalance:50000,  hwm:51800,  profitTarget:53000,  maxDrawdown:47000, days:7,  minDays:7,  trades:23, winRate:57,
      tradesToday:[{sym:"ES",side:"BUY",pnl:225,t:"09:32"},{sym:"NQ",side:"SELL",pnl:180,t:"11:04"}] },
  ]);

  useEffect(()=>{
    const iv=setInterval(()=>{
      setEvals(prev=>prev.map(ev=>{
        if(ev.status!=="active")return ev;
        const delta=(Math.random()-.42)*350;
        const nb=Math.max(ev.maxDrawdown+100,ev.currentBalance+delta);
        const nhwm=Math.max(ev.hwm,nb);
        const status=nb>=ev.profitTarget?"passed":nb<=ev.maxDrawdown?"breached":"active";
        const doTrade=Math.random()<.12;
        const symMap={e1:["EURUSD","GBPUSD","BTCUSD","GOLD","SPX500"],e2:["ES","NQ","CL","GC","YM"]};
        const tSym=(symMap[ev.id]||["EURUSD"])[Math.floor(Math.random()*5)];
        const newTrade=doTrade?{sym:tSym,side:Math.random()>.5?"BUY":"SELL",pnl:(Math.random()>.58?1:-1)*(50+Math.random()*380),t:new Date().toLocaleTimeString("en",{hour:"2-digit",minute:"2-digit"})}:null;
        return {...ev,currentBalance:nb,hwm:nhwm,status,tradesToday:newTrade?[newTrade,...ev.tradesToday.slice(0,9)]:ev.tradesToday,trades:ev.trades+(doTrade?1:0)};
      }));
    },1500);
    return()=>clearInterval(iv);
  },[]);

  const selEng = ENG[selSym];
  const totalEvalPnl = evals.reduce((s,e)=>s+(e.currentBalance-e.startBalance),0);
  const portfolioTotal = 285000 + totalEvalPnl;

  function connectKey(id) {
    if (!keyInput.trim()) return;
    setConns(prev=>prev.map(c=>c.id===id?{...c,status:"connected"}:c));
    setKeyModal(null); setKeyInput("");
  }

  const TABS = [
    {id:"markets",  label:"Markets",     icon:"📈"},
    {id:"prop",     label:"Prop Firms",  icon:"🎯"},
    {id:"connect",  label:"Connections", icon:"🔌"},
  ];

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@600;700;900&family=Inter:wght@400;500;600;700&display=swap');
        *{box-sizing:border-box;margin:0;padding:0;}
        html,body{height:100%;background:#0D1117;}
        ::-webkit-scrollbar{width:4px;} ::-webkit-scrollbar-thumb{background:rgba(255,255,255,.1);border-radius:2px;}
        @keyframes blink{0%,100%{opacity:1}50%{opacity:.3}}
        @keyframes fadeIn{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:translateY(0)}}
        @keyframes spin{to{transform:rotate(360deg)}}
        @keyframes tradeIn{from{opacity:0;transform:translateX(6px)}to{opacity:1;transform:translateX(0)}}
        .fade{animation:fadeIn .3s ease both;}
        .trade{animation:tradeIn .25s ease both;}
        button:active{opacity:.8;}
        input[type=number]{-moz-appearance:textfield;}
        input::-webkit-outer-spin-button,input::-webkit-inner-spin-button{-webkit-appearance:none;}
        input::placeholder{color:rgba(255,255,255,.2);}
      `}</style>

      {orderAsset && <OrderModal asset={orderAsset} onClose={()=>setOrderAsset(null)}/>}

      {/* API key modal */}
      {keyModal && (
        <div onClick={e=>{if(e.target===e.currentTarget)setKeyModal(null);}} style={{position:"fixed",inset:0,background:"rgba(0,0,0,.8)",backdropFilter:"blur(8px)",display:"flex",alignItems:"center",justifyContent:"center",zIndex:200}}>
          <div style={{background:"#161B22",border:"1px solid rgba(255,255,255,.12)",borderRadius:16,padding:28,width:400}}>
            <div style={{fontWeight:600,fontSize:15,marginBottom:6}}>Connect {connections.find(c=>c.id===keyModal)?.name}</div>
            <div style={{color:"rgba(255,255,255,.4)",fontSize:12,marginBottom:18,lineHeight:1.5}}>{connections.find(c=>c.id===keyModal)?.note}</div>
            <div style={{color:"rgba(255,255,255,.45)",fontSize:11,marginBottom:7,fontWeight:500}}>API Key</div>
            <input value={keyInput} onChange={e=>setKeyInput(e.target.value)} placeholder="Paste your API key here..." style={{width:"100%",background:"rgba(255,255,255,.05)",border:"1px solid rgba(255,255,255,.12)",borderRadius:9,padding:"11px 14px",color:"white",fontFamily:"monospace",fontSize:12,outline:"none",marginBottom:16}}/>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
              <button onClick={()=>{setKeyModal(null);setKeyInput("");}} style={{background:"rgba(255,255,255,.05)",border:"1px solid rgba(255,255,255,.1)",borderRadius:9,padding:"11px",cursor:"pointer",color:"rgba(255,255,255,.45)",fontWeight:600,fontSize:13}}>Cancel</button>
              <button onClick={()=>connectKey(keyModal)} style={{background:"linear-gradient(135deg,#00C97A,#008844)",border:"none",borderRadius:9,padding:"11px",cursor:"pointer",color:"#0D1117",fontWeight:700,fontSize:13}}>Connect ✓</button>
            </div>
          </div>
        </div>
      )}

      <div style={{minHeight:"100vh",background:"#0D1117",color:"white",fontFamily:"'Inter',sans-serif",display:"flex",flexDirection:"column"}}>

        {/* ── HEADER ── */}
        <div style={{background:"#161B22",borderBottom:"1px solid rgba(255,255,255,.08)",padding:"0 24px",height:56,display:"flex",alignItems:"center",justifyContent:"space-between",flexShrink:0}}>
          <div style={{display:"flex",alignItems:"center",gap:12}}>
            <div style={{width:32,height:32,background:"linear-gradient(135deg,#00C97A,#005F38)",borderRadius:9,display:"flex",alignItems:"center",justifyContent:"center",fontSize:16,boxShadow:"0 0 16px rgba(0,201,122,.3)"}}>◈</div>
            <div>
              <div style={{fontFamily:"'Orbitron',monospace",fontWeight:700,fontSize:13,color:"#00C97A",letterSpacing:3}}>NEXUS</div>
              <div style={{fontSize:9,color:"rgba(255,255,255,.25)",letterSpacing:2,fontFamily:"monospace"}}>QUANTUM TRADER · 2026</div>
            </div>
          </div>

          {/* Tabs */}
          <div style={{display:"flex",gap:2,background:"rgba(255,255,255,.04)",borderRadius:10,padding:3}}>
            {TABS.map(t=>(
              <button key={t.id} onClick={()=>setTab(t.id)} style={{background:tab===t.id?"rgba(255,255,255,.1)":"transparent",border:`1px solid ${tab===t.id?"rgba(255,255,255,.15)":"transparent"}`,borderRadius:8,padding:"6px 18px",cursor:"pointer",color:tab===t.id?"white":"rgba(255,255,255,.4)",fontSize:13,fontWeight:tab===t.id?600:400,transition:"all .15s",display:"flex",alignItems:"center",gap:6}}>
                <span>{t.icon}</span>{t.label}
              </button>
            ))}
          </div>

          {/* Live stats */}
          <div style={{display:"flex",gap:20,alignItems:"center"}}>
            {[
              {l:"Portfolio",  v:`$${portfolioTotal.toFixed(0).replace(/\B(?=(\d{3})+(?!\d))/g,",")}`, c:"#00C97A"},
              {l:"Prop P&L",   v:`${totalEvalPnl>=0?"+":""}$${Math.abs(totalEvalPnl).toFixed(0).replace(/\B(?=(\d{3})+(?!\d))/g,",")}`, c:totalEvalPnl>=0?"#00C97A":"#F43F5E"},
              {l:"BTC",        v:fmt$(ENG["BTC"].price), c:"#F7931A"},
              {l:"ETH",        v:fmt$(ENG["ETH"].price), c:"#627EEA"},
            ].map(s=>(
              <div key={s.l} style={{textAlign:"right"}}>
                <div style={{fontFamily:"'Orbitron',monospace",fontSize:13,fontWeight:700,color:s.c,lineHeight:1}}>{s.v}</div>
                <div style={{fontSize:9,color:"rgba(255,255,255,.25)",letterSpacing:1,marginTop:2}}>{s.l}</div>
              </div>
            ))}
            <div style={{display:"flex",alignItems:"center",gap:6,background:"rgba(0,201,122,.05)",border:"1px solid rgba(0,201,122,.18)",borderRadius:20,padding:"4px 10px"}}>
              <div style={{width:6,height:6,borderRadius:"50%",background:"#00C97A",animation:"blink 1.5s infinite"}}/>
              <span style={{fontSize:9,color:"rgba(0,201,122,.8)",fontFamily:"monospace",letterSpacing:1}}>LIVE</span>
            </div>
          </div>
        </div>

        {/* ── REGIME BAR ── */}
        <div style={{background:"#161B22",borderBottom:"1px solid rgba(255,255,255,.05)",padding:"5px 24px",display:"flex",gap:0,overflowX:"auto",flexShrink:0}}>
          {[
            {l:"FEAR/GREED",v:`${MARKET_REGIME.fearGreed} — FEAR`,c:"#F59E0B"},
            {l:"BTC DOM",    v:`${MARKET_REGIME.btcDominance}%`,  c:"#F7931A"},
            {l:"MCAP",       v:"$2.68T",                          c:"#00C97A"},
            {l:"ETF INFLOW", v:"$630M/day",                       c:"#00C97A"},
            {l:"FUNDING",    v:`${(MARKET_REGIME.funding*100).toFixed(3)}%`,c:"#F43F5E"},
            {l:"OI",         v:`$${MARKET_REGIME.oi}B`,           c:"#A78BFA"},
            {l:"CONNECTIONS",v:`${connections.filter(c=>c.status==="connected").length}/${connections.length} LIVE`,c:"#00D4FF"},
          ].map((s,i)=>(
            <div key={s.l} style={{display:"flex",gap:6,alignItems:"center",padding:"0 14px",borderRight:i<6?"1px solid rgba(255,255,255,.05)":"none",whiteSpace:"nowrap"}}>
              <span style={{color:"rgba(255,255,255,.28)",fontSize:9,fontFamily:"monospace"}}>{s.l}</span>
              <span style={{color:s.c,fontFamily:"'Orbitron',monospace",fontSize:9,fontWeight:600}}>{s.v}</span>
            </div>
          ))}
        </div>

        {/* ── CONTENT ── */}
        <div style={{flex:1,overflow:"hidden",display:"flex"}}>

          {/* ── MARKETS TAB ── */}
          {tab==="markets" && (
            <div style={{display:"grid",gridTemplateColumns:"220px 1fr 300px",width:"100%",overflow:"hidden"}}>

              {/* Asset list */}
              <div style={{borderRight:"1px solid rgba(255,255,255,.07)",overflowY:"auto",padding:"12px 0"}}>
                <div style={{padding:"0 12px",color:"rgba(255,255,255,.3)",fontSize:10,fontWeight:500,marginBottom:10,letterSpacing:1}}>MARKETS</div>
                {ASSETS.map(a=>{
                  const e=ENG[a.sym],up=e.chg24>=0,lc=up?"#00C97A":"#F43F5E";
                  return (
                    <div key={a.sym} onClick={()=>setSelSym(a.sym)} style={{display:"flex",alignItems:"center",gap:10,padding:"9px 12px",background:selSym===a.sym?`rgba(${rgb(a.color)},.07)`:"transparent",borderLeft:`2px solid ${selSym===a.sym?a.color:"transparent"}`,cursor:"pointer",transition:"all .15s"}}>
                      <div style={{width:32,height:32,borderRadius:8,background:`rgba(${rgb(a.color)},.1)`,border:`1px solid rgba(${rgb(a.color)},.25)`,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>
                        <span style={{fontFamily:"'Orbitron',monospace",fontSize:7,fontWeight:700,color:a.color}}>{a.sym.slice(0,3)}</span>
                      </div>
                      <div style={{flex:1,minWidth:0}}>
                        <div style={{fontWeight:600,fontSize:12,color:"white"}}>{a.sym}</div>
                        <div style={{fontSize:10,color:lc,fontFamily:"monospace"}}>{fmtPct(e.chg24)}</div>
                      </div>
                      <div style={{textAlign:"right"}}>
                        <div style={{fontFamily:"'Orbitron',monospace",fontSize:11,fontWeight:700,color:"white"}}>{fmt$(e.price)}</div>
                        <Spark data={e.history} color={lc}/>
                      </div>
                    </div>
                  );
                })}

                {/* Market stats */}
                <div style={{margin:"12px",background:"#1C2333",borderRadius:10,padding:"12px"}}>
                  <div style={{color:"rgba(255,255,255,.3)",fontSize:9,fontFamily:"monospace",letterSpacing:1,marginBottom:8}}>2026 REGIME</div>
                  {[{l:"S&P 500",v:"All-time high"},{l:"Fed Rate",v:"4.25–4.50%"},{l:"Clarity Act",v:"Pending vote"},{l:"Whale BTC",v:"270K accumulated"}].map(s=>(
                    <div key={s.l} style={{display:"flex",justifyContent:"space-between",padding:"4px 0",borderBottom:"1px solid rgba(255,255,255,.04)"}}>
                      <span style={{color:"rgba(255,255,255,.3)",fontSize:9}}>{s.l}</span>
                      <span style={{color:"rgba(255,255,255,.6)",fontSize:9,fontFamily:"monospace"}}>{s.v}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Chart */}
              <div style={{display:"flex",flexDirection:"column",overflow:"hidden",borderRight:"1px solid rgba(255,255,255,.07)"}}>
                <div style={{padding:"10px 14px",borderBottom:"1px solid rgba(255,255,255,.05)",display:"flex",justifyContent:"space-between",alignItems:"center",flexShrink:0}}>
                  <div style={{display:"flex",alignItems:"center",gap:12}}>
                    <div style={{width:8,height:8,borderRadius:"50%",background:ASSETS.find(a=>a.sym===selSym)?.color,boxShadow:`0 0 8px ${ASSETS.find(a=>a.sym===selSym)?.color}`}}/>
                    <span style={{fontFamily:"'Orbitron',monospace",fontWeight:700,fontSize:14,color:"white",letterSpacing:2}}>{selSym}</span>
                    <span style={{fontFamily:"'Orbitron',monospace",fontSize:18,fontWeight:700,color:selEng.chg>=0?"#00C97A":"#F43F5E"}}>{fmt$(selEng.price)}</span>
                    <span style={{fontSize:12,color:selEng.chg>=0?"#00C97A":"#F43F5E",fontFamily:"monospace"}}>{fmtPct(selEng.chg24)}</span>
                  </div>
                  <div style={{display:"flex",gap:8}}>
                    {(()=>{const rsi=selEng.rsi(),bb=selEng.bb();return(
                      <>
                        <span style={{background:"rgba(255,255,255,.04)",border:"1px solid rgba(255,255,255,.08)",borderRadius:6,padding:"3px 9px",fontSize:10,color:rsi>70?"#F43F5E":rsi<30?"#00C97A":"#F59E0B",fontFamily:"monospace"}}>RSI {rsi.toFixed(0)}</span>
                        <span style={{background:"rgba(255,255,255,.04)",border:"1px solid rgba(255,255,255,.08)",borderRadius:6,padding:"3px 9px",fontSize:10,color:"rgba(255,255,255,.4)",fontFamily:"monospace"}}>BB {bb.pct.toFixed(0)}%</span>
                        <button onClick={()=>setOrderAsset(ASSETS.find(a=>a.sym===selSym))} style={{background:"linear-gradient(135deg,#00C97A88,#00884488)",border:"1px solid rgba(0,201,122,.4)",borderRadius:8,padding:"5px 14px",cursor:"pointer",color:"#00C97A",fontWeight:600,fontSize:12}}>Trade →</button>
                      </>
                    )})()}
                  </div>
                </div>
                <div style={{flex:1,padding:"6px"}}>
                  <QuantumChart key={selSym} symKey={selSym} h="100%"/>
                </div>
                {/* Mini grid */}
                <div style={{flexShrink:0,display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:8,padding:"10px 12px",borderTop:"1px solid rgba(255,255,255,.05)"}}>
                  {ASSETS.filter(a=>a.sym!==selSym).slice(0,4).map(a=>{
                    const e=ENG[a.sym],up=e.chg>=0;
                    return (
                      <div key={a.sym} onClick={()=>setSelSym(a.sym)} style={{background:"#1C2333",border:"1px solid rgba(255,255,255,.06)",borderRadius:8,padding:"7px 9px",cursor:"pointer"}}>
                        <div style={{display:"flex",justifyContent:"space-between",marginBottom:4}}>
                          <span style={{fontFamily:"'Orbitron',monospace",fontSize:9,color:a.color}}>{a.sym}</span>
                          <span style={{fontSize:9,color:up?"#00C97A":"#F43F5E",fontFamily:"monospace"}}>{fmtPct(e.chg)}</span>
                        </div>
                        <QuantumChart symKey={a.sym} h={36}/>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Right: eval + trades */}
              <div style={{display:"flex",flexDirection:"column",overflow:"hidden"}}>
                <div style={{padding:"10px 14px 6px",borderBottom:"1px solid rgba(255,255,255,.05)",flexShrink:0}}>
                  <div style={{color:"rgba(255,255,255,.3)",fontSize:10,fontWeight:500,letterSpacing:1}}>ACTIVE EVALUATIONS</div>
                </div>
                <div style={{padding:"10px 12px",display:"flex",flexDirection:"column",gap:10,overflowY:"auto",flex:1}}>
                  {evals.map(ev=>{
                    const firm=PROP_FIRMS.find(f=>f.id===ev.firmId);
                    return <EvalCard key={ev.id} ev={ev} firm={firm}/>;
                  })}

                  <div style={{background:"#1C2333",borderRadius:12,padding:"14px"}}>
                    <div style={{color:"rgba(255,255,255,.3)",fontSize:10,fontWeight:500,marginBottom:10}}>RECENT EXECUTIONS</div>
                    {evals.flatMap(ev=>ev.tradesToday.slice(0,3)).slice(0,8).map((t,i)=>(
                      <div key={i} className="trade" style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"6px 0",borderBottom:"1px solid rgba(255,255,255,.04)"}}>
                        <div style={{display:"flex",gap:7,alignItems:"center"}}>
                          <span style={{background:t.side==="BUY"?"rgba(0,201,122,.1)":"rgba(244,63,94,.1)",color:t.side==="BUY"?"#00C97A":"#F43F5E",border:`1px solid ${t.side==="BUY"?"rgba(0,201,122,.3)":"rgba(244,63,94,.3)"}`,borderRadius:4,padding:"1px 6px",fontSize:8,fontFamily:"monospace"}}>{t.side}</span>
                          <span style={{fontWeight:500,fontSize:12}}>{t.sym}</span>
                        </div>
                        <div style={{display:"flex",gap:10,alignItems:"center"}}>
                          <span style={{fontFamily:"'Orbitron',monospace",fontSize:11,color:t.pnl>=0?"#00C97A":"#F43F5E",fontWeight:600}}>{t.pnl>=0?"+":"-"}${Math.abs(t.pnl).toFixed(0)}</span>
                          <span style={{color:"rgba(255,255,255,.2)",fontSize:9,fontFamily:"monospace"}}>{t.t}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ── PROP FIRMS TAB ── */}
          {tab==="prop" && (
            <div style={{flex:1,padding:"20px 24px",overflowY:"auto"}}>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:16}}>
                <div>
                  <h2 style={{fontSize:16,fontWeight:600}}>Prop Firm Evaluations</h2>
                  <div style={{color:"rgba(255,255,255,.4)",fontSize:12,marginTop:3}}>Track progress, drawdown, and payouts across all your prop accounts</div>
                </div>
                <div style={{display:"flex",gap:12}}>
                  <div style={{background:"#1C2333",border:"1px solid rgba(255,255,255,.07)",borderRadius:10,padding:"10px 16px",textAlign:"center"}}>
                    <div style={{fontFamily:"'Orbitron',monospace",fontSize:16,fontWeight:700,color:"#00C97A"}}>${totalEvalPnl>=0?"+":""}${Math.abs(totalEvalPnl).toFixed(0).replace(/\B(?=(\d{3})+(?!\d))/g,",")}</div>
                    <div style={{color:"rgba(255,255,255,.3)",fontSize:10,marginTop:2}}>Total Eval P&L</div>
                  </div>
                  <div style={{background:"#1C2333",border:"1px solid rgba(255,255,255,.07)",borderRadius:10,padding:"10px 16px",textAlign:"center"}}>
                    <div style={{fontFamily:"'Orbitron',monospace",fontSize:16,fontWeight:700,color:"#F59E0B"}}>$9,200</div>
                    <div style={{color:"rgba(255,255,255,.3)",fontSize:10,marginTop:2}}>Paid Out</div>
                  </div>
                </div>
              </div>

              {/* Eval cards */}
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:14,marginBottom:20}}>
                {evals.map(ev=>{
                  const firm=PROP_FIRMS.find(f=>f.id===ev.firmId);
                  return <EvalCard key={ev.id} ev={ev} firm={firm}/>;
                })}
              </div>

              {/* Prop firm comparison */}
              <h3 style={{fontSize:14,fontWeight:600,marginBottom:12,color:"rgba(255,255,255,.7)"}}>Available Firms</h3>
              <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:12}}>
                {PROP_FIRMS.map(f=>(
                  <div key={f.id} style={{background:"#1C2333",border:`1px solid rgba(${rgb(f.color)},.15)`,borderRadius:14,padding:"16px"}}>
                    <div style={{display:"flex",gap:9,alignItems:"center",marginBottom:12}}>
                      <div style={{width:34,height:34,borderRadius:8,background:`rgba(${rgb(f.color)},.12)`,border:`1px solid rgba(${rgb(f.color)},.3)`,display:"flex",alignItems:"center",justifyContent:"center"}}>
                        <span style={{fontFamily:"'Orbitron',monospace",fontSize:8,fontWeight:700,color:f.color}}>{f.logo}</span>
                      </div>
                      <div>
                        <div style={{fontWeight:600,fontSize:13,color:"white"}}>{f.name}</div>
                        <div style={{color:"rgba(255,255,255,.3)",fontSize:10}}>{f.freq} payouts</div>
                      </div>
                    </div>
                    {[{l:"Target",v:`${f.profitTarget}%`},{l:"Max DD",v:`${f.maxDD}%`},{l:"Split",v:`${f.split}%`},{l:"Fee",v:`$${f.fee}`}].map(s=>(
                      <div key={s.l} style={{display:"flex",justifyContent:"space-between",padding:"5px 0",borderBottom:"1px solid rgba(255,255,255,.04)"}}>
                        <span style={{color:"rgba(255,255,255,.35)",fontSize:11}}>{s.l}</span>
                        <span style={{fontFamily:"'Orbitron',monospace",fontSize:11,color:f.color,fontWeight:600}}>{s.v}</span>
                      </div>
                    ))}
                    <div style={{marginTop:10,fontSize:10,color:"rgba(255,255,255,.3)",lineHeight:1.5,marginBottom:10}}>{f.instruments.slice(0,2).join(", ")}</div>
                    <button onClick={()=>window.open("https://"+f.url,"_blank")} style={{width:"100%",background:`rgba(${rgb(f.color)},.1)`,border:`1px solid rgba(${rgb(f.color)},.3)`,borderRadius:8,padding:"8px",cursor:"pointer",color:f.color,fontWeight:600,fontSize:12}}>
                      Visit {f.url} →
                    </button>
                  </div>
                ))}
              </div>

              {/* Connection guide */}
              <div style={{background:"rgba(0,212,255,.04)",border:"1px solid rgba(0,212,255,.12)",borderRadius:14,padding:"18px 20px",marginTop:20}}>
                <div style={{fontWeight:600,fontSize:13,color:"#00D4FF",marginBottom:12}}>ℹ How to Connect After Passing</div>
                <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:16}}>
                  {[
                    {title:"FTMO / E8 → MT5",steps:["Pass evaluation on firm website","Receive MT5 server + login by email","Open MetaTrader 5 → File → Login","Enter: server, login, password","Balance syncs — start trading live","Request payout from firm dashboard"]},
                    {title:"Apex / TopStep → Rithmic",steps:["Pass challenge on firm website","Download Rithmic R|Trader Pro free","Enter connection credentials from email","Connect NinjaTrader or TradeStation","Or use Rithmic API for algo trading","Payouts processed automatically"]},
                    {title:"API / Automated Trading",steps:["Most firms allow EAs and scripts","FTMO: MT5 Expert Advisors allowed","Apex: Rithmic API SDK available","No martingale or grid strategies","Max risk per trade: 1-2% of account","Keep trade logs for compliance"]},
                  ].map(s=>(
                    <div key={s.title}>
                      <div style={{fontWeight:600,fontSize:12,color:"rgba(255,255,255,.65)",marginBottom:9}}>{s.title}</div>
                      {s.steps.map((step,i)=>(
                        <div key={i} style={{display:"flex",gap:7,marginBottom:6,alignItems:"flex-start"}}>
                          <span style={{background:"rgba(0,212,255,.1)",color:"#00D4FF",borderRadius:"50%",width:17,height:17,display:"flex",alignItems:"center",justifyContent:"center",fontSize:8,fontFamily:"monospace",flexShrink:0,marginTop:1}}>{i+1}</span>
                          <span style={{color:"rgba(255,255,255,.4)",fontSize:11,lineHeight:1.5}}>{step}</span>
                        </div>
                      ))}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* ── CONNECTIONS TAB ── */}
          {tab==="connect" && (
            <div style={{flex:1,padding:"20px 24px",overflowY:"auto"}}>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:16}}>
                <div>
                  <h2 style={{fontSize:16,fontWeight:600}}>Market Connections</h2>
                  <div style={{color:"rgba(255,255,255,.4)",fontSize:12,marginTop:3}}>Connect exchanges, brokers, and data feeds. Public WebSocket feeds need no API key.</div>
                </div>
                <div style={{background:"rgba(0,201,122,.06)",border:"1px solid rgba(0,201,122,.2)",borderRadius:10,padding:"8px 16px",display:"flex",gap:14}}>
                  <div style={{textAlign:"center"}}>
                    <div style={{fontFamily:"'Orbitron',monospace",fontSize:15,fontWeight:700,color:"#00C97A"}}>{connections.filter(c=>c.status==="connected").length}</div>
                    <div style={{fontSize:9,color:"rgba(255,255,255,.3)"}}>CONNECTED</div>
                  </div>
                  <div style={{textAlign:"center"}}>
                    <div style={{fontFamily:"'Orbitron',monospace",fontSize:15,fontWeight:700,color:"#F59E0B"}}>{connections.filter(c=>c.status==="key_needed").length}</div>
                    <div style={{fontSize:9,color:"rgba(255,255,255,.3)"}}>NEEDS KEY</div>
                  </div>
                </div>
              </div>

              <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:14,marginBottom:24}}>
                {connections.map(c=><ConnCard key={c.id} conn={c} onToggle={id=>{setKeyModal(id);setKeyInput("");}}/>)}
              </div>

              {/* How to connect guide */}
              <div style={{background:"#1C2333",borderRadius:14,padding:"20px"}}>
                <div style={{fontWeight:600,fontSize:14,marginBottom:16}}>Market Data Connection Guide</div>
                <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:20}}>
                  <div>
                    <div style={{fontWeight:600,fontSize:12,color:"#00C97A",marginBottom:10}}>Free Public Feeds (No API Key)</div>
                    {[
                      {name:"Binance WebSocket",  code:"wss://stream.binance.com:9443/ws/btcusdt@trade",  note:"Real-time BTC price ticks"},
                      {name:"Coinbase WebSocket",  code:"wss://advanced-trade-ws.coinbase.com",            note:"Full order book depth"},
                      {name:"Bybit WebSocket",     code:"wss://stream.bybit.com/v5/public/linear",         note:"Perp funding rates + OI"},
                    ].map(f=>(
                      <div key={f.name} style={{marginBottom:12}}>
                        <div style={{fontWeight:500,fontSize:12,color:"white",marginBottom:3}}>{f.name}</div>
                        <div style={{background:"rgba(0,0,0,.3)",borderRadius:7,padding:"7px 10px",fontFamily:"monospace",fontSize:10,color:"#00C97A",marginBottom:3}}>{f.code}</div>
                        <div style={{color:"rgba(255,255,255,.3)",fontSize:10}}>{f.note}</div>
                      </div>
                    ))}
                  </div>
                  <div>
                    <div style={{fontWeight:600,fontSize:12,color:"#F59E0B",marginBottom:10}}>API Key Required</div>
                    {[
                      {name:"Alpaca Markets (stocks/ETFs)", url:"alpaca.markets",    note:"Free paper trading + live. US stocks, ETFs, crypto. REST + WebSocket."},
                      {name:"Polygon.io (all markets)",     url:"polygon.io",         note:"Stocks, forex, crypto, options. Free tier: 15min delay. Paid: real-time."},
                      {name:"Binance Trading API",          url:"binance.com",        note:"Full trading API. Create key in Account → API Management. IP whitelist required."},
                    ].map(f=>(
                      <div key={f.name} style={{marginBottom:12}}>
                        <div style={{fontWeight:500,fontSize:12,color:"white",marginBottom:3}}>{f.name}</div>
                        <div style={{color:"rgba(255,255,255,.35)",fontSize:11,marginBottom:3,lineHeight:1.5}}>{f.note}</div>
                        <button onClick={()=>window.open("https://"+f.url,"_blank")} style={{background:"rgba(245,158,11,.08)",border:"1px solid rgba(245,158,11,.25)",borderRadius:6,padding:"4px 10px",cursor:"pointer",color:"#F59E0B",fontSize:10,fontWeight:600}}>Get free API key at {f.url} →</button>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Status notice */}
              <div style={{background:"rgba(0,212,255,.04)",border:"1px solid rgba(0,212,255,.12)",borderRadius:12,padding:"14px 18px",marginTop:14,display:"flex",gap:12,alignItems:"flex-start"}}>
                <span style={{fontSize:18,flexShrink:0}}>ℹ️</span>
                <div style={{color:"rgba(255,255,255,.45)",fontSize:12,lineHeight:1.7}}>
                  <strong style={{color:"white"}}>Note on live trading:</strong> The price feeds in this dashboard are simulated for demonstration. To connect real exchange data, you need server-side code (Node.js / Python) that opens the WebSocket connections listed above and streams data to your frontend. Your API keys should always live in a <code style={{color:"#00C97A",background:"rgba(0,201,122,.08)",padding:"1px 5px",borderRadius:3}}>.env</code> file on your backend server — never in browser code.
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
}
