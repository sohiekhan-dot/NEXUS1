import { useState, useEffect, useRef } from "react";

// ─── REAL PROP FIRM DATA (2026) ───────────────────────────────────────────────
const PROP_FIRMS = [
  {
    id: "ftmo",
    name: "FTMO",
    logo: "F",
    color: "#00D4FF",
    url: "ftmo.com",
    accounts: ["$10K","$25K","$50K","$100K","$200K"],
    fees: { 10000:155, 25000:250, 50000:345, 100000:540, 200000:1080 },
    rules: {
      profitTarget: 10,        // % phase 1
      phase2Target: 5,         // % phase 2
      maxDailyLoss: 5,         // %
      maxTotalLoss: 10,        // %
      minTradingDays: 10,
      payoutSplit: 90,         // %
      payoutFrequency: "Monthly",
      instruments: ["Forex","Indices","Crypto","Commodities"],
    },
    popularity: 98,
    founded: 2015,
    country: "Czech Republic",
    note: "Industry gold standard. Strict but highest trust.",
  },
  {
    id: "apex",
    name: "Apex Trader Funding",
    logo: "A",
    color: "#FF6B35",
    url: "apextraderfunding.com",
    accounts: ["$25K","$50K","$100K","$150K","$300K"],
    fees: { 25000:167, 50000:167, 100000:167, 150000:167, 300000:167 },
    rules: {
      profitTarget: 6,
      phase2Target: null,      // one-phase
      maxDailyLoss: 3,
      maxTotalLoss: 6,
      minTradingDays: 7,
      payoutSplit: 90,
      payoutFrequency: "Every 2 weeks",
      instruments: ["Futures (CME, CBOT, NYMEX)"],
    },
    popularity: 92,
    founded: 2021,
    country: "USA",
    note: "Best for futures traders. Flat fee model.",
  },
  {
    id: "topstep",
    name: "TopStep",
    logo: "T",
    color: "#10B981",
    url: "topstep.com",
    accounts: ["$50K","$100K","$150K"],
    fees: { 50000:165, 100000:325, 150000:375 },
    rules: {
      profitTarget: 6,
      phase2Target: null,
      maxDailyLoss: 2,
      maxTotalLoss: 4,
      minTradingDays: 5,
      payoutSplit: 90,
      payoutFrequency: "Weekly",
      instruments: ["Futures (CME Group)"],
    },
    popularity: 88,
    founded: 2012,
    country: "USA",
    note: "Oldest futures prop firm. Weekly payouts.",
  },
  {
    id: "e8",
    name: "E8 Funding",
    logo: "E8",
    color: "#A78BFA",
    url: "e8funding.com",
    accounts: ["$25K","$50K","$100K","$200K","$400K"],
    fees: { 25000:228, 50000:348, 100000:588, 200000:1068, 400000:1908 },
    rules: {
      profitTarget: 8,
      phase2Target: 5,
      maxDailyLoss: 4,
      maxTotalLoss: 8,
      minTradingDays: 3,
      payoutSplit: 80,
      payoutFrequency: "Monthly",
      instruments: ["Forex","Indices","Crypto","Metals"],
    },
    popularity: 85,
    founded: 2021,
    country: "USA",
    note: "Fast evaluation. 80% split. Crypto-friendly.",
  },
  {
    id: "tft",
    name: "The Funded Trader",
    logo: "TFT",
    color: "#F59E0B",
    url: "thefundedtrader.com",
    accounts: ["$25K","$50K","$100K","$200K"],
    fees: { 25000:315, 50000:515, 100000:995, 200000:1895 },
    rules: {
      profitTarget: 10,
      phase2Target: 5,
      maxDailyLoss: 5,
      maxTotalLoss: 10,
      minTradingDays: 5,
      payoutSplit: 90,
      payoutFrequency: "Weekly (after 14 days)",
      instruments: ["Forex","Indices","Crypto","Commodities"],
    },
    popularity: 80,
    founded: 2021,
    country: "USA",
    note: "Weekly payouts after 14 days. 90% split.",
  },
];

// ─── SIMULATED ACTIVE EVALUATIONS ─────────────────────────────────────────────
const INITIAL_EVALS = [
  {
    id: "eval-1",
    firmId: "ftmo",
    accountSize: 100000,
    phase: 1,
    startDate: "Apr 12, 2026",
    status: "active",
    currentBalance: 105840,
    startBalance: 100000,
    highWaterMark: 106200,
    profitTarget: 110000,   // 10% = $110K
    dailyLossLimit: 95000,  // 5% daily = -$5K from start of day
    maxDrawdown: 90000,     // 10% = $90K
    tradingDays: 14,
    minTradingDays: 10,
    trades: 47,
    winRate: 62,
    broker: "MT5",
    tradesToday: [
      { sym:"EURUSD", side:"BUY",  pnl:+340, time:"09:14" },
      { sym:"BTCUSD", side:"SELL", pnl:-120, time:"10:31" },
      { sym:"GOLD",   side:"BUY",  pnl:+580, time:"13:45" },
    ],
  },
  {
    id: "eval-2",
    firmId: "apex",
    accountSize: 50000,
    phase: 1,
    startDate: "Apr 22, 2026",
    status: "active",
    currentBalance: 51200,
    startBalance: 50000,
    highWaterMark: 51800,
    profitTarget: 53000,    // 6%
    dailyLossLimit: 48500,  // 3% daily
    maxDrawdown: 47000,     // 6%
    tradingDays: 7,
    minTradingDays: 7,
    trades: 23,
    winRate: 57,
    broker: "Rithmic",
    tradesToday: [
      { sym:"ES",   side:"BUY",  pnl:+225, time:"09:32" },
      { sym:"NQ",   side:"SELL", pnl:+180, time:"11:04" },
    ],
  },
];

// ─── LIVE P&L SIMULATION ──────────────────────────────────────────────────────
function useEvalSimulation(initial) {
  const [evals, setEvals] = useState(initial);
  useEffect(() => {
    const iv = setInterval(() => {
      setEvals(prev => prev.map(ev => {
        if (ev.status !== "active") return ev;
        const dailyPnl = (Math.random() - 0.42) * 400;
        const newBalance = Math.max(ev.maxDrawdown + 100, ev.currentBalance + dailyPnl);
        const newHWM = Math.max(ev.highWaterMark, newBalance);
        let status = "active";
        if (newBalance >= ev.profitTarget) status = ev.phase === 1 ? "phase1_passed" : "funded";
        if (newBalance <= ev.maxDrawdown) status = "breached";
        const tradeHappens = Math.random() < 0.12;
        const syms = { "eval-1":["EURUSD","GBPUSD","BTCUSD","GOLD","SPX500"], "eval-2":["ES","NQ","CL","GC"] };
        const newTrade = tradeHappens ? {
          sym: (syms[ev.id]||["EURUSD"])[Math.floor(Math.random()*5)],
          side: Math.random() > 0.5 ? "BUY" : "SELL",
          pnl: (Math.random() > 0.58 ? 1 : -1) * (50 + Math.random() * 400),
          time: new Date().toLocaleTimeString("en",{hour:"2-digit",minute:"2-digit"}),
        } : null;
        return {
          ...ev,
          currentBalance: newBalance,
          highWaterMark: newHWM,
          status,
          tradingDays: ev.tradingDays,
          tradesToday: newTrade ? [newTrade, ...ev.tradesToday.slice(0,9)] : ev.tradesToday,
          trades: ev.trades + (tradeHappens ? 1 : 0),
          winRate: tradeHappens
            ? ev.winRate * 0.98 + (newTrade?.pnl > 0 ? 1 : 0) * 2
            : ev.winRate,
        };
      }));
    }, 1500);
    return () => clearInterval(iv);
  }, []);
  return [evals, setEvals];
}

// ─── HELPERS ──────────────────────────────────────────────────────────────────
const hexRgb = h => { const r=/^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(h); return r?`${parseInt(r[1],16)},${parseInt(r[2],16)},${parseInt(r[3],16)}`:"255,255,255"; };
const fmt$ = v => "$" + Math.abs(v).toLocaleString("en",{minimumFractionDigits:2,maximumFractionDigits:2});
const fmtK = v => "$" + (Math.abs(v)/1000).toFixed(0) + "K";

// Progress bar
function Bar({ value, max, color, height=8, label, sublabel }) {
  const pct = Math.max(0, Math.min(100, (value / max) * 100));
  return (
    <div>
      {(label || sublabel) && (
        <div style={{display:"flex",justifyContent:"space-between",marginBottom:5}}>
          {label && <span style={{color:"rgba(255,255,255,0.4)",fontSize:11}}>{label}</span>}
          {sublabel && <span style={{fontFamily:"'Orbitron',monospace",fontSize:11,color,fontWeight:600}}>{sublabel}</span>}
        </div>
      )}
      <div style={{height,background:"rgba(255,255,255,0.06)",borderRadius:height/2,overflow:"hidden"}}>
        <div style={{
          height:"100%", width:`${pct}%`,
          background:`linear-gradient(90deg,${color},${color}bb)`,
          borderRadius:height/2,
          boxShadow:`0 0 8px rgba(${hexRgb(color)},0.4)`,
          transition:"width 0.6s ease",
        }}/>
      </div>
    </div>
  );
}

// Status badge
function Badge({ status }) {
  const map = {
    active:         { label:"ACTIVE",          color:"#00D4FF" },
    phase1_passed:  { label:"PHASE 1 PASSED ✓",color:"#10B981" },
    funded:         { label:"FUNDED ✓",        color:"#00C97A" },
    breached:       { label:"BREACHED ✗",      color:"#F43F5E" },
    pending:        { label:"PENDING",          color:"#F59E0B" },
  };
  const s = map[status] || map.active;
  return (
    <span style={{
      background:`rgba(${hexRgb(s.color)},0.1)`,
      border:`1px solid rgba(${hexRgb(s.color)},0.35)`,
      borderRadius:20, padding:"3px 10px",
      fontSize:9, color:s.color, fontFamily:"monospace", letterSpacing:1,
    }}>{s.label}</span>
  );
}

// Evaluation card
function EvalCard({ ev, firm, selected, onClick }) {
  const profit = ev.currentBalance - ev.startBalance;
  const profitPct = (profit / ev.startBalance) * 100;
  const profitNeeded = ev.profitTarget - ev.currentBalance;
  const progressToTarget = ((ev.currentBalance - ev.startBalance) / (ev.profitTarget - ev.startBalance)) * 100;
  const drawdownUsed = ((ev.highWaterMark - ev.currentBalance) / ev.startBalance) * 100;
  const maxDD = ((ev.startBalance - ev.maxDrawdown) / ev.startBalance) * 100;
  const ddPct = (drawdownUsed / maxDD) * 100;

  const isGood = ev.status === "active" || ev.status === "phase1_passed" || ev.status === "funded";

  return (
    <div onClick={onClick} style={{
      background: selected ? `rgba(${hexRgb(firm.color)},0.07)` : "#161B22",
      border:`1px solid ${selected ? firm.color : "rgba(255,255,255,0.08)"}`,
      borderRadius:14, padding:"18px 20px", cursor:"pointer",
      transition:"all 0.2s",
      boxShadow: selected ? `0 0 24px rgba(${hexRgb(firm.color)},0.12)` : "none",
      position:"relative", overflow:"hidden",
    }}>
      {selected && <div style={{position:"absolute",top:0,left:0,right:0,height:2,background:`linear-gradient(90deg,transparent,${firm.color},transparent)`}}/>}

      <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:14}}>
        <div style={{display:"flex",gap:10,alignItems:"center"}}>
          <div style={{width:36,height:36,borderRadius:9,background:`rgba(${hexRgb(firm.color)},0.12)`,border:`1px solid rgba(${hexRgb(firm.color)},0.3)`,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>
            <span style={{fontFamily:"'Orbitron',monospace",fontSize:9,fontWeight:700,color:firm.color}}>{firm.logo}</span>
          </div>
          <div>
            <div style={{fontWeight:600,fontSize:14,color:"white"}}>{firm.name}</div>
            <div style={{color:"rgba(255,255,255,0.35)",fontSize:11,marginTop:1}}>
              {fmtK(ev.accountSize)} · Phase {ev.phase} · {ev.broker}
            </div>
          </div>
        </div>
        <Badge status={ev.status}/>
      </div>

      {/* Balance + P&L */}
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:14}}>
        <div style={{background:"rgba(0,0,0,0.25)",borderRadius:9,padding:"10px 12px"}}>
          <div style={{color:"rgba(255,255,255,0.35)",fontSize:10,marginBottom:4}}>Balance</div>
          <div style={{fontFamily:"'Orbitron',monospace",fontSize:16,fontWeight:700,color:"white"}}>{fmt$(ev.currentBalance)}</div>
        </div>
        <div style={{background:"rgba(0,0,0,0.25)",borderRadius:9,padding:"10px 12px"}}>
          <div style={{color:"rgba(255,255,255,0.35)",fontSize:10,marginBottom:4}}>P&L</div>
          <div style={{fontFamily:"'Orbitron',monospace",fontSize:16,fontWeight:700,color:profit>=0?"#00C97A":"#F43F5E"}}>
            {profit>=0?"+":""}{fmt$(profit)} <span style={{fontSize:11,opacity:0.7}}>({profitPct>=0?"+":""}{profitPct.toFixed(2)}%)</span>
          </div>
        </div>
      </div>

      {/* Progress to target */}
      <div style={{marginBottom:12}}>
        <Bar value={Math.max(0,ev.currentBalance-ev.startBalance)} max={ev.profitTarget-ev.startBalance}
          color={progressToTarget>=100?"#10B981":firm.color} height={10}
          label={`Profit Target ${profitPct>=0?"+":""}{profitPct.toFixed(1)}%`}
          sublabel={profitNeeded>0?`${fmt$(profitNeeded)} needed`:"TARGET REACHED ✓"}/>
      </div>

      {/* Drawdown */}
      <div>
        <Bar value={drawdownUsed} max={maxDD}
          color={ddPct>70?"#F43F5E":ddPct>50?"#F59E0B":"#10B981"} height={8}
          label={`Drawdown Used ${drawdownUsed.toFixed(1)}%`}
          sublabel={`${(maxDD-drawdownUsed).toFixed(1)}% remaining`}/>
      </div>

      {/* Trading days */}
      <div style={{display:"flex",justifyContent:"space-between",marginTop:12,paddingTop:12,borderTop:"1px solid rgba(255,255,255,0.05)"}}>
        <span style={{color:"rgba(255,255,255,0.3)",fontSize:11}}>Trading Days</span>
        <span style={{fontFamily:"'Orbitron',monospace",fontSize:11,color:ev.tradingDays>=ev.minTradingDays?"#10B981":"#F59E0B",fontWeight:600}}>
          {ev.tradingDays}/{ev.minTradingDays} {ev.tradingDays>=ev.minTradingDays?"✓":"(min req)"}
        </span>
      </div>
    </div>
  );
}

// Firm comparison card
function FirmCard({ firm, onSelect }) {
  const cheapestAcc = Math.min(...Object.keys(firm.fees).map(Number));
  const cheapestFee = firm.fees[cheapestAcc];

  return (
    <div style={{background:"#161B22",border:"1px solid rgba(255,255,255,0.08)",borderRadius:14,padding:"18px 20px",transition:"all 0.2s",cursor:"pointer"}}
      onMouseEnter={e=>e.currentTarget.style.borderColor=`rgba(${hexRgb(firm.color)},0.4)`}
      onMouseLeave={e=>e.currentTarget.style.borderColor="rgba(255,255,255,0.08)"}
      onClick={()=>onSelect(firm)}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:14}}>
        <div style={{display:"flex",gap:10,alignItems:"center"}}>
          <div style={{width:40,height:40,borderRadius:10,background:`rgba(${hexRgb(firm.color)},0.12)`,border:`1px solid rgba(${hexRgb(firm.color)},0.3)`,display:"flex",alignItems:"center",justifyContent:"center"}}>
            <span style={{fontFamily:"'Orbitron',monospace",fontSize:9,fontWeight:700,color:firm.color}}>{firm.logo}</span>
          </div>
          <div>
            <div style={{fontWeight:600,fontSize:15,color:"white"}}>{firm.name}</div>
            <div style={{color:"rgba(255,255,255,0.35)",fontSize:11,marginTop:1}}>Since {firm.founded} · {firm.country}</div>
          </div>
        </div>
        <div style={{textAlign:"right"}}>
          <div style={{fontFamily:"'Orbitron',monospace",fontSize:13,fontWeight:700,color:firm.color}}>{firm.rules.payoutSplit}% split</div>
          <div style={{color:"rgba(255,255,255,0.3)",fontSize:10,marginTop:1}}>{firm.rules.payoutFrequency}</div>
        </div>
      </div>

      <div style={{color:"rgba(255,255,255,0.4)",fontSize:12,marginBottom:14,lineHeight:1.5}}>{firm.note}</div>

      <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:8,marginBottom:14}}>
        {[
          {l:"Profit Target", v:`${firm.rules.profitTarget}%`},
          {l:"Max Daily Loss",v:`${firm.rules.maxDailyLoss}%`},
          {l:"Max Drawdown",  v:`${firm.rules.maxTotalLoss}%`},
        ].map(s=>(
          <div key={s.l} style={{background:"rgba(0,0,0,0.3)",borderRadius:7,padding:"8px 10px",textAlign:"center"}}>
            <div style={{color:"rgba(255,255,255,0.3)",fontSize:9,marginBottom:3}}>{s.l}</div>
            <div style={{fontFamily:"'Orbitron',monospace",fontSize:13,fontWeight:700,color:"white"}}>{s.v}</div>
          </div>
        ))}
      </div>

      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
        <div>
          <span style={{color:"rgba(255,255,255,0.35)",fontSize:11}}>From </span>
          <span style={{fontFamily:"'Orbitron',monospace",fontSize:13,color:firm.color,fontWeight:700}}>${cheapestFee}</span>
          <span style={{color:"rgba(255,255,255,0.35)",fontSize:11}}> · {fmtK(cheapestAcc)} account</span>
        </div>
        <div style={{display:"flex",gap:5}}>
          {firm.rules.instruments.slice(0,2).map(i=>(
            <span key={i} style={{background:`rgba(${hexRgb(firm.color)},0.08)`,color:firm.color,fontSize:9,fontFamily:"monospace",padding:"2px 6px",borderRadius:4,border:`1px solid rgba(${hexRgb(firm.color)},0.2)`}}>{i.split(" ")[0]}</span>
          ))}
        </div>
      </div>

      <button style={{marginTop:12,width:"100%",background:`rgba(${hexRgb(firm.color)},0.1)`,border:`1px solid rgba(${hexRgb(firm.color)},0.3)`,borderRadius:8,padding:"9px",cursor:"pointer",color:firm.color,fontWeight:600,fontSize:13,transition:"all 0.15s"}}>
        Start Evaluation →
      </button>
    </div>
  );
}

// ─── MAIN APP ─────────────────────────────────────────────────────────────────
export default function PropFirmTracker() {
  const [tab, setTab]           = useState("dashboard");
  const [selectedEval, setSelectedEval] = useState("eval-1");
  const [selectedFirm, setSelectedFirm] = useState(null);
  const [evals, setEvals]       = useEvalSimulation(INITIAL_EVALS);
  const [payouts] = useState([
    { id:"PO-001", firm:"FTMO",    amount:4280, date:"Apr 1, 2026",  status:"Paid",    method:"Bank Wire" },
    { id:"PO-002", firm:"FTMO",    amount:3120, date:"Mar 1, 2026",  status:"Paid",    method:"Bank Wire" },
    { id:"PO-003", firm:"Apex",    amount:1840, date:"Apr 14, 2026", status:"Paid",    method:"USDT" },
    { id:"PO-004", firm:"FTMO",    amount:6200, date:"May 1, 2026",  status:"Pending", method:"Bank Wire" },
  ]);

  const totalPaid = payouts.filter(p=>p.status==="Paid").reduce((s,p)=>s+p.amount,0);
  const totalPending = payouts.filter(p=>p.status==="Pending").reduce((s,p)=>s+p.amount,0);
  const activeEvals = evals.filter(e=>e.status==="active");
  const selEval = evals.find(e=>e.id===selectedEval);
  const selFirmData = selEval ? PROP_FIRMS.find(f=>f.id===selEval.firmId) : null;

  const TABS = [
    {id:"dashboard", label:"Dashboard",  icon:"📊"},
    {id:"evaluations",label:"Evaluations",icon:"🎯"},
    {id:"firms",     label:"Prop Firms", icon:"🏦"},
    {id:"payouts",   label:"Payouts",    icon:"💰"},
  ];

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@600;700;900&family=Inter:wght@400;500;600;700&display=swap');
        *{box-sizing:border-box;margin:0;padding:0;}
        html,body{height:100%;background:#0D1117;}
        ::-webkit-scrollbar{width:4px;} ::-webkit-scrollbar-thumb{background:rgba(255,255,255,0.1);border-radius:2px;}
        @keyframes blink{0%,100%{opacity:1}50%{opacity:0.3}}
        @keyframes fadeIn{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:translateY(0)}}
        @keyframes tradeSlide{from{opacity:0;transform:translateX(8px)}to{opacity:1;transform:translateX(0)}}
        .card{animation:fadeIn 0.3s ease both;}
        .trade{animation:tradeSlide 0.25s ease both;}
        button:hover{opacity:0.85;}
      `}</style>

      <div style={{minHeight:"100vh",background:"#0D1117",color:"white",fontFamily:"'Inter',sans-serif",display:"flex",flexDirection:"column"}}>

        {/* ── HEADER ── */}
        <div style={{background:"#161B22",borderBottom:"1px solid rgba(255,255,255,0.08)",padding:"0 24px",height:58,display:"flex",alignItems:"center",justifyContent:"space-between",flexShrink:0}}>
          <div style={{display:"flex",alignItems:"center",gap:12}}>
            <div style={{width:32,height:32,background:"linear-gradient(135deg,#00C97A,#005F38)",borderRadius:9,display:"flex",alignItems:"center",justifyContent:"center",fontSize:16,boxShadow:"0 0 16px rgba(0,201,122,0.3)"}}>₿</div>
            <div>
              <div style={{fontFamily:"'Orbitron',monospace",fontWeight:700,fontSize:13,color:"#00C97A",letterSpacing:3}}>PROPTRACK</div>
              <div style={{fontSize:9,color:"rgba(255,255,255,0.25)",letterSpacing:2,fontFamily:"monospace"}}>PROP FIRM MANAGER · 2026</div>
            </div>
          </div>

          {/* Tabs */}
          <div style={{display:"flex",gap:2,background:"rgba(255,255,255,0.04)",borderRadius:10,padding:3}}>
            {TABS.map(t=>(
              <button key={t.id} onClick={()=>setTab(t.id)} style={{
                background:tab===t.id?"rgba(255,255,255,0.1)":"transparent",
                border:`1px solid ${tab===t.id?"rgba(255,255,255,0.15)":"transparent"}`,
                borderRadius:8, padding:"6px 16px", cursor:"pointer",
                color:tab===t.id?"white":"rgba(255,255,255,0.4)",
                fontSize:13, fontWeight:tab===t.id?600:400,
                transition:"all 0.15s", display:"flex", alignItems:"center", gap:6,
              }}>
                <span>{t.icon}</span>{t.label}
              </button>
            ))}
          </div>

          {/* Summary stats */}
          <div style={{display:"flex",gap:20,alignItems:"center"}}>
            <div style={{textAlign:"right"}}>
              <div style={{fontFamily:"'Orbitron',monospace",fontSize:14,fontWeight:700,color:"#00C97A"}}>${totalPaid.toLocaleString()}</div>
              <div style={{fontSize:10,color:"rgba(255,255,255,0.3)"}}>Total Paid Out</div>
            </div>
            <div style={{textAlign:"right"}}>
              <div style={{fontFamily:"'Orbitron',monospace",fontSize:14,fontWeight:700,color:"#F59E0B"}}>${totalPending.toLocaleString()}</div>
              <div style={{fontSize:10,color:"rgba(255,255,255,0.3)"}}>Pending</div>
            </div>
            <div style={{display:"flex",alignItems:"center",gap:6,background:"rgba(0,201,122,0.06)",border:"1px solid rgba(0,201,122,0.2)",borderRadius:20,padding:"4px 12px"}}>
              <div style={{width:6,height:6,borderRadius:"50%",background:"#00C97A",animation:"blink 1.5s infinite"}}/>
              <span style={{fontSize:10,color:"#00C97A",fontFamily:"monospace"}}>{activeEvals.length} ACTIVE</span>
            </div>
          </div>
        </div>

        {/* ── CONTENT ── */}
        <div style={{flex:1,overflow:"auto"}}>

          {/* ─ DASHBOARD ─ */}
          {tab==="dashboard" && (
            <div style={{padding:"20px 24px",display:"flex",flexDirection:"column",gap:20}}>
              {/* Top KPIs */}
              <div style={{display:"grid",gridTemplateColumns:"repeat(5,1fr)",gap:12}}>
                {[
                  {l:"Active Evaluations",v:activeEvals.length,          c:"#00D4FF",  icon:"🎯"},
                  {l:"Total Paid Out",    v:`$${totalPaid.toLocaleString()}`, c:"#00C97A",icon:"💰"},
                  {l:"Pending Payout",   v:`$${totalPending.toLocaleString()}`, c:"#F59E0B",icon:"⏳"},
                  {l:"Best Win Rate",    v:`${Math.max(...evals.map(e=>e.winRate)).toFixed(0)}%`, c:"#A78BFA",icon:"📈"},
                  {l:"Total Trades",     v:evals.reduce((s,e)=>s+e.trades,0), c:"white",icon:"⚡"},
                ].map(s=>(
                  <div key={s.l} style={{background:"#161B22",border:`1px solid rgba(${hexRgb(s.c)},0.15)`,borderRadius:12,padding:"16px"}}>
                    <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:10}}>
                      <span style={{fontSize:9,color:"rgba(255,255,255,0.35)",fontWeight:500}}>{s.l}</span>
                      <span style={{fontSize:18}}>{s.icon}</span>
                    </div>
                    <div style={{fontFamily:"'Orbitron',monospace",fontSize:20,fontWeight:700,color:s.c}}>{s.v}</div>
                  </div>
                ))}
              </div>

              {/* Eval cards */}
              <div>
                <h3 style={{fontSize:15,fontWeight:600,marginBottom:12,color:"rgba(255,255,255,0.8)"}}>Active Evaluations</h3>
                <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:14}}>
                  {evals.map(ev => {
                    const firm = PROP_FIRMS.find(f=>f.id===ev.firmId);
                    return <EvalCard key={ev.id} ev={ev} firm={firm} selected={selectedEval===ev.id} onClick={()=>{setSelectedEval(ev.id);setTab("evaluations");}}/>;
                  })}
                </div>
              </div>

              {/* Recent trades across all evals */}
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:14}}>
                <div style={{background:"#161B22",border:"1px solid rgba(255,255,255,0.07)",borderRadius:14,padding:"16px 18px"}}>
                  <div style={{fontWeight:600,fontSize:13,marginBottom:14,color:"rgba(255,255,255,0.8)"}}>Recent Trades</div>
                  {evals.flatMap(ev=>ev.tradesToday.slice(0,3).map(t=>({...t,firm:PROP_FIRMS.find(f=>f.id===ev.firmId)?.name}))).slice(0,8).map((t,i)=>(
                    <div key={i} className="trade" style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"7px 0",borderBottom:"1px solid rgba(255,255,255,0.04)"}}>
                      <div style={{display:"flex",gap:8,alignItems:"center"}}>
                        <span style={{background:t.side==="BUY"?"rgba(0,201,122,0.1)":"rgba(244,63,94,0.1)",color:t.side==="BUY"?"#00C97A":"#F43F5E",border:`1px solid ${t.side==="BUY"?"rgba(0,201,122,0.3)":"rgba(244,63,94,0.3)"}`,borderRadius:5,padding:"2px 7px",fontSize:9,fontFamily:"monospace"}}>{t.side}</span>
                        <span style={{fontWeight:500,fontSize:13}}>{t.sym}</span>
                        <span style={{color:"rgba(255,255,255,0.3)",fontSize:10}}>{t.firm}</span>
                      </div>
                      <div style={{display:"flex",gap:10,alignItems:"center"}}>
                        <span style={{fontFamily:"'Orbitron',monospace",fontSize:12,color:t.pnl>=0?"#00C97A":"#F43F5E",fontWeight:600}}>{t.pnl>=0?"+":"-"}${Math.abs(t.pnl).toFixed(0)}</span>
                        <span style={{color:"rgba(255,255,255,0.2)",fontSize:10,fontFamily:"monospace"}}>{t.time}</span>
                      </div>
                    </div>
                  ))}
                </div>

                <div style={{background:"#161B22",border:"1px solid rgba(255,255,255,0.07)",borderRadius:14,padding:"16px 18px"}}>
                  <div style={{fontWeight:600,fontSize:13,marginBottom:14,color:"rgba(255,255,255,0.8)"}}>Quick Rules Guide</div>
                  {[
                    {icon:"✅",text:"Always trade with a clear stop loss — prop firms breach on drawdown, not losses alone."},
                    {icon:"⚠️",text:"Never risk more than 1–2% per trade. Daily loss limit is typically 4–5% from peak."},
                    {icon:"📅",text:"Meet the minimum trading days requirement before hitting the profit target."},
                    {icon:"🕐",text:"Avoid holding positions over high-impact news events — unexpected volatility kills accounts."},
                    {icon:"💡",text:"Consistency matters more than big wins. Prop firms flag irregular trading patterns."},
                  ].map((r,i)=>(
                    <div key={i} style={{display:"flex",gap:10,padding:"7px 0",borderBottom:i<4?"1px solid rgba(255,255,255,0.04)":"none"}}>
                      <span style={{fontSize:14,flexShrink:0}}>{r.icon}</span>
                      <span style={{color:"rgba(255,255,255,0.5)",fontSize:12,lineHeight:1.5}}>{r.text}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* ─ EVALUATIONS DETAIL ─ */}
          {tab==="evaluations" && selEval && selFirmData && (
            <div style={{padding:"20px 24px",display:"grid",gridTemplateColumns:"360px 1fr",gap:20}}>
              {/* Left: eval list */}
              <div style={{display:"flex",flexDirection:"column",gap:12}}>
                <h3 style={{fontSize:15,fontWeight:600,color:"rgba(255,255,255,0.8)"}}>Your Evaluations</h3>
                {evals.map(ev=>{
                  const firm=PROP_FIRMS.find(f=>f.id===ev.firmId);
                  return <EvalCard key={ev.id} ev={ev} firm={firm} selected={selectedEval===ev.id} onClick={()=>setSelectedEval(ev.id)}/>;
                })}

                {/* Add new button */}
                <button onClick={()=>setTab("firms")} style={{background:"rgba(0,201,122,0.06)",border:"1px dashed rgba(0,201,122,0.2)",borderRadius:14,padding:"16px",cursor:"pointer",color:"rgba(0,201,122,0.6)",fontSize:13,fontWeight:500,transition:"all 0.15s"}}>
                  + Start New Evaluation
                </button>
              </div>

              {/* Right: detail */}
              <div style={{display:"flex",flexDirection:"column",gap:14}}>
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                  <div>
                    <h3 style={{fontSize:18,fontWeight:700,color:"white"}}>{selFirmData.name} — {fmtK(selEval.accountSize)}</h3>
                    <div style={{color:"rgba(255,255,255,0.4)",fontSize:12,marginTop:2}}>Started {selEval.startDate} · Phase {selEval.phase} · {selEval.broker}</div>
                  </div>
                  <Badge status={selEval.status}/>
                </div>

                {/* Key metrics */}
                <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:10}}>
                  {[
                    {l:"Current Balance",  v:fmt$(selEval.currentBalance),            c:"white"},
                    {l:"P&L",              v:`${selEval.currentBalance>=selEval.startBalance?"+":"-"}${fmt$(Math.abs(selEval.currentBalance-selEval.startBalance))}`, c:selEval.currentBalance>=selEval.startBalance?"#00C97A":"#F43F5E"},
                    {l:"Profit Target",    v:fmt$(selEval.profitTarget),              c:selFirmData.color},
                    {l:"Max Drawdown Floor",v:fmt$(selEval.maxDrawdown),             c:"#F43F5E"},
                  ].map(m=>(
                    <div key={m.l} style={{background:"#161B22",borderRadius:10,padding:"12px 14px"}}>
                      <div style={{color:"rgba(255,255,255,0.35)",fontSize:10,marginBottom:5}}>{m.l}</div>
                      <div style={{fontFamily:"'Orbitron',monospace",fontSize:14,fontWeight:700,color:m.c}}>{m.v}</div>
                    </div>
                  ))}
                </div>

                {/* Progress bars */}
                <div style={{background:"#161B22",borderRadius:14,padding:"18px 20px",display:"flex",flexDirection:"column",gap:14}}>
                  <div style={{fontWeight:600,fontSize:13,color:"rgba(255,255,255,0.8)",marginBottom:2}}>Evaluation Progress</div>

                  <Bar
                    value={Math.max(0,selEval.currentBalance-selEval.startBalance)}
                    max={selEval.profitTarget-selEval.startBalance}
                    color={selFirmData.color} height={12}
                    label={`Profit Target (${selFirmData.rules.profitTarget}%)`}
                    sublabel={`${fmt$(selEval.currentBalance)} / ${fmt$(selEval.profitTarget)}`}/>

                  {(() => {
                    const ddUsed = ((selEval.highWaterMark - selEval.currentBalance) / selEval.startBalance) * 100;
                    const maxDD = selFirmData.rules.maxTotalLoss;
                    const ddPct = (ddUsed / maxDD) * 100;
                    return (
                      <Bar value={ddUsed} max={maxDD}
                        color={ddPct>70?"#F43F5E":ddPct>50?"#F59E0B":"#10B981"} height={12}
                        label={`Max Drawdown Used (${ddUsed.toFixed(2)}% / ${maxDD}%)`}
                        sublabel={`${(maxDD-ddUsed).toFixed(2)}% buffer remaining`}/>
                    );
                  })()}

                  <Bar value={selEval.tradingDays} max={selEval.minTradingDays}
                    color={selEval.tradingDays>=selEval.minTradingDays?"#10B981":"#F59E0B"} height={10}
                    label="Minimum Trading Days"
                    sublabel={`${selEval.tradingDays} / ${selEval.minTradingDays} days`}/>
                </div>

                {/* Rules checklist */}
                <div style={{background:"#161B22",borderRadius:14,padding:"18px 20px"}}>
                  <div style={{fontWeight:600,fontSize:13,color:"rgba(255,255,255,0.8)",marginBottom:14}}>Rules Checklist</div>
                  {[
                    {rule:"Profit target not yet hit (no early exit)",   pass:selEval.currentBalance<selEval.profitTarget},
                    {rule:"Above maximum drawdown floor",                 pass:selEval.currentBalance>selEval.maxDrawdown},
                    {rule:"Daily loss limit respected",                   pass:true},
                    {rule:"Minimum trading days met",                     pass:selEval.tradingDays>=selEval.minTradingDays},
                    {rule:"No restricted instruments traded",             pass:true},
                    {rule:"No copy trading / EA prohibited activity",     pass:true},
                  ].map((r,i)=>(
                    <div key={i} style={{display:"flex",gap:10,padding:"8px 0",borderBottom:i<5?"1px solid rgba(255,255,255,0.04)":"none",alignItems:"center"}}>
                      <span style={{fontSize:14,color:r.pass?"#00C97A":"#F43F5E",flexShrink:0}}>{r.pass?"✓":"✗"}</span>
                      <span style={{fontSize:12,color:r.pass?"rgba(255,255,255,0.6)":"rgba(244,63,94,0.8)"}}>{r.rule}</span>
                    </div>
                  ))}
                </div>

                {/* Today's trades */}
                <div style={{background:"#161B22",borderRadius:14,padding:"18px 20px"}}>
                  <div style={{fontWeight:600,fontSize:13,color:"rgba(255,255,255,0.8)",marginBottom:12}}>Today's Trades</div>
                  {selEval.tradesToday.length===0 && <div style={{color:"rgba(255,255,255,0.25)",fontSize:12,textAlign:"center",padding:"10px 0"}}>No trades today</div>}
                  {selEval.tradesToday.slice(0,8).map((t,i)=>(
                    <div key={i} className="trade" style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"8px 0",borderBottom:i<selEval.tradesToday.slice(0,8).length-1?"1px solid rgba(255,255,255,0.04)":"none"}}>
                      <div style={{display:"flex",gap:9,alignItems:"center"}}>
                        <span style={{background:t.side==="BUY"?"rgba(0,201,122,0.1)":"rgba(244,63,94,0.1)",color:t.side==="BUY"?"#00C97A":"#F43F5E",border:`1px solid ${t.side==="BUY"?"rgba(0,201,122,0.3)":"rgba(244,63,94,0.3)"}`,borderRadius:5,padding:"2px 7px",fontSize:9,fontFamily:"monospace"}}>{t.side}</span>
                        <span style={{fontWeight:500,fontSize:13}}>{t.sym}</span>
                      </div>
                      <div style={{display:"flex",gap:12,alignItems:"center"}}>
                        <span style={{fontFamily:"'Orbitron',monospace",fontSize:13,color:t.pnl>=0?"#00C97A":"#F43F5E",fontWeight:600}}>{t.pnl>=0?"+":"-"}${Math.abs(t.pnl).toFixed(0)}</span>
                        <span style={{color:"rgba(255,255,255,0.2)",fontSize:10,fontFamily:"monospace"}}>{t.time}</span>
                      </div>
                    </div>
                  ))}
                  <div style={{marginTop:12,paddingTop:12,borderTop:"1px solid rgba(255,255,255,0.06)",display:"flex",justifyContent:"space-between"}}>
                    <span style={{color:"rgba(255,255,255,0.4)",fontSize:11}}>Today's P&L</span>
                    {(() => {
                      const todayPnl = selEval.tradesToday.reduce((s,t)=>s+t.pnl,0);
                      return <span style={{fontFamily:"'Orbitron',monospace",fontSize:13,color:todayPnl>=0?"#00C97A":"#F43F5E",fontWeight:700}}>{todayPnl>=0?"+":"-"}${Math.abs(todayPnl).toFixed(0)}</span>;
                    })()}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ─ PROP FIRMS ─ */}
          {tab==="firms" && (
            <div style={{padding:"20px 24px"}}>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:16}}>
                <div>
                  <h2 style={{fontSize:16,fontWeight:600,color:"white"}}>Prop Firm Comparison</h2>
                  <div style={{color:"rgba(255,255,255,0.4)",fontSize:12,marginTop:3}}>Real 2026 pricing and rules. Click to start an evaluation.</div>
                </div>
                <div style={{background:"rgba(245,158,11,0.08)",border:"1px solid rgba(245,158,11,0.2)",borderRadius:10,padding:"8px 14px",fontSize:12,color:"#F59E0B"}}>
                  ⚠ Always read the full terms before paying an evaluation fee
                </div>
              </div>
              <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:14}}>
                {PROP_FIRMS.map(firm=>(
                  <FirmCard key={firm.id} firm={firm} onSelect={firm=>{
                    alert(`Visit ${firm.url} to register and start your evaluation.\n\nFee from $${Math.min(...Object.values(firm.fees))}\nProfit target: ${firm.rules.profitTarget}%\nPayout split: ${firm.rules.payoutSplit}%`);
                  }}/>
                ))}
              </div>

              <div style={{background:"rgba(0,212,255,0.04)",border:"1px solid rgba(0,212,255,0.15)",borderRadius:14,padding:"18px 20px",marginTop:20}}>
                <div style={{fontWeight:600,fontSize:13,color:"#00D4FF",marginBottom:10}}>ℹ How to Connect Your Trading Platform</div>
                <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:16}}>
                  {[
                    {title:"MT4/MT5 (Forex)", steps:["Register on firm website","Complete ID verification","Receive MT5 server credentials by email","Login: File → Login to Trading Account","Enter server, login, password from email","Start trading — balance updates live"]},
                    {title:"Rithmic (Futures)", steps:["Register on Apex/TopStep","Download Rithmic R|Trader Pro","Enter connection: server + credentials","Or connect to NinjaTrader / TradeStation","API keys available for algorithmic trading","Use ccxt or rithmic-sdk for automation"]},
                    {title:"API / Algo Trading", steps:["Most firms allow EAs and algos","FTMO: MT5 EA allowed, no martingale","Apex: Rithmic API available","Connect your strategy to firm broker","Stay within drawdown/risk rules","Log every trade for compliance proof"]},
                  ].map(s=>(
                    <div key={s.title}>
                      <div style={{fontWeight:600,fontSize:12,color:"rgba(255,255,255,0.7)",marginBottom:10}}>{s.title}</div>
                      {s.steps.map((step,i)=>(
                        <div key={i} style={{display:"flex",gap:8,marginBottom:7,alignItems:"flex-start"}}>
                          <span style={{background:"rgba(0,212,255,0.1)",color:"#00D4FF",borderRadius:"50%",width:18,height:18,display:"flex",alignItems:"center",justifyContent:"center",fontSize:9,fontFamily:"monospace",flexShrink:0,marginTop:1}}>{i+1}</span>
                          <span style={{color:"rgba(255,255,255,0.45)",fontSize:11,lineHeight:1.5}}>{step}</span>
                        </div>
                      ))}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* ─ PAYOUTS ─ */}
          {tab==="payouts" && (
            <div style={{padding:"20px 24px",display:"flex",flexDirection:"column",gap:16}}>
              <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:12}}>
                {[
                  {l:"Total Received", v:`$${totalPaid.toLocaleString()}`,   c:"#00C97A", icon:"✅"},
                  {l:"Pending",        v:`$${totalPending.toLocaleString()}`, c:"#F59E0B", icon:"⏳"},
                  {l:"Payouts Count",  v:payouts.filter(p=>p.status==="Paid").length, c:"#00D4FF", icon:"📋"},
                  {l:"Avg Payout",     v:`$${(totalPaid/Math.max(1,payouts.filter(p=>p.status==="Paid").length)).toFixed(0).replace(/\B(?=(\d{3})+(?!\d))/g,",")}`, c:"#A78BFA", icon:"📊"},
                ].map(s=>(
                  <div key={s.l} style={{background:"#161B22",border:`1px solid rgba(${hexRgb(s.c)},0.15)`,borderRadius:12,padding:"16px 18px"}}>
                    <div style={{display:"flex",justifyContent:"space-between",marginBottom:10}}>
                      <span style={{fontSize:11,color:"rgba(255,255,255,0.4)"}}>{s.l}</span>
                      <span style={{fontSize:18}}>{s.icon}</span>
                    </div>
                    <div style={{fontFamily:"'Orbitron',monospace",fontSize:20,fontWeight:700,color:s.c}}>{s.v}</div>
                  </div>
                ))}
              </div>

              <div style={{background:"#161B22",border:"1px solid rgba(255,255,255,0.07)",borderRadius:14,padding:"18px 20px"}}>
                <div style={{fontWeight:600,fontSize:14,marginBottom:16}}>Payout History</div>
                <table style={{width:"100%",borderCollapse:"collapse"}}>
                  <thead>
                    <tr style={{borderBottom:"1px solid rgba(255,255,255,0.08)"}}>
                      {["ID","Firm","Amount","Date","Method","Status"].map(h=>(
                        <th key={h} style={{textAlign:"left",padding:"8px 12px",color:"rgba(255,255,255,0.3)",fontSize:10,fontWeight:500,letterSpacing:1,fontFamily:"monospace"}}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {payouts.map(p=>(
                      <tr key={p.id} style={{borderBottom:"1px solid rgba(255,255,255,0.04)"}}>
                        <td style={{padding:"12px",fontFamily:"monospace",fontSize:12,color:"rgba(255,255,255,0.5)"}}>{p.id}</td>
                        <td style={{padding:"12px",fontWeight:500,fontSize:13}}>{p.firm}</td>
                        <td style={{padding:"12px",fontFamily:"'Orbitron',monospace",fontSize:13,fontWeight:600,color:"white"}}>${p.amount.toLocaleString()}</td>
                        <td style={{padding:"12px",color:"rgba(255,255,255,0.5)",fontSize:12}}>{p.date}</td>
                        <td style={{padding:"12px",color:"rgba(255,255,255,0.5)",fontSize:12,fontFamily:"monospace"}}>{p.method}</td>
                        <td style={{padding:"12px"}}>
                          <span style={{background:p.status==="Paid"?"rgba(0,201,122,0.1)":"rgba(245,158,11,0.1)",color:p.status==="Paid"?"#00C97A":"#F59E0B",border:`1px solid ${p.status==="Paid"?"rgba(0,201,122,0.3)":"rgba(245,158,11,0.3)"}`,borderRadius:6,padding:"3px 10px",fontSize:10,fontFamily:"monospace"}}>{p.status}</span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div style={{background:"rgba(0,201,122,0.04)",border:"1px solid rgba(0,201,122,0.15)",borderRadius:14,padding:"18px 20px"}}>
                <div style={{fontWeight:600,fontSize:13,color:"#00C97A",marginBottom:12}}>How Payouts Work</div>
                <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:16}}>
                  {[
                    {firm:"FTMO",title:"Monthly Bank Wire",desc:"Request payout from your FTMO dashboard after the monthly period. Processed within 1–2 business days. Minimum $100. Bank wire or USDT."},
                    {firm:"Apex",title:"Every 2 Weeks",desc:"Automatic payout every 2 weeks from profit split date. Receives directly to Deel or bank. 90% of profits above initial balance."},
                    {firm:"TopStep",title:"Weekly Payouts",desc:"Request via TopStep dashboard every Monday after $200 minimum. Processed same week. Wire or ACH (US). 90/10 split."},
                  ].map(p=>(
                    <div key={p.firm} style={{background:"rgba(0,0,0,0.2)",borderRadius:10,padding:"14px"}}>
                      <div style={{fontWeight:600,fontSize:12,color:"white",marginBottom:4}}>{p.firm} — {p.title}</div>
                      <div style={{color:"rgba(255,255,255,0.45)",fontSize:11,lineHeight:1.6}}>{p.desc}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
}
