import { useState, useEffect, useRef, useMemo } from "react";

// ─── 2026 REAL MARKET DATA ────────────────────────────────────────────────────
// Live as of May 2, 2026 — sourced from CoinGecko/TheBlock/CoinDesk
const MARKET_2026 = {
  fearGreed: 26,           // Fear territory — recovered from 8/100 in April
  btcDominance: 58.5,      // BTC dominance elevated
  totalMarketCap: 2683,    // $2.683T
  volume24h: 79.8,         // $79.8B
  ethGasGwei: 0.261,
  stablecoinVol: 166.85,   // $166.85B — 138% of total market vol
  defiVol: 8.16,
};

// Real 2026 asset universe — crypto + RWA + perps + AI tokens
const ASSETS_2026 = [
  // Core crypto — actual May 2 2026 prices
  { sym:"BTC",   name:"Bitcoin",          price:78244, vol:0.62, mu:0.45, cat:"L1",        color:"#F7931A" },
  { sym:"ETH",   name:"Ethereum",         price:2295,  vol:0.71, mu:0.28, cat:"L1",        color:"#627EEA" },
  { sym:"SOL",   name:"Solana",           price:83.74, vol:0.88, mu:0.55, cat:"L1",        color:"#9945FF" },
  { sym:"XRP",   name:"XRP",              price:1.39,  vol:0.82, mu:0.35, cat:"L1",        color:"#00AAE4" },
  { sym:"LINK",  name:"Chainlink",        price:9.09,  vol:0.75, mu:0.40, cat:"ORACLE",    color:"#375BD2" },
  { sym:"TAO",   name:"Bittensor",        price:312,   vol:1.15, mu:0.80, cat:"AI",        color:"#7FBA00" },
  // 2026 new force — Real World Assets & perps
  { sym:"ONDO",  name:"Ondo Finance",     price:0.89,  vol:0.95, mu:0.65, cat:"RWA",       color:"#00C2FF" },
  { sym:"ENA",   name:"Ethena",           price:0.42,  vol:1.10, mu:0.55, cat:"STABLECOIN",color:"#8B5CF6" },
  // Traditional — macro backdrop
  { sym:"SPY",   name:"S&P 500 ETF",      price:542,   vol:0.16, mu:0.12, cat:"EQUITIES",  color:"#10B981" },
  { sym:"GOLD",  name:"Gold",             price:3245,  vol:0.13, mu:0.08, cat:"COMMODITY", color:"#F59E0B" },
  { sym:"DXY",   name:"US Dollar Index",  price:99.2,  vol:0.07, mu:-0.02,cat:"FX",        color:"#6B7280" },
  { sym:"BTC.P", name:"BTC Perp (Bybit)", price:78198, vol:0.63, mu:0.45, cat:"PERP",      color:"#FF6B35" },
];

// 2026 market regime parameters
const REGIME_2026 = {
  name: "FEAR CONSOLIDATION",
  color: "#F59E0B",
  description: "BTC rangebound $75K–$80K. ETF inflows sustaining floor. Senate Clarity Act catalyst pending.",
  btcEtfDailyInflow: 630,   // $630M/day BlackRock IBIT
  fundingRate: -0.012,       // slightly negative — bearish bias
  openInterest: 28.4,        // $28.4B BTC OI
  liquidations24h: 142,      // $142M liquidated
  whaleAccumulation: 270000, // 270K BTC accumulated by whales in April
};

// ─── REALISTIC MARKET ENGINE (GBM + GARCH + 2026 calibration) ────────────────
class Engine2026 {
  constructor(asset) {
    this.asset = asset;
    this.price = asset.price;
    this.vol = asset.vol / Math.sqrt(252 * 390);
    this.annualVol = asset.vol;
    this.mu = asset.mu / (252 * 390);
    this.lastReturn = 0;
    this.lastVol = this.vol;
    this.history = this._initHistory();
    this.fundingRate = REGIME_2026.fundingRate * (asset.cat === "PERP" ? 1 : 0);
  }

  _initHistory() {
    const h = [this.price];
    for (let i = 1; i < 120; i++) {
      const prev = h[h.length - 1];
      const r = this.mu + this.annualVol / Math.sqrt(252 * 390) * this._randn();
      h.push(Math.max(prev * Math.exp(r), 0.001));
    }
    return h;
  }

  _randn() {
    let u = 0, v = 0;
    while (!u) u = Math.random();
    while (!v) v = Math.random();
    return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
  }

  tick() {
    // GARCH(1,1) volatility updating
    const omega = 0.000001, alpha = 0.09, beta = 0.90;
    this.lastVol = Math.sqrt(omega + alpha * this.lastReturn ** 2 + beta * this.lastVol ** 2);
    this.lastVol = Math.max(this.vol * 0.4, Math.min(this.vol * 3.5, this.lastVol));

    const dt = 1;
    const drift = this.mu * dt;
    const diff  = this.lastVol * this._randn();

    // 2026 regime: fear suppresses upside, BTC ETF inflows add slight positive drift for BTC
    const regimeBias = this.asset.sym === "BTC" ? 0.000008 : 0;
    // DXY has inverse correlation to crypto in 2026
    const dxyBias = this.asset.sym === "DXY" ? 0.000002 : 0;

    // Rare jump (geopolitical shock, whale move, regulatory news)
    const jumpProb = this.asset.cat === "AI" ? 0.004 : 0.0015;
    const jump = Math.random() < jumpProb ? this._randn() * this.annualVol * 0.03 : 0;

    const logReturn = drift + diff + regimeBias + dxyBias + jump;
    this.lastReturn = logReturn;
    this.price = Math.max(this.price * Math.exp(logReturn), 0.0001);
    this.history.push(this.price);
    if (this.history.length > 300) this.history.shift();
    return this.price;
  }

  // Monte Carlo probability cloud — 200 paths, 30 steps forward
  probCloud(steps = 30) {
    const paths = Array.from({ length: 200 }, () => {
      let p = this.price;
      return Array.from({ length: steps + 1 }, (_, i) => {
        if (i === 0) return p;
        const r = this.mu + this.lastVol * this._randn();
        p = p * Math.exp(r);
        return p;
      });
    });
    return Array.from({ length: steps + 1 }, (_, i) => {
      const vals = paths.map(p => p[i]).sort((a, b) => a - b);
      const n = vals.length;
      return {
        p5:  vals[Math.floor(n * 0.05)],
        p25: vals[Math.floor(n * 0.25)],
        p50: vals[Math.floor(n * 0.50)],
        p75: vals[Math.floor(n * 0.75)],
        p95: vals[Math.floor(n * 0.95)],
      };
    });
  }

  // RSI
  rsi(period = 14) {
    const h = this.history.slice(-period - 1);
    if (h.length < period + 1) return 50;
    let gains = 0, losses = 0;
    for (let i = 1; i < h.length; i++) {
      const d = h[i] - h[i - 1];
      d > 0 ? (gains += d) : (losses += Math.abs(d));
    }
    const rs = gains / (losses || 1e-10);
    return 100 - 100 / (1 + rs);
  }

  // Bollinger Bands
  bb(period = 20) {
    const h = this.history.slice(-period);
    const mean = h.reduce((a, b) => a + b, 0) / h.length;
    const std  = Math.sqrt(h.reduce((a, b) => a + (b - mean) ** 2, 0) / h.length);
    return { upper: mean + 2 * std, lower: mean - 2 * std, mid: mean, std, pct: ((this.price - (mean - 2*std)) / (4 * std)) * 100 };
  }

  // ATR (14)
  atr(period = 14) {
    const h = this.history.slice(-period - 1);
    if (h.length < 2) return 0;
    const trs = [];
    for (let i = 1; i < h.length; i++) trs.push(Math.abs(h[i] - h[i-1]));
    return trs.reduce((a, b) => a + b, 0) / trs.length;
  }

  get pctChange() {
    const prev = this.history[this.history.length - 2] || this.price;
    return (this.price - prev) / prev * 100;
  }

  get pctChange24h() {
    const prev = this.history[Math.max(0, this.history.length - 30)] || this.price;
    return (this.price - prev) / prev * 100;
  }
}

// Init engines
const ENGINES = {};
ASSETS_2026.forEach(a => { ENGINES[a.sym] = new Engine2026(a); });

// ─── 2026 TRADING AGENTS ──────────────────────────────────────────────────────
const AGENTS_2026 = [
  {
    id:"apex",  name:"APEX",  subtitle:"ETF Flow Rider",       color:"#00F5A0", accent:"#00C97A",
    strategy:"Tracks BlackRock IBIT + Fidelity FBTC daily inflow signals. Long BTC on $500M+ inflow days.",
    winProb:0.63, avgWin:2.1, avgLoss:0.9, risk:"HIGH",
    indicators:["ETF Flows","CVD","Funding Rate","OI Change"],
  },
  {
    id:"vega",  name:"VEGA",  subtitle:"Fear/Greed Reversion",  color:"#FF6B35", accent:"#CC4A1A",
    strategy:"Enters long when F&G < 20 (extreme fear). Exits at 55 (greed onset). Calibrated on 2025-26 data.",
    winProb:0.58, avgWin:1.8, avgLoss:1.1, risk:"MEDIUM",
    indicators:["Fear & Greed","BB%B","Volume Profile","Z-Score"],
  },
  {
    id:"nova",  name:"NOVA",  subtitle:"RWA/Perp Arb",          color:"#A78BFA", accent:"#7C3AED",
    strategy:"Exploits BTC spot/perp basis and RWA token mispricing. Monitors funding rates across Binance, Bybit, OKX.",
    winProb:0.71, avgWin:1.3, avgLoss:0.6, risk:"LOW",
    indicators:["Funding Rate","Basis","Perp OI","Cointegration"],
  },
  {
    id:"ares",  name:"ARES",  subtitle:"Whale Order Flow",       color:"#F43F5E", accent:"#BE123C",
    strategy:"Reads on-chain whale movements and dark pool prints. 270K BTC whale accumulation signal active.",
    winProb:0.55, avgWin:3.2, avgLoss:1.8, risk:"VERY HIGH",
    indicators:["On-chain CVD","Exchange Reserves","Whale Alerts","Dark Pool"],
  },
];

// ─── HELPERS ──────────────────────────────────────────────────────────────────
const fmtPrice = (p, sym) => {
  if (p >= 10000) return p.toLocaleString("en", { maximumFractionDigits: 0 });
  if (p >= 100)   return p.toLocaleString("en", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  if (p >= 1)     return p.toLocaleString("en", { minimumFractionDigits: 3, maximumFractionDigits: 3 });
  return p.toFixed(4);
};
const fmtPct = v => (v >= 0 ? "+" : "") + v.toFixed(2) + "%";
const hexToRgb = hex => {
  const r = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return r ? `${parseInt(r[1],16)},${parseInt(r[2],16)},${parseInt(r[3],16)}` : "255,255,255";
};

// ─── QUANTUM CHART CANVAS ─────────────────────────────────────────────────────
function QuantumChart({ symKey, showCloud = true, showBB = true, height = "100%" }) {
  const canvasRef = useRef(null);
  const [tick, setTick] = useState(0);
  useEffect(() => { const iv = setInterval(() => setTick(t => t+1), 700); return () => clearInterval(iv); }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const eng = ENGINES[symKey];
    if (!eng) return;
    const dpr = window.devicePixelRatio || 1;
    const W = canvas.offsetWidth, H = canvas.offsetHeight;
    canvas.width = W * dpr; canvas.height = H * dpr;
    const ctx = canvas.getContext("2d");
    ctx.scale(dpr, dpr);

    const hist = eng.history.slice(-80);
    const cloud = showCloud ? eng.probCloud(24) : null;
    const allP = [...hist, ...(cloud ? [cloud[cloud.length-1].p95, cloud[cloud.length-1].p5] : [])];
    const mn = Math.min(...allP) * 0.997, mx = Math.max(...allP) * 1.003;
    const rng = mx - mn || 1;
    const totalPts = hist.length + (cloud ? cloud.length - 1 : 0);
    const toX = (i) => (i / (totalPts - 1)) * (W - 52);
    const toY = (p) => H - 8 - ((p - mn) / rng) * (H - 16);
    const col = eng.asset.color;
    const isUp = hist[hist.length-1] >= hist[0];
    const lineCol = isUp ? "#00F5A0" : "#F43F5E";

    ctx.clearRect(0, 0, W, H);

    // Grid lines + price labels
    for (let i = 0; i <= 5; i++) {
      const y = 8 + (i / 5) * (H - 16);
      const p = mx - (i / 5) * rng;
      ctx.strokeStyle = "rgba(255,255,255,0.03)";
      ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W - 52, y); ctx.stroke();
      ctx.fillStyle = "rgba(255,255,255,0.22)";
      ctx.font = `${9 * dpr / dpr}px 'Share Tech Mono',monospace`;
      ctx.fillText(fmtPrice(p, symKey), W - 50, y + 3);
    }

    // BB bands
    if (showBB && hist.length > 20) {
      const bbData = hist.map((_, i) => {
        if (i < 19) return null;
        const slice = hist.slice(Math.max(0, i - 19), i + 1);
        const mean = slice.reduce((a, b) => a + b, 0) / slice.length;
        const std = Math.sqrt(slice.reduce((a, b) => a + (b - mean) ** 2, 0) / slice.length);
        return { upper: mean + 2 * std, lower: mean - 2 * std, mid: mean };
      });
      ["upper", "lower", "mid"].forEach((band, bi) => {
        ctx.beginPath();
        bbData.forEach((b, i) => {
          if (!b) return;
          const x = toX(i), y = toY(b[band]);
          i === 19 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
        });
        ctx.strokeStyle = `rgba(${hexToRgb(col)},${bi === 2 ? 0.12 : 0.08})`;
        ctx.lineWidth = bi === 2 ? 1 : 0.8;
        ctx.setLineDash(bi === 2 ? [3, 3] : []);
        ctx.stroke();
        ctx.setLineDash([]);
      });
    }

    // Probability cloud
    if (cloud) {
      const cloudStart = hist.length - 1;
      const bands = [
        { lo: "p5",  hi: "p95", alpha: 0.04 },
        { lo: "p25", hi: "p75", alpha: 0.11 },
      ];
      bands.forEach(({ lo, hi, alpha }) => {
        ctx.beginPath();
        cloud.forEach((b, i) => { const x = toX(cloudStart + i), y = toY(b[hi]); i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y); });
        [...cloud].reverse().forEach((b, i) => { const x = toX(cloudStart + cloud.length - 1 - i), y = toY(b[lo]); ctx.lineTo(x, y); });
        ctx.closePath();
        const g = ctx.createLinearGradient(toX(cloudStart), 0, W - 52, 0);
        g.addColorStop(0, `rgba(${hexToRgb(lineCol)},${alpha * 2})`);
        g.addColorStop(1, `rgba(${hexToRgb(lineCol)},${alpha * 0.3})`);
        ctx.fillStyle = g; ctx.fill();
      });
      // Median dashed
      ctx.beginPath();
      cloud.forEach((b, i) => { const x = toX(cloudStart + i), y = toY(b.p50); i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y); });
      ctx.strokeStyle = `rgba(${hexToRgb(lineCol)},0.45)`;
      ctx.lineWidth = 1.2; ctx.setLineDash([3, 4]); ctx.stroke(); ctx.setLineDash([]);
    }

    // Price area fill
    ctx.beginPath();
    hist.forEach((p, i) => { const x = toX(i), y = toY(p); i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y); });
    ctx.lineTo(toX(hist.length - 1), H); ctx.lineTo(toX(0), H); ctx.closePath();
    const fillG = ctx.createLinearGradient(0, 0, 0, H);
    fillG.addColorStop(0, `rgba(${hexToRgb(lineCol)},0.18)`);
    fillG.addColorStop(1, "rgba(0,0,0,0)");
    ctx.fillStyle = fillG; ctx.fill();

    // Price line
    ctx.beginPath();
    hist.forEach((p, i) => { const x = toX(i), y = toY(p); i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y); });
    ctx.strokeStyle = lineCol; ctx.lineWidth = 2;
    ctx.shadowColor = lineCol; ctx.shadowBlur = 7; ctx.stroke(); ctx.shadowBlur = 0;

    // NOW divider
    const nowX = toX(hist.length - 1);
    ctx.beginPath(); ctx.setLineDash([2, 3]);
    ctx.moveTo(nowX, 0); ctx.lineTo(nowX, H);
    ctx.strokeStyle = "rgba(255,255,255,0.12)"; ctx.lineWidth = 1; ctx.stroke(); ctx.setLineDash([]);

    // Current price dot
    const lastY = toY(hist[hist.length - 1]);
    ctx.beginPath(); ctx.arc(nowX, lastY, 4, 0, Math.PI * 2);
    ctx.fillStyle = lineCol; ctx.shadowColor = lineCol; ctx.shadowBlur = 14; ctx.fill(); ctx.shadowBlur = 0;

    // Labels
    ctx.fillStyle = `rgba(${hexToRgb(lineCol)},0.45)`;
    ctx.font = `8px monospace`;
    if (cloud) ctx.fillText("◈ PROB CLOUD →", nowX + 5, H - 6);
    ctx.fillStyle = "rgba(255,255,255,0.2)";
    ctx.fillText("NOW", nowX + 3, 12);

  }, [tick, symKey, showCloud, showBB]);

  return <canvas ref={canvasRef} style={{ width: "100%", height, display: "block" }} />;
}

// ─── MARKET REGIME BANNER ─────────────────────────────────────────────────────
function RegimeBanner() {
  const fg = REGIME_2026.fearGreed;
  const fgColor = fg < 25 ? "#F43F5E" : fg < 45 ? "#F59E0B" : fg < 75 ? "#10B981" : "#F43F5E";
  const fgLabel = fg < 25 ? "FEAR" : fg < 45 ? "NEUTRAL" : fg < 75 ? "GREED" : "EXTREME GREED";

  return (
    <div style={{ display: "flex", gap: 10, padding: "6px 16px", background: "rgba(2,8,20,0.9)", borderBottom: "1px solid rgba(255,255,255,0.05)", flexShrink: 0, overflowX: "auto", whiteSpace: "nowrap" }}>
      {[
        { l: "REGIME", v: REGIME_2026.name, c: REGIME_2026.color },
        { l: "FEAR/GREED", v: `${fg} — ${fgLabel}`, c: fgColor },
        { l: "BTC DOMINANCE", v: `${MARKET_2026.btcDominance}%`, c: "#F7931A" },
        { l: "MARKET CAP", v: `$${MARKET_2026.totalMarketCap}B`, c: "#00F5A0" },
        { l: "24H VOL", v: `$${MARKET_2026.volume24h}B`, c: "#A78BFA" },
        { l: "ETF INFLOW/DAY", v: `$${REGIME_2026.btcEtfDailyInflow}M`, c: "#00F5A0" },
        { l: "BTC FUNDING", v: `${(REGIME_2026.fundingRate * 100).toFixed(3)}%`, c: REGIME_2026.fundingRate < 0 ? "#F43F5E" : "#00F5A0" },
        { l: "OPEN INTEREST", v: `$${REGIME_2026.openInterest}B`, c: "#F59E0B" },
        { l: "LIQD 24H", v: `$${REGIME_2026.liquidations24h}M`, c: "#F43F5E" },
        { l: "ETH GAS", v: `${MARKET_2026.ethGasGwei} GWEI`, c: "#627EEA" },
      ].map(m => (
        <div key={m.l} style={{ display: "flex", gap: 6, alignItems: "center", padding: "0 8px", borderRight: "1px solid rgba(255,255,255,0.06)" }}>
          <span style={{ color: "rgba(255,255,255,0.3)", fontSize: 8, fontFamily: "monospace", letterSpacing: 1 }}>{m.l}</span>
          <span style={{ color: m.c, fontFamily: "'Orbitron',monospace", fontSize: 9, fontWeight: 600 }}>{m.v}</span>
        </div>
      ))}
    </div>
  );
}

// ─── ASSET ROW ────────────────────────────────────────────────────────────────
function AssetRow({ symKey, selected, onClick }) {
  const [, setT] = useState(0);
  useEffect(() => { const iv = setInterval(() => setT(t => t+1), 900); return () => clearInterval(iv); }, []);
  const eng = ENGINES[symKey];
  const asset = eng.asset;
  const chg = eng.pctChange;
  const chg24 = eng.pctChange24h;
  const rsi = eng.rsi();
  const bb = eng.bb();
  // Mini sparkline
  const h = eng.history.slice(-20);
  const mn = Math.min(...h), mx = Math.max(...h), rng = mx - mn || 1;
  const pts = h.map((v, i) => `${(i/(h.length-1))*60},${24-((v-mn)/rng)*20-2}`).join(" ");
  const lineCol = chg >= 0 ? "#00F5A0" : "#F43F5E";

  const catColors = { L1:"#F7931A", ORACLE:"#375BD2", AI:"#7FBA00", RWA:"#00C2FF", STABLECOIN:"#8B5CF6", EQUITIES:"#10B981", COMMODITY:"#F59E0B", FX:"#6B7280", PERP:"#FF6B35" };

  return (
    <div onClick={onClick} style={{
      display: "flex", alignItems: "center", gap: 8,
      padding: "8px 10px",
      background: selected ? `rgba(${hexToRgb(asset.color)},0.08)` : "transparent",
      borderLeft: `2px solid ${selected ? asset.color : "transparent"}`,
      cursor: "pointer", transition: "all 0.15s",
    }}>
      <div style={{ width: 28, height: 28, borderRadius: 7, background: `rgba(${hexToRgb(asset.color)},0.12)`, border: `1px solid rgba(${hexToRgb(asset.color)},0.3)`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
        <span style={{ fontSize: 8, color: asset.color, fontFamily: "'Orbitron',monospace", fontWeight: 700 }}>{symKey.slice(0,3)}</span>
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <span style={{ fontFamily: "'Orbitron',monospace", fontSize: 10, fontWeight: 700, color: "white", letterSpacing: 1 }}>{symKey}</span>
          <span style={{ fontFamily: "'Orbitron',monospace", fontSize: 10, fontWeight: 600, color: lineCol }}>{fmtPrice(eng.price, symKey)}</span>
        </div>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 2 }}>
          <div style={{ display: "flex", gap: 5 }}>
            <span style={{ background: `rgba(${hexToRgb(catColors[asset.cat]||"255,255,255")},0.1)`, color: catColors[asset.cat]||"white", fontSize: 7, fontFamily: "monospace", padding: "1px 4px", borderRadius: 3, letterSpacing: 0.5 }}>{asset.cat}</span>
            <span style={{ fontSize: 8, color: lineCol, fontFamily: "monospace" }}>{fmtPct(chg24)}</span>
          </div>
          <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
            <span style={{ fontSize: 7, color: rsi > 70 ? "#F43F5E" : rsi < 30 ? "#00F5A0" : "rgba(255,255,255,0.3)", fontFamily: "monospace" }}>RSI {rsi.toFixed(0)}</span>
          </div>
        </div>
      </div>
      <svg width="60" height="24" style={{ flexShrink: 0 }}>
        <polygon points={`0,24 ${pts} 60,24`} fill={`rgba(${hexToRgb(lineCol)},0.15)`}/>
        <polyline points={pts} fill="none" stroke={lineCol} strokeWidth="1.5"/>
      </svg>
    </div>
  );
}

// ─── AGENT CARD ───────────────────────────────────────────────────────────────
function AgentCard({ agent, selected, onClick, pnl, winRate, trades, status, openPnl }) {
  const isPos = pnl >= 0;
  return (
    <div onClick={onClick} style={{
      background: selected ? `rgba(${hexToRgb(agent.color)},0.1)` : "rgba(4,10,28,0.85)",
      border: `1px solid ${selected ? agent.color : "rgba(255,255,255,0.07)"}`,
      borderRadius: 12, padding: "13px 15px", cursor: "pointer",
      transition: "all 0.2s", position: "relative", overflow: "hidden",
      boxShadow: selected ? `0 0 22px rgba(${hexToRgb(agent.color)},0.15)` : "none",
    }}>
      {selected && <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: 2, background: `linear-gradient(90deg,transparent,${agent.color},transparent)` }} />}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 8 }}>
        <div>
          <div style={{ fontFamily: "'Orbitron',monospace", fontSize: 13, fontWeight: 900, color: agent.color, letterSpacing: 3, textShadow: `0 0 14px ${agent.color}44` }}>{agent.name}</div>
          <div style={{ color: "rgba(255,255,255,0.3)", fontSize: 8, fontFamily: "monospace", letterSpacing: 1, marginTop: 1 }}>{agent.subtitle}</div>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 5, background: `rgba(${hexToRgb(agent.color)},0.08)`, border: `1px solid rgba(${hexToRgb(agent.color)},0.25)`, borderRadius: 20, padding: "3px 8px" }}>
          <div style={{ width: 5, height: 5, borderRadius: "50%", background: agent.color, animation: status === "EXECUTING" ? "qPulse 1s infinite" : "none", boxShadow: `0 0 5px ${agent.color}` }} />
          <span style={{ fontSize: 7, color: agent.color, fontFamily: "monospace", letterSpacing: 1 }}>{status}</span>
        </div>
      </div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end" }}>
        <div>
          <div style={{ fontFamily: "'Orbitron',monospace", fontSize: 15, fontWeight: 700, color: isPos ? "#00F5A0" : "#F43F5E" }}>
            {isPos ? "+" : "-"}${Math.abs(pnl).toFixed(0).replace(/\B(?=(\d{3})+(?!\d))/g, ",")}
          </div>
          <div style={{ color: "rgba(255,255,255,0.25)", fontSize: 8, fontFamily: "monospace", marginTop: 2 }}>
            {winRate.toFixed(1)}% WIN · {trades} EX · OPEN: <span style={{ color: openPnl >= 0 ? "#00F5A0" : "#F43F5E" }}>{openPnl >= 0 ? "+" : "-"}${Math.abs(openPnl).toFixed(0)}</span>
          </div>
        </div>
        <span style={{ fontSize: 8, color: `rgba(${hexToRgb(agent.color)},0.5)`, fontFamily: "monospace", background: `rgba(${hexToRgb(agent.color)},0.06)`, border: `1px solid rgba(${hexToRgb(agent.color)},0.15)`, borderRadius: 4, padding: "2px 6px" }}>{agent.risk}</span>
      </div>
    </div>
  );
}

// ─── MAIN DASHBOARD ───────────────────────────────────────────────────────────
export default function QuantumDash2026() {
  const [activeSym, setActiveSym]   = useState("BTC");
  const [activeAgent, setActiveAgent] = useState(0);
  const [tick, setTick]             = useState(0);
  const [activeTab, setActiveTab]   = useState("market");
  const [showWithdraw, setShowWithdraw] = useState(false);
  const [withdrawAmt, setWithdrawAmt] = useState("");
  const [withdrawStep, setWithdrawStep] = useState(1);

  const [agentState, setAgentState] = useState(() =>
    AGENTS_2026.map(a => ({
      pnl: (Math.random() - 0.3) * 55000,
      trades: Math.floor(Math.random() * 500) + 80,
      winRate: a.winProb * 100,
      equity: Array.from({ length: 50 }, (_, i) => 100000 + (Math.random() - 0.38) * 5000 * i),
      status: ["HUNTING", "ANALYZING", "EXECUTING", "STANDBY"][Math.floor(Math.random() * 4)],
      feed: [],
      openPnl: (Math.random() - 0.5) * 6000,
    }))
  );

  // Drive market engines
  useEffect(() => {
    const iv = setInterval(() => {
      Object.values(ENGINES).forEach(e => e.tick());
      setTick(t => t + 1);
    }, 700);
    return () => clearInterval(iv);
  }, []);

  // Drive agent simulation
  useEffect(() => {
    const iv = setInterval(() => {
      setAgentState(prev => prev.map((s, i) => {
        const a = AGENTS_2026[i];
        s.openPnl += (Math.random() - 0.5) * 400;
        if (Math.random() > 0.18) return { ...s };
        const isWin = Math.random() < a.winProb;
        const delta = (isWin ? a.avgWin : -a.avgLoss) * (400 + Math.random() * 1600);
        const syms = Object.keys(ENGINES);
        const sym = syms[Math.floor(Math.random() * syms.length)];
        const trade = { id: Date.now() + Math.random(), sym, side: Math.random() > 0.5 ? "LONG" : "SHORT", pnl: delta, t: new Date().toLocaleTimeString("en", { hour: "2-digit", minute: "2-digit", second: "2-digit" }), win: isWin };
        const statuses = ["HUNTING", "ANALYZING", "EXECUTING", "STANDBY", "IN POSITION"];
        return {
          ...s,
          pnl: s.pnl + delta,
          trades: s.trades + 1,
          winRate: s.winRate * 0.997 + (isWin ? 1 : 0) * 0.3,
          status: Math.random() < 0.1 ? statuses[Math.floor(Math.random() * statuses.length)] : s.status,
          equity: [...s.equity.slice(-49), (s.equity[s.equity.length - 1] || 100000) + delta],
          feed: [trade, ...s.feed.slice(0, 8)],
          openPnl: s.openPnl,
        };
      }));
    }, 1100);
    return () => clearInterval(iv);
  }, []);

  const totalPnl = agentState.reduce((s, a) => s + a.pnl, 0);
  const portfolioBalance = 285000 + totalPnl;
  const eng = ENGINES[activeSym];
  const ag  = AGENTS_2026[activeAgent];
  const ags = agentState[activeAgent];

  const TABS = [
    { id: "market",  label: "MARKET",   icon: "◈" },
    { id: "agents",  label: "AGENTS",   icon: "⬡" },
    { id: "perps",   label: "PERPS/RWA",icon: "▦" },
    { id: "macro",   label: "MACRO",    icon: "◉" },
  ];

  const statusColor = { HUNTING: "#00F5A0", ANALYZING: "#F59E0B", EXECUTING: "#3B82F6", STANDBY: "#4B5563", "IN POSITION": "#F43F5E" };

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@400;600;700;900&family=Syne:wght@400;500;600;700;800&family=Share+Tech+Mono&display=swap');
        *{box-sizing:border-box;margin:0;padding:0;}
        html,body{height:100%;background:#020C1B;overflow:hidden;}
        ::-webkit-scrollbar{width:2px;height:2px;}
        ::-webkit-scrollbar-thumb{background:rgba(0,245,160,0.15);border-radius:1px;}
        @keyframes qPulse{0%,100%{opacity:1;box-shadow:0 0 6px currentColor}50%{opacity:0.3;box-shadow:0 0 16px currentColor}}
        @keyframes scanH{0%{top:-1px}100%{top:100%}}
        @keyframes fadeUp{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}
        @keyframes spin{to{transform:rotate(360deg)}}
        @keyframes tradeIn{from{opacity:0;transform:translateX(10px)}to{opacity:1;transform:translateX(0)}}
        .fadein{animation:fadeUp 0.3s ease both;}
        .tradein{animation:tradeIn 0.25s ease both;}
        input[type=number]{-moz-appearance:textfield;}
        input::-webkit-outer-spin-button,input::-webkit-inner-spin-button{-webkit-appearance:none;}
        select option{background:#020C1B;color:white;}
      `}</style>

      {/* WITHDRAW MODAL */}
      {showWithdraw && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.85)", backdropFilter: "blur(12px)", zIndex: 1000, display: "flex", alignItems: "center", justifyContent: "center" }}>
          <div style={{ background: "linear-gradient(135deg,rgba(4,12,32,0.99),rgba(2,8,20,0.99))", border: "1px solid rgba(0,245,160,0.25)", borderRadius: 20, padding: 32, width: 500, position: "relative" }}>
            <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: 2, background: "linear-gradient(90deg,transparent,#00F5A0,transparent)", borderRadius: "20px 20px 0 0" }} />
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 20 }}>
              <div>
                <div style={{ fontFamily: "'Orbitron',monospace", fontSize: 16, color: "#00F5A0", letterSpacing: 3, fontWeight: 900 }}>WITHDRAWAL PORTAL</div>
                <div style={{ color: "rgba(255,255,255,0.3)", fontSize: 9, fontFamily: "monospace", marginTop: 3 }}>SECURE FUND EXTRACTION · 2026</div>
              </div>
              <button onClick={() => { setShowWithdraw(false); setWithdrawStep(1); setWithdrawAmt(""); }} style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 7, width: 30, height: 30, cursor: "pointer", color: "rgba(255,255,255,0.5)", fontSize: 16 }}>×</button>
            </div>
            <div style={{ background: "rgba(0,245,160,0.05)", border: "1px solid rgba(0,245,160,0.15)", borderRadius: 10, padding: "12px 16px", marginBottom: 20 }}>
              <div style={{ color: "rgba(255,255,255,0.3)", fontSize: 8, fontFamily: "monospace", letterSpacing: 2, marginBottom: 4 }}>AVAILABLE BALANCE</div>
              <div style={{ fontFamily: "'Orbitron',monospace", fontSize: 26, fontWeight: 900, color: "#00F5A0" }}>${portfolioBalance.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ",")}</div>
            </div>
            {withdrawStep === 1 && (<>
              <div style={{ marginBottom: 14 }}>
                <div style={{ color: "rgba(255,255,255,0.3)", fontSize: 8, fontFamily: "monospace", letterSpacing: 2, marginBottom: 7 }}>AMOUNT (USD)</div>
                <div style={{ display: "flex", gap: 8 }}>
                  <input type="number" value={withdrawAmt} onChange={e => setWithdrawAmt(e.target.value)} placeholder="0.00" style={{ flex: 1, background: "rgba(2,8,20,0.9)", border: "1px solid rgba(0,245,160,0.2)", borderRadius: 8, padding: "11px 14px", color: "white", fontFamily: "'Orbitron',monospace", fontSize: 18, fontWeight: 700, outline: "none" }} />
                  <button onClick={() => setWithdrawAmt((portfolioBalance * 0.95).toFixed(2))} style={{ background: "rgba(0,245,160,0.08)", border: "1px solid rgba(0,245,160,0.25)", borderRadius: 8, padding: "0 14px", cursor: "pointer", color: "#00F5A0", fontFamily: "monospace", fontSize: 9, letterSpacing: 1 }}>MAX</button>
                </div>
              </div>
              <div style={{ marginBottom: 16 }}>
                <div style={{ color: "rgba(255,255,255,0.3)", fontSize: 8, fontFamily: "monospace", letterSpacing: 2, marginBottom: 7 }}>DESTINATION (BTC ADDRESS)</div>
                <input placeholder="bc1q... or 0x..." style={{ width: "100%", background: "rgba(2,8,20,0.9)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 8, padding: "10px 14px", color: "white", fontFamily: "monospace", fontSize: 12, outline: "none" }} />
              </div>
              {parseFloat(withdrawAmt) > 0 && (
                <div style={{ background: "rgba(2,8,20,0.8)", border: "1px solid rgba(255,255,255,0.05)", borderRadius: 8, padding: "12px 14px", marginBottom: 14 }}>
                  {[["AMOUNT", `$${parseFloat(withdrawAmt).toFixed(2)}`], ["NETWORK FEE (0.1%)", `-$${(parseFloat(withdrawAmt) * 0.001 + 2.5).toFixed(2)}`], ["YOU RECEIVE", `$${(parseFloat(withdrawAmt) - parseFloat(withdrawAmt) * 0.001 - 2.5).toFixed(2)}`]].map(([l, v], i) => (
                    <div key={l} style={{ display: "flex", justifyContent: "space-between", padding: "4px 0" }}>
                      <span style={{ color: "rgba(255,255,255,0.3)", fontSize: 10, fontFamily: "monospace" }}>{l}</span>
                      <span style={{ fontFamily: "'Orbitron',monospace", fontSize: 11, color: i === 2 ? "#00F5A0" : i === 1 ? "#F43F5E" : "white" }}>{v}</span>
                    </div>
                  ))}
                </div>
              )}
              <button onClick={() => setWithdrawStep(2)} style={{ width: "100%", background: "linear-gradient(135deg,#00C97A,#008844)", border: "none", borderRadius: 10, padding: "13px", cursor: "pointer", color: "#020C1B", fontFamily: "'Orbitron',monospace", fontWeight: 900, fontSize: 12, letterSpacing: 3, opacity: parseFloat(withdrawAmt) > 0 ? 1 : 0.4 }}>REVIEW →</button>
            </>)}
            {withdrawStep === 2 && (<>
              <div style={{ background: "rgba(245,158,11,0.05)", border: "1px solid rgba(245,158,11,0.2)", borderRadius: 10, padding: 16, marginBottom: 18 }}>
                <div style={{ color: "#F59E0B", fontSize: 11, fontFamily: "'Orbitron',monospace", letterSpacing: 2, marginBottom: 10 }}>⚠ CONFIRM — CANNOT BE UNDONE</div>
                {[["AMOUNT", `$${parseFloat(withdrawAmt||0).toFixed(2)}`], ["NET RECEIVE", `$${(parseFloat(withdrawAmt||0) * 0.999 - 2.5).toFixed(2)}`], ["NETWORK", "Bitcoin (BTC)"]].map(([l,v]) => (
                  <div key={l} style={{ display:"flex", justifyContent:"space-between", padding:"5px 0", borderBottom:"1px solid rgba(255,255,255,0.04)" }}>
                    <span style={{ color:"rgba(255,255,255,0.3)", fontSize:10, fontFamily:"monospace"}}>{l}</span>
                    <span style={{ color:"white", fontSize:10, fontFamily:"monospace"}}>{v}</span>
                  </div>
                ))}
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
                <button onClick={() => setWithdrawStep(1)} style={{ background: "rgba(4,12,32,0.9)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 10, padding: "12px", cursor: "pointer", color: "rgba(255,255,255,0.5)", fontFamily: "'Orbitron',monospace", fontSize: 10, letterSpacing: 1 }}>← BACK</button>
                <button onClick={() => setWithdrawStep(3)} style={{ background: "linear-gradient(135deg,#00C97A,#008844)", border: "none", borderRadius: 10, padding: "12px", cursor: "pointer", color: "#020C1B", fontFamily: "'Orbitron',monospace", fontWeight: 900, fontSize: 11, letterSpacing: 2 }}>CONFIRM ✓</button>
              </div>
            </>)}
            {withdrawStep === 3 && (
              <div style={{ textAlign: "center", padding: "10px 0" }}>
                <div style={{ fontSize: 48, color: "#00F5A0", marginBottom: 12, textShadow: "0 0 30px rgba(0,245,160,0.5)" }}>✓</div>
                <div style={{ fontFamily: "'Orbitron',monospace", fontSize: 16, color: "#00F5A0", letterSpacing: 3, marginBottom: 8 }}>INITIATED</div>
                <div style={{ color: "rgba(255,255,255,0.4)", fontSize: 11, fontFamily: "monospace", lineHeight: 1.8 }}>
                  ${(parseFloat(withdrawAmt||0)*0.999-2.5).toFixed(2)} processing<br/>
                  REF: WD-{Math.floor(Math.random()*9000)+1000}<br/>
                  ETA: 10–30 minutes on-chain
                </div>
                <button onClick={() => { setShowWithdraw(false); setWithdrawStep(1); setWithdrawAmt(""); }} style={{ marginTop: 20, background: "rgba(0,245,160,0.08)", border: "1px solid rgba(0,245,160,0.3)", borderRadius: 10, padding: "10px 24px", cursor: "pointer", color: "#00F5A0", fontFamily: "'Orbitron',monospace", fontSize: 10, letterSpacing: 2 }}>CLOSE</button>
              </div>
            )}
          </div>
        </div>
      )}

      <div style={{ width: "100vw", height: "100vh", display: "flex", flexDirection: "column", background: "radial-gradient(ellipse at 10% 0%,rgba(0,245,160,0.04) 0%,transparent 45%),radial-gradient(ellipse at 90% 100%,rgba(167,139,250,0.03) 0%,transparent 45%),#020C1B", color: "white", fontFamily: "'Syne',sans-serif", overflow: "hidden", position: "relative" }}>
        {/* Grid */}
        <div style={{ position: "fixed", inset: 0, backgroundImage: "linear-gradient(rgba(0,245,160,0.011) 1px,transparent 1px),linear-gradient(90deg,rgba(0,245,160,0.011) 1px,transparent 1px)", backgroundSize: "48px 48px", pointerEvents: "none", zIndex: 0 }} />
        {/* Scanline */}
        <div style={{ position: "fixed", left: 0, right: 0, height: "1px", background: "linear-gradient(90deg,transparent,rgba(0,245,160,0.06),transparent)", animation: "scanH 7s linear infinite", pointerEvents: "none", zIndex: 9999 }} />

        {/* ── HEADER ── */}
        <div style={{ position: "relative", zIndex: 10, flexShrink: 0, background: "rgba(2,12,27,0.96)", backdropFilter: "blur(20px)", borderBottom: "1px solid rgba(255,255,255,0.055)", height: 54, display: "flex", alignItems: "center", padding: "0 16px", gap: 16 }}>
          {/* Logo */}
          <div style={{ display: "flex", alignItems: "center", gap: 10, flexShrink: 0 }}>
            <svg width="32" height="32" viewBox="0 0 32 32">
              <polygon points="16,2 30,10 30,22 16,30 2,22 2,10" fill="none" stroke="#00F5A0" strokeWidth="1.5" style={{ filter: "drop-shadow(0 0 5px #00F5A0)" }} />
              <polygon points="16,8 24,13 24,19 16,24 8,19 8,13" fill="rgba(0,245,160,0.08)" stroke="rgba(0,245,160,0.4)" strokeWidth="1" />
              <circle cx="16" cy="16" r="3" fill="#00F5A0" style={{ filter: "drop-shadow(0 0 4px #00F5A0)" }} />
            </svg>
            <div>
              <div style={{ fontFamily: "'Orbitron',monospace", fontWeight: 900, fontSize: 14, color: "#00F5A0", letterSpacing: 5, textShadow: "0 0 18px rgba(0,245,160,0.4)" }}>NEXUS</div>
              <div style={{ fontFamily: "monospace", fontSize: 7, color: "rgba(255,255,255,0.22)", letterSpacing: 3 }}>QUANTUM OS · MAY 2026</div>
            </div>
          </div>

          {/* Tabs */}
          <div style={{ display: "flex", gap: 2, background: "rgba(2,12,27,0.8)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 9, padding: 3 }}>
            {TABS.map(t => (
              <button key={t.id} onClick={() => setActiveTab(t.id)} style={{ background: activeTab === t.id ? "rgba(0,245,160,0.1)" : "transparent", border: `1px solid ${activeTab === t.id ? "rgba(0,245,160,0.3)" : "transparent"}`, borderRadius: 7, padding: "5px 13px", cursor: "pointer", color: activeTab === t.id ? "#00F5A0" : "rgba(255,255,255,0.35)", fontFamily: "'Orbitron',monospace", fontSize: 9, letterSpacing: 2, transition: "all 0.15s", display: "flex", alignItems: "center", gap: 5 }}>
                <span style={{ fontSize: 10 }}>{t.icon}</span>{t.label}
              </button>
            ))}
          </div>

          {/* Header stats */}
          <div style={{ marginLeft: "auto", display: "flex", gap: 18, alignItems: "center" }}>
            {[
              { l: "PORTFOLIO",  v: `$${portfolioBalance.toFixed(0).replace(/\B(?=(\d{3})+(?!\d))/g, ",")}`, c: "#00F5A0" },
              { l: "P&L",        v: `${totalPnl >= 0 ? "+" : ""}$${Math.abs(totalPnl).toFixed(0).replace(/\B(?=(\d{3})+(?!\d))/g, ",")}`, c: totalPnl >= 0 ? "#00F5A0" : "#F43F5E" },
              { l: "BTC PRICE",  v: `$${fmtPrice(ENGINES["BTC"].price, "BTC")}`, c: "#F7931A" },
              { l: "ETH PRICE",  v: `$${fmtPrice(ENGINES["ETH"].price, "ETH")}`, c: "#627EEA" },
            ].map(s => (
              <div key={s.l} style={{ textAlign: "right" }}>
                <div style={{ fontFamily: "'Orbitron',monospace", fontSize: 13, fontWeight: 700, color: s.c, lineHeight: 1 }}>{s.v}</div>
                <div style={{ color: "rgba(255,255,255,0.2)", fontSize: 7, fontFamily: "monospace", letterSpacing: 2, marginTop: 2 }}>{s.l}</div>
              </div>
            ))}
            <div style={{ display: "flex", alignItems: "center", gap: 6, background: "rgba(0,245,160,0.05)", border: "1px solid rgba(0,245,160,0.18)", borderRadius: 7, padding: "5px 10px" }}>
              <div style={{ width: 6, height: 6, borderRadius: "50%", background: "#00F5A0", animation: "qPulse 1.5s infinite" }} />
              <span style={{ fontSize: 8, color: "rgba(0,245,160,0.8)", fontFamily: "monospace", letterSpacing: 1.5 }}>LIVE</span>
            </div>
            <button onClick={() => setShowWithdraw(true)} style={{ background: "rgba(0,245,160,0.08)", border: "1px solid rgba(0,245,160,0.3)", borderRadius: 8, padding: "7px 14px", cursor: "pointer", color: "#00F5A0", fontFamily: "'Orbitron',monospace", fontSize: 9, letterSpacing: 2, fontWeight: 700, transition: "all 0.2s" }}>↗ WITHDRAW</button>
          </div>
        </div>

        {/* ── REGIME BANNER ── */}
        <RegimeBanner />

        {/* ── CONTENT ── */}
        <div style={{ flex: 1, overflow: "hidden", position: "relative", zIndex: 1 }}>

          {/* MARKET TAB */}
          {activeTab === "market" && (
            <div style={{ display: "grid", gridTemplateColumns: "220px 1fr 260px", height: "100%", overflow: "hidden" }}>

              {/* Asset list */}
              <div style={{ borderRight: "1px solid rgba(255,255,255,0.055)", overflowY: "auto", background: "rgba(2,12,27,0.5)" }}>
                <div style={{ padding: "8px 10px 4px", fontFamily: "'Orbitron',monospace", fontSize: 7, color: "rgba(255,255,255,0.2)", letterSpacing: 3 }}>MARKETS 2026 · {ASSETS_2026.length} ASSETS</div>
                {ASSETS_2026.map(a => <AssetRow key={a.sym} symKey={a.sym} selected={activeSym === a.sym} onClick={() => setActiveSym(a.sym)} />)}
              </div>

              {/* Main chart */}
              <div style={{ display: "flex", flexDirection: "column", overflow: "hidden" }}>
                {/* Chart tabs */}
                <div style={{ flexShrink: 0, display: "flex", gap: 4, padding: "6px 12px 0", borderBottom: "1px solid rgba(255,255,255,0.04)", background: "rgba(2,12,27,0.7)", alignItems: "center" }}>
                  {ASSETS_2026.slice(0, 7).map(a => (
                    <button key={a.sym} onClick={() => setActiveSym(a.sym)} style={{ background: activeSym === a.sym ? `rgba(${hexToRgb(a.color)},0.1)` : "transparent", border: `1px solid ${activeSym === a.sym ? `rgba(${hexToRgb(a.color)},0.35)` : "transparent"}`, borderRadius: "6px 6px 0 0", borderBottom: "none", padding: "4px 11px", cursor: "pointer", color: activeSym === a.sym ? a.color : "rgba(255,255,255,0.3)", fontFamily: "'Orbitron',monospace", fontSize: 8, letterSpacing: 1, transition: "all 0.15s" }}>{a.sym}</button>
                  ))}
                  <div style={{ marginLeft: "auto", display: "flex", gap: 8, paddingBottom: 4, alignItems: "center" }}>
                    <span style={{ fontSize: 7, color: `rgba(${hexToRgb(ENGINES[activeSym]?.asset.color || "#fff")},0.5)`, fontFamily: "monospace" }}>◈ PROB CLOUD</span>
                    <span style={{ fontSize: 7, color: "rgba(255,255,255,0.2)", fontFamily: "monospace" }}>─ BB BANDS</span>
                  </div>
                </div>
                {/* Chart */}
                <div style={{ flex: 1, background: "rgba(2,12,27,0.8)", padding: "4px 6px 2px" }}>
                  <QuantumChart key={activeSym} symKey={activeSym} showCloud showBB height="100%" />
                </div>
              </div>

              {/* Right panel */}
              <div style={{ borderLeft: "1px solid rgba(255,255,255,0.055)", display: "flex", flexDirection: "column", overflow: "hidden", background: "rgba(2,12,27,0.4)" }}>
                {eng && (
                  <>
                    {/* Asset detail */}
                    <div style={{ flexShrink: 0, padding: "12px 14px", borderBottom: "1px solid rgba(255,255,255,0.05)", background: `rgba(${hexToRgb(eng.asset.color)},0.04)` }}>
                      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 12 }}>
                        <div>
                          <div style={{ fontFamily: "'Orbitron',monospace", fontSize: 18, fontWeight: 900, color: eng.asset.color, letterSpacing: 3 }}>{activeSym}</div>
                          <div style={{ color: "rgba(255,255,255,0.35)", fontSize: 10, fontFamily: "monospace" }}>{eng.asset.name}</div>
                        </div>
                        <div style={{ textAlign: "right" }}>
                          <div style={{ fontFamily: "'Orbitron',monospace", fontSize: 18, fontWeight: 700, color: eng.pctChange >= 0 ? "#00F5A0" : "#F43F5E" }}>${fmtPrice(eng.price, activeSym)}</div>
                          <div style={{ fontSize: 10, color: eng.pctChange >= 0 ? "#00F5A0" : "#F43F5E", fontFamily: "monospace" }}>{fmtPct(eng.pctChange24h)}</div>
                        </div>
                      </div>
                      {/* Indicators */}
                      {(() => {
                        const rsi = eng.rsi(), bb = eng.bb(), atr = eng.atr();
                        return (
                          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 7 }}>
                            {[
                              { l: "RSI (14)", v: rsi.toFixed(1), c: rsi > 70 ? "#F43F5E" : rsi < 30 ? "#00F5A0" : "#F59E0B" },
                              { l: "BB %B", v: bb.pct.toFixed(1) + "%", c: bb.pct > 80 ? "#F43F5E" : bb.pct < 20 ? "#00F5A0" : "#F59E0B" },
                              { l: "ATR", v: fmtPrice(atr, activeSym), c: "white" },
                              { l: "VOL REGIME", v: eng.lastVol > eng.vol * 1.5 ? "HIGH" : "NORMAL", c: eng.lastVol > eng.vol * 1.5 ? "#F43F5E" : "#10B981" },
                            ].map(m => (
                              <div key={m.l} style={{ background: "rgba(2,12,27,0.7)", borderRadius: 7, padding: "7px 9px" }}>
                                <div style={{ color: "rgba(255,255,255,0.25)", fontSize: 7, fontFamily: "monospace", letterSpacing: 1, marginBottom: 3 }}>{m.l}</div>
                                <div style={{ fontFamily: "'Orbitron',monospace", fontSize: 11, fontWeight: 700, color: m.c }}>{m.v}</div>
                              </div>
                            ))}
                          </div>
                        );
                      })()}
                    </div>
                    {/* 4 mini charts */}
                    <div style={{ flexShrink: 0, padding: "10px 12px", borderBottom: "1px solid rgba(255,255,255,0.04)" }}>
                      <div style={{ fontFamily: "'Orbitron',monospace", fontSize: 7, color: "rgba(255,255,255,0.2)", letterSpacing: 2, marginBottom: 8 }}>CORRELATED MARKETS</div>
                      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
                        {["ETH", "SOL", "SPY", "GOLD"].filter(s => s !== activeSym).slice(0, 4).map(sym => {
                          const e2 = ENGINES[sym];
                          const c2 = e2.pctChange >= 0 ? "#00F5A0" : "#F43F5E";
                          return (
                            <div key={sym} onClick={() => setActiveSym(sym)} style={{ background: "rgba(2,12,27,0.8)", border: `1px solid ${activeSym === sym ? "rgba(0,245,160,0.2)" : "rgba(255,255,255,0.05)"}`, borderRadius: 7, padding: "6px 8px", cursor: "pointer" }}>
                              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 3 }}>
                                <span style={{ fontFamily: "'Orbitron',monospace", fontSize: 8, color: e2.asset.color }}>{sym}</span>
                                <span style={{ fontSize: 8, color: c2, fontFamily: "monospace" }}>{fmtPct(e2.pctChange)}</span>
                              </div>
                              <div style={{ height: 32 }}>
                                <QuantumChart symKey={sym} showCloud={false} showBB={false} height="100%" />
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                    {/* 2026 context */}
                    <div style={{ flex: 1, padding: "10px 12px", overflowY: "auto" }}>
                      <div style={{ fontFamily: "'Orbitron',monospace", fontSize: 7, color: "rgba(255,255,255,0.2)", letterSpacing: 2, marginBottom: 8 }}>2026 MARKET CONTEXT</div>
                      {[
                        { l: "BTC ETF INFLOWS", v: `$${REGIME_2026.btcEtfDailyInflow}M/day`, note: "BlackRock IBIT leading", c: "#00F5A0" },
                        { l: "FEAR & GREED", v: `${REGIME_2026.fearGreed} — FEAR`, note: "Recovering from 8/100 April low", c: "#F59E0B" },
                        { l: "SENATE CLARITY ACT", v: "Pending", note: "Stablecoin yield compromise cleared", c: "#A78BFA" },
                        { l: "WHALE ACCUMULATION", v: `${(REGIME_2026.whaleAccumulation/1000).toFixed(0)}K BTC`, note: "Exchange reserves 6-year low", c: "#00F5A0" },
                        { l: "STABLECOIN MKTCAP", v: "$191.7B USDT", note: "Tether Q1 profit $10.4B", c: "#627EEA" },
                        { l: "BTC DOMINANCE", v: `${MARKET_2026.btcDominance}%`, note: "Altseason not yet confirmed", c: "#F7931A" },
                      ].map(m => (
                        <div key={m.l} style={{ padding: "7px 0", borderBottom: "1px solid rgba(255,255,255,0.03)" }}>
                          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 2 }}>
                            <span style={{ fontSize: 8, color: "rgba(255,255,255,0.3)", fontFamily: "monospace", letterSpacing: 1 }}>{m.l}</span>
                            <span style={{ fontFamily: "'Orbitron',monospace", fontSize: 9, color: m.c, fontWeight: 600 }}>{m.v}</span>
                          </div>
                          <div style={{ fontSize: 8, color: "rgba(255,255,255,0.2)", fontFamily: "monospace" }}>{m.note}</div>
                        </div>
                      ))}
                    </div>
                  </>
                )}
              </div>
            </div>
          )}

          {/* AGENTS TAB */}
          {activeTab === "agents" && (
            <div style={{ display: "grid", gridTemplateColumns: "260px 1fr 260px", height: "100%", overflow: "hidden" }}>
              {/* Agent roster */}
              <div style={{ borderRight: "1px solid rgba(255,255,255,0.055)", overflowY: "auto", padding: "10px", background: "rgba(2,12,27,0.5)", display: "flex", flexDirection: "column", gap: 10 }}>
                <div style={{ fontFamily: "'Orbitron',monospace", fontSize: 7, color: "rgba(255,255,255,0.2)", letterSpacing: 3, padding: "2px 4px" }}>AGENT ROSTER · 2026</div>
                {AGENTS_2026.map((a, i) => (
                  <AgentCard key={a.id} agent={a} selected={activeAgent === i} onClick={() => setActiveAgent(i)} pnl={agentState[i].pnl} winRate={agentState[i].winRate} trades={agentState[i].trades} status={agentState[i].status} openPnl={agentState[i].openPnl} />
                ))}
                {/* Portfolio total */}
                <div style={{ background: "rgba(4,12,32,0.9)", border: "1px solid rgba(0,245,160,0.15)", borderRadius: 12, padding: "13px 15px", marginTop: 4 }}>
                  <div style={{ color: "rgba(255,255,255,0.2)", fontSize: 7, fontFamily: "monospace", letterSpacing: 2, marginBottom: 8 }}>PORTFOLIO TOTAL</div>
                  <div style={{ fontFamily: "'Orbitron',monospace", fontSize: 20, fontWeight: 700, color: totalPnl >= 0 ? "#00F5A0" : "#F43F5E" }}>{totalPnl >= 0 ? "+" : ""}${Math.abs(totalPnl).toFixed(0).replace(/\B(?=(\d{3})+(?!\d))/g, ",")}</div>
                  <div style={{ color: "rgba(255,255,255,0.25)", fontSize: 9, fontFamily: "monospace", marginTop: 4 }}>Balance: ${portfolioBalance.toFixed(0).replace(/\B(?=(\d{3})+(?!\d))/g, ",")}</div>
                </div>
              </div>

              {/* Agent main view */}
              <div style={{ display: "flex", flexDirection: "column", overflow: "hidden" }}>
                {/* Agent header */}
                <div style={{ flexShrink: 0, padding: "12px 18px", borderBottom: "1px solid rgba(255,255,255,0.05)", background: `rgba(${hexToRgb(ag.color)},0.04)`, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <div>
                    <div style={{ fontFamily: "'Orbitron',monospace", fontSize: 20, fontWeight: 900, color: ag.color, letterSpacing: 4, textShadow: `0 0 20px ${ag.color}55` }}>{ag.name}</div>
                    <div style={{ color: "rgba(255,255,255,0.35)", fontSize: 11, fontFamily: "monospace", marginTop: 3 }}>{ag.subtitle} · {ag.strategy.slice(0, 60)}...</div>
                  </div>
                  <div style={{ display: "flex", alignItems: "center", gap: 6, background: `rgba(${hexToRgb(statusColor[ags.status] || "#4B5563")},0.1)`, border: `1px solid rgba(${hexToRgb(statusColor[ags.status] || "#4B5563")},0.3)`, borderRadius: 20, padding: "4px 12px" }}>
                    <div style={{ width: 6, height: 6, borderRadius: "50%", background: statusColor[ags.status] || "#4B5563", animation: ags.status === "EXECUTING" ? "qPulse 1s infinite" : "none" }} />
                    <span style={{ fontSize: 9, color: statusColor[ags.status] || "#4B5563", fontFamily: "monospace", letterSpacing: 1 }}>{ags.status}</span>
                  </div>
                </div>
                {/* Equity curve */}
                <div style={{ flexShrink: 0, height: "45%", background: "rgba(2,12,27,0.8)", padding: "8px 12px", borderBottom: "1px solid rgba(255,255,255,0.04)" }}>
                  <div style={{ color: "rgba(255,255,255,0.2)", fontSize: 7, fontFamily: "monospace", letterSpacing: 2, marginBottom: 4 }}>EQUITY CURVE</div>
                  {(() => {
                    const eq = ags.equity; if (eq.length < 2) return null;
                    const mn = Math.min(...eq), mx = Math.max(...eq), rng = mx - mn || 1;
                    const W = 500, H = 100;
                    const pts = eq.map((v, i) => `${(i/(eq.length-1))*W},${H-((v-mn)/rng)*(H-8)-4}`).join(" ");
                    const fill = `0,${H} ${pts} ${W},${H}`;
                    const isUp = eq[eq.length-1] >= eq[0];
                    const c = isUp ? "#00F5A0" : "#F43F5E";
                    return (
                      <svg width="100%" viewBox={`0 0 ${W} ${H}`} style={{ overflow: "visible" }}>
                        <defs>
                          <linearGradient id="eqGrad" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="0%" stopColor={c} stopOpacity="0.22" />
                            <stop offset="100%" stopColor={c} stopOpacity="0" />
                          </linearGradient>
                        </defs>
                        <polygon points={fill} fill="url(#eqGrad)" />
                        <polyline points={pts} fill="none" stroke={c} strokeWidth="2" style={{ filter: `drop-shadow(0 0 4px ${c})` }} />
                      </svg>
                    );
                  })()}
                </div>
                {/* Metrics grid */}
                <div style={{ flex: 1, padding: "12px 14px", display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 10, overflowY: "auto" }}>
                  {[
                    { l: "TOTAL P&L", v: `${ags.pnl >= 0 ? "+" : "-"}$${Math.abs(ags.pnl).toFixed(0).replace(/\B(?=(\d{3})+(?!\d))/g,",")}`, c: ags.pnl >= 0 ? "#00F5A0" : "#F43F5E" },
                    { l: "WIN RATE", v: ags.winRate.toFixed(1) + "%", c: ag.color },
                    { l: "EXECUTIONS", v: ags.trades.toLocaleString(), c: "white" },
                    { l: "SHARPE", v: (1.3 + ag.winProb * 1.2).toFixed(2), c: "#A78BFA" },
                    { l: "MAX DD", v: `−${(8 + (1-ag.winProb)*18).toFixed(1)}%`, c: "#F43F5E" },
                    { l: "PROFIT F", v: ((ag.avgWin/ag.avgLoss)*(ag.winProb/(1-ag.winProb))).toFixed(2), c: "#00F5A0" },
                  ].map(m => (
                    <div key={m.l} style={{ background: "rgba(2,12,27,0.8)", border: "1px solid rgba(255,255,255,0.06)", borderRadius: 10, padding: "11px 13px" }}>
                      <div style={{ color: "rgba(255,255,255,0.25)", fontSize: 7, fontFamily: "monospace", letterSpacing: 1.5, marginBottom: 6 }}>{m.l}</div>
                      <div style={{ fontFamily: "'Orbitron',monospace", fontSize: 14, fontWeight: 700, color: m.c }}>{m.v}</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Trade feed */}
              <div style={{ borderLeft: "1px solid rgba(255,255,255,0.055)", display: "flex", flexDirection: "column", overflow: "hidden", background: "rgba(2,12,27,0.4)" }}>
                <div style={{ padding: "10px 12px 6px", flexShrink: 0, display: "flex", justifyContent: "space-between", alignItems: "center", borderBottom: "1px solid rgba(255,255,255,0.04)" }}>
                  <div style={{ fontFamily: "'Orbitron',monospace", fontSize: 7, color: "rgba(255,255,255,0.2)", letterSpacing: 2 }}>LIVE FEED · {ag.name}</div>
                  <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
                    <div style={{ width: 5, height: 5, borderRadius: "50%", background: "#00F5A0", animation: "qPulse 1.2s infinite" }} />
                    <span style={{ fontSize: 7, color: "rgba(0,245,160,0.6)", fontFamily: "monospace" }}>LIVE</span>
                  </div>
                </div>
                <div style={{ flex: 1, overflowY: "auto", padding: "6px 10px", display: "flex", flexDirection: "column", gap: 5 }}>
                  {ags.feed.length === 0 && <div style={{ textAlign: "center", color: "rgba(255,255,255,0.15)", fontSize: 10, fontFamily: "monospace", marginTop: 20 }}>Scanning markets...</div>}
                  {ags.feed.map(t => (
                    <div key={t.id} className="tradein" style={{ background: t.win ? "rgba(0,245,160,0.04)" : "rgba(244,63,94,0.04)", border: `1px solid ${t.win ? "rgba(0,245,160,0.1)" : "rgba(244,63,94,0.08)"}`, borderRadius: 8, padding: "8px 10px", borderLeft: `2px solid ${t.win ? "#00F5A0" : "#F43F5E"}` }}>
                      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                        <div style={{ display: "flex", gap: 7, alignItems: "center" }}>
                          <span style={{ background: t.side === "LONG" ? "rgba(0,245,160,0.1)" : "rgba(244,63,94,0.1)", color: t.side === "LONG" ? "#00F5A0" : "#F43F5E", border: `1px solid ${t.side === "LONG" ? "rgba(0,245,160,0.3)" : "rgba(244,63,94,0.3)"}`, borderRadius: 4, padding: "1px 5px", fontSize: 7, fontFamily: "monospace" }}>{t.side}</span>
                          <span style={{ color: "rgba(255,255,255,0.65)", fontSize: 9, fontFamily: "'Orbitron',monospace", letterSpacing: 1 }}>{t.sym}</span>
                        </div>
                        <div style={{ textAlign: "right" }}>
                          <div style={{ fontFamily: "'Orbitron',monospace", fontSize: 11, color: t.pnl >= 0 ? "#00F5A0" : "#F43F5E", fontWeight: 700 }}>{t.pnl >= 0 ? "+" : "-"}${Math.abs(t.pnl).toFixed(0)}</div>
                          <div style={{ color: "rgba(255,255,255,0.2)", fontSize: 8, fontFamily: "monospace" }}>{t.t}</div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* PERPS/RWA TAB */}
          {activeTab === "perps" && (
            <div style={{ padding: "18px 20px", overflowY: "auto", height: "100%", display: "flex", flexDirection: "column", gap: 16 }}>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 14 }}>
                {[
                  { l: "BTC PERP BASIS", v: `${((ENGINES["BTC.P"].price - ENGINES["BTC"].price) / ENGINES["BTC"].price * 100).toFixed(3)}%`, sub: "Spot/Perp spread", c: "#FF6B35" },
                  { l: "FUNDING RATE", v: `${(REGIME_2026.fundingRate*100).toFixed(3)}%/8h`, sub: "Bearish bias", c: "#F43F5E" },
                  { l: "OPEN INTEREST", v: `$${REGIME_2026.openInterest}B`, sub: "BTC perps", c: "#A78BFA" },
                  { l: "LIQD 24H", v: `$${REGIME_2026.liquidations24h}M`, sub: "Mostly longs", c: "#F43F5E" },
                ].map(m => (
                  <div key={m.l} style={{ background: "rgba(4,12,32,0.9)", border: `1px solid rgba(${hexToRgb(m.c)},0.2)`, borderRadius: 14, padding: "16px 18px" }}>
                    <div style={{ color: "rgba(255,255,255,0.25)", fontSize: 8, fontFamily: "monospace", letterSpacing: 2, marginBottom: 8 }}>{m.l}</div>
                    <div style={{ fontFamily: "'Orbitron',monospace", fontSize: 18, fontWeight: 700, color: m.c }}>{m.v}</div>
                    <div style={{ color: "rgba(255,255,255,0.25)", fontSize: 9, fontFamily: "monospace", marginTop: 4 }}>{m.sub}</div>
                  </div>
                ))}
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
                {/* BTC Perp chart */}
                <div style={{ background: "rgba(4,12,32,0.9)", border: "1px solid rgba(255,107,53,0.15)", borderRadius: 14, padding: "14px 16px" }}>
                  <div style={{ fontFamily: "'Orbitron',monospace", fontSize: 8, color: "#FF6B35", letterSpacing: 2, marginBottom: 8 }}>BTC PERPETUAL · BYBIT/BINANCE</div>
                  <div style={{ height: 160 }}>
                    <QuantumChart symKey="BTC.P" showCloud showBB={false} height="100%" />
                  </div>
                </div>
                {/* RWA tokens */}
                <div style={{ background: "rgba(4,12,32,0.9)", border: "1px solid rgba(0,194,255,0.15)", borderRadius: 14, padding: "14px 16px" }}>
                  <div style={{ fontFamily: "'Orbitron',monospace", fontSize: 8, color: "#00C2FF", letterSpacing: 2, marginBottom: 8 }}>RWA TOKENS · REAL WORLD ASSETS 2026</div>
                  <div style={{ height: 160 }}>
                    <QuantumChart symKey="ONDO" showCloud showBB={false} height="100%" />
                  </div>
                </div>
              </div>
              {/* 2026 DeFi context */}
              <div style={{ background: "rgba(4,12,32,0.9)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 14, padding: "16px 20px" }}>
                <div style={{ fontFamily: "'Orbitron',monospace", fontSize: 8, color: "rgba(255,255,255,0.2)", letterSpacing: 3, marginBottom: 14 }}>2026 STRUCTURAL THEMES — COINBASE INSTITUTIONAL</div>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 14 }}>
                  {[
                    { title: "PERP FUTURES → DEFI", desc: "Perpetual futures integrating with lending, collateral, hedging as core DeFi primitives. Equity perps emerging for 24/7 retail.", color: "#FF6B35" },
                    { title: "PREDICTION MARKETS", desc: "Volume broadening in 2026. Tax changes tilting users to derivative-anchored markets. Aggregators emerging as dominant interface.", color: "#A78BFA" },
                    { title: "STABLECOINS → $1.2T", desc: "Stablecoins cemented as #1 use case. Tether $191.7B reserves. Senate Clarity Act enables yield products. Target $1.2T by 2028.", color: "#627EEA" },
                    { title: "RWA TOKENIZATION", desc: "Real-world assets on-chain accelerating. Tokenized treasuries, real estate, commodities. Ondo Finance leading institutional RWA.", color: "#00C2FF" },
                    { title: "ETF INSTITUTIONALIZATION", desc: "$630M/day BlackRock IBIT inflows absorbing supply despite volatility. DAT 2.0 model: sovereign block space procurement.", color: "#F7931A" },
                    { title: "AI × CRYPTO", desc: "Bittensor (TAO) leading AI token category. On-chain AI compute markets. Agent-based trading infrastructure expanding.", color: "#7FBA00" },
                  ].map(t => (
                    <div key={t.title} style={{ background: `rgba(${hexToRgb(t.color)},0.04)`, border: `1px solid rgba(${hexToRgb(t.color)},0.12)`, borderRadius: 10, padding: "13px 15px" }}>
                      <div style={{ fontFamily: "'Orbitron',monospace", fontSize: 9, color: t.color, letterSpacing: 1.5, marginBottom: 7 }}>{t.title}</div>
                      <div style={{ color: "rgba(255,255,255,0.4)", fontSize: 11, lineHeight: 1.6 }}>{t.desc}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* MACRO TAB */}
          {activeTab === "macro" && (
            <div style={{ padding: "18px 20px", overflowY: "auto", height: "100%", display: "flex", flexDirection: "column", gap: 16 }}>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
                <div style={{ background: "rgba(4,12,32,0.9)", border: "1px solid rgba(16,185,129,0.15)", borderRadius: 14, padding: "14px 16px" }}>
                  <div style={{ fontFamily: "'Orbitron',monospace", fontSize: 8, color: "#10B981", letterSpacing: 2, marginBottom: 8 }}>S&P 500 · MACRO BACKDROP</div>
                  <div style={{ height: 140 }}><QuantumChart symKey="SPY" showCloud showBB height="100%" /></div>
                </div>
                <div style={{ background: "rgba(4,12,32,0.9)", border: "1px solid rgba(245,158,11,0.15)", borderRadius: 14, padding: "14px 16px" }}>
                  <div style={{ fontFamily: "'Orbitron',monospace", fontSize: 8, color: "#F59E0B", letterSpacing: 2, marginBottom: 8 }}>GOLD · SAFE HAVEN</div>
                  <div style={{ height: 140 }}><QuantumChart symKey="GOLD" showCloud showBB height="100%" /></div>
                </div>
              </div>
              <div style={{ background: "rgba(4,12,32,0.9)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 14, padding: "18px 20px" }}>
                <div style={{ fontFamily: "'Orbitron',monospace", fontSize: 8, color: "rgba(255,255,255,0.2)", letterSpacing: 3, marginBottom: 14 }}>MACRO REGIME · MAY 2026</div>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 12 }}>
                  {[
                    { l: "FED RATE", v: "4.25–4.50%", note: "Cut near — BTC fundamentals resilient", c: "#10B981" },
                    { l: "US-IRAN DIPLOMACY", v: "OPTIMISTIC", note: "Oil prices declining on diplomatic news", c: "#00F5A0" },
                    { l: "DOLLAR INDEX", v: `${fmtPrice(ENGINES["DXY"].price, "DXY")}`, note: "Weakening DXY bullish for crypto", c: "#6B7280" },
                    { l: "S&P 500", v: "NEW RECORD", note: "Risk-on sentiment supporting BTC", c: "#10B981" },
                    { l: "CONSENSUS 2026", v: "MAY 5–7", note: "Miami — regulation, tech, ETF trends", c: "#A78BFA" },
                    { l: "STABLECOIN VOL", v: `$${MARKET_2026.stablecoinVol}B`, note: "138% of total market — dominance", c: "#627EEA" },
                    { l: "DEFI VOL", v: `$${MARKET_2026.defiVol}B`, note: "6.77% of total crypto volume", c: "#FF6B35" },
                    { l: "ETH FOUNDATION", v: "SELLING ETH", note: "OTC to BitMine, $47M in 1 week", c: "#F59E0B" },
                  ].map(m => (
                    <div key={m.l} style={{ background: "rgba(2,12,27,0.7)", border: `1px solid rgba(${hexToRgb(m.c)},0.12)`, borderRadius: 10, padding: "12px 14px" }}>
                      <div style={{ color: "rgba(255,255,255,0.25)", fontSize: 7, fontFamily: "monospace", letterSpacing: 1.5, marginBottom: 6 }}>{m.l}</div>
                      <div style={{ fontFamily: "'Orbitron',monospace", fontSize: 12, fontWeight: 700, color: m.c, marginBottom: 4 }}>{m.v}</div>
                      <div style={{ color: "rgba(255,255,255,0.25)", fontSize: 8, fontFamily: "monospace", lineHeight: 1.4 }}>{m.note}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        <style>{`@keyframes ticker{0%{transform:translateX(0)}100%{transform:translateX(-50%)}}`}</style>
      </div>
    </>
  );
}
