import { useState, useEffect, useRef, useCallback } from "react";

// ─── CONSTANTS ────────────────────────────────────────────────────────────────
const AGENTS = [
  { id: "apex", name: "APEX", subtitle: "Momentum Predator", strategy: "Trend + Breakout", color: "#00ff88", accent: "#00cc66", risk: "High", timeframe: "15m–4h", description: "Rides momentum with surgical entries. Cuts losses instantly, lets winners run indefinitely.", indicators: ["RSI", "MACD", "Volume Profile", "ATR"] },
  { id: "vega", name: "VEGA", subtitle: "Volatility Harvester", strategy: "Mean Reversion", color: "#ff6b35", accent: "#cc4a1a", risk: "Medium", timeframe: "1h–1D", description: "Exploits fear and greed cycles. Enters when the crowd panics, exits when they celebrate.", indicators: ["Bollinger Bands", "OBV", "Fear Index", "Z-Score"] },
  { id: "nova", name: "NOVA", subtitle: "Quantum Arbitrageur", strategy: "Statistical Arbitrage", color: "#a78bfa", accent: "#7c3aed", risk: "Low", timeframe: "Tick–5m", description: "Exploits micro-inefficiencies across correlated pairs with sub-millisecond precision.", indicators: ["Correlation Matrix", "Cointegration", "Spread Z", "Kelly Criterion"] },
  { id: "ares", name: "ARES", subtitle: "Order Flow Predator", strategy: "Dark Pool + Tape Reading", color: "#f43f5e", accent: "#be123c", risk: "Very High", timeframe: "1m–30m", description: "Reads institutional order flow. Follows the smart money before the move happens.", indicators: ["Delta", "CVD", "Footprint", "Imbalance"] },
];

const SYMBOLS = ["BTC/USDT", "ETH/USDT", "SOL/USDT", "AAPL", "NVDA", "GOLD", "SPY", "EUR/USD"];
const NETWORKS = ["Ethereum (ERC-20)", "BNB Smart Chain (BEP-20)", "Solana (SPL)", "Polygon (MATIC)", "Arbitrum One", "Avalanche (AVAX-C)"];
const CRYPTO_ASSETS = ["USDT", "USDC", "ETH", "BTC", "SOL", "BNB"];
const BANK_COUNTRIES = ["United States", "United Kingdom", "European Union", "Singapore", "Australia", "Canada"];

function hexToRgb(hex) {
  const r = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return r ? `${parseInt(r[1],16)},${parseInt(r[2],16)},${parseInt(r[3],16)}` : "255,255,255";
}

// ─── HOOKS ────────────────────────────────────────────────────────────────────
function useMarketData() {
  const [prices, setPrices] = useState({ "BTC/USDT":68420,"ETH/USDT":3845,"SOL/USDT":182,"AAPL":214.5,"NVDA":875.3,"GOLD":2345,"SPY":528.4,"EUR/USD":1.0842 });
  const [changes, setChanges] = useState({});
  useEffect(() => {
    const iv = setInterval(() => {
      setPrices(prev => {
        const next = {...prev}; const ch = {};
        Object.keys(next).forEach(s => {
          const v = s.includes("USDT") ? 0.003 : s==="EUR/USD" ? 0.0008 : 0.002;
          const n = next[s] * (1+(Math.random()-0.5)*v);
          ch[s] = n>next[s]?"up":"down"; next[s]=n;
        });
        setChanges(ch); return next;
      });
    }, 800);
    return ()=>clearInterval(iv);
  }, []);
  return { prices, changes };
}

function useAgentSim() {
  const [agents, setAgents] = useState(AGENTS.map(a => ({
    ...a,
    pnl: (Math.random()-0.3)*50000,
    winRate: 55+Math.random()*25,
    trades: Math.floor(Math.random()*500)+50,
    equity: Array.from({length:40},(_,i)=>100000+(Math.random()-0.4)*5000*i),
    recentTrades: [],
    status: ["hunting","analyzing","executing","waiting","in position"][Math.floor(Math.random()*5)],
  })));
  useEffect(() => {
    const iv = setInterval(() => {
      setAgents(prev => prev.map(agent => {
        if(Math.random()>0.15) return agent;
        const isWin = Math.random()<agent.winRate/100;
        const delta = isWin ? Math.random()*2000+200 : -(Math.random()*800+100);
        const sym = SYMBOLS[Math.floor(Math.random()*SYMBOLS.length)];
        const side = Math.random()>0.5?"LONG":"SHORT";
        const trade = { id:Date.now()+Math.random(), symbol:sym, side, pnl:delta, time:new Date().toLocaleTimeString(), win:isWin };
        const statuses = ["hunting","analyzing","executing","waiting","in position"];
        return {
          ...agent,
          pnl: agent.pnl+delta,
          trades: agent.trades+1,
          winRate: agent.winRate*0.995+(isWin?1:0)*0.5,
          status: Math.random()<0.08 ? statuses[Math.floor(Math.random()*statuses.length)] : agent.status,
          equity: [...agent.equity.slice(-39),(agent.equity[agent.equity.length-1]||100000)+delta],
          recentTrades: [trade,...agent.recentTrades.slice(0,6)],
        };
      }));
    }, 1100);
    return ()=>clearInterval(iv);
  }, []);
  return agents;
}

// ─── MINI COMPONENTS ──────────────────────────────────────────────────────────
function GlowDot({ color, pulse }) {
  return (
    <span style={{
      width:8, height:8, borderRadius:"50%", background:color,
      boxShadow:`0 0 8px ${color}`, display:"inline-block",
      animation: pulse?"glowPulse 1.4s ease-in-out infinite":"none"
    }}/>
  );
}

function Tag({ children, color }) {
  return (
    <span style={{
      background:`rgba(${hexToRgb(color)},0.1)`,
      border:`1px solid rgba(${hexToRgb(color)},0.35)`,
      borderRadius:5, padding:"2px 9px", fontSize:9,
      color, fontFamily:"monospace", letterSpacing:1.2,
    }}>{children}</span>
  );
}

function MiniSparkline({ data, color, width=110, height=38 }) {
  if(!data||data.length<2) return null;
  const mn=Math.min(...data), mx=Math.max(...data), range=mx-mn||1;
  const pts = data.map((v,i)=>`${(i/(data.length-1))*width},${height-((v-mn)/range)*(height-6)-3}`).join(" ");
  const fill = `0,${height} ${pts} ${width},${height}`;
  const id = `sg${color.replace(/[^a-z0-9]/gi,"")}`;
  return (
    <svg width={width} height={height} style={{overflow:"visible",flexShrink:0}}>
      <defs>
        <linearGradient id={id} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.28"/>
          <stop offset="100%" stopColor={color} stopOpacity="0"/>
        </linearGradient>
      </defs>
      <polygon points={fill} fill={`url(#${id})`}/>
      <polyline points={pts} fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round"/>
    </svg>
  );
}

function EquityCurve({ data, color }) {
  const W=460, H=110;
  if(!data||data.length<2) return null;
  const mn=Math.min(...data), mx=Math.max(...data), range=mx-mn||1;
  const pts = data.map((v,i)=>`${(i/(data.length-1))*W},${H-((v-mn)/range)*(H-12)-6}`).join(" ");
  const fill=`0,${H} ${pts} ${W},${H}`;
  const chartColor = data[data.length-1]>=data[0]?"#00ff88":"#f43f5e";
  return (
    <svg width="100%" viewBox={`0 0 ${W} ${H}`} style={{overflow:"visible"}}>
      <defs>
        <linearGradient id="eqGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={chartColor} stopOpacity="0.22"/>
          <stop offset="100%" stopColor={chartColor} stopOpacity="0"/>
        </linearGradient>
        <filter id="lineGlow"><feGaussianBlur stdDeviation="2.5" result="blur"/><feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
      </defs>
      <polygon points={fill} fill="url(#eqGrad)"/>
      <polyline points={pts} fill="none" stroke={chartColor} strokeWidth="2.2" strokeLinecap="round" filter="url(#lineGlow)"/>
    </svg>
  );
}

function StatusPill({ status, color }) {
  const map = { hunting:"#00ff88", analyzing:"#f59e0b", executing:"#3b82f6", waiting:"#4b5563", "in position":"#f43f5e" };
  const c = map[status]||color;
  return (
    <span style={{display:"inline-flex",alignItems:"center",gap:6,background:`rgba(${hexToRgb(c)},0.08)`,border:`1px solid rgba(${hexToRgb(c)},0.25)`,borderRadius:20,padding:"3px 10px"}}>
      <GlowDot color={c} pulse={status==="executing"||status==="in position"}/>
      <span style={{color:c,fontSize:9,fontFamily:"monospace",letterSpacing:1.5,textTransform:"uppercase"}}>{status}</span>
    </span>
  );
}

// ─── AGENT CARD ───────────────────────────────────────────────────────────────
function AgentCard({ agent, selected, onClick }) {
  const pos = agent.pnl>=0;
  return (
    <div onClick={onClick} style={{
      background: selected
        ? `linear-gradient(135deg,rgba(${hexToRgb(agent.color)},0.13) 0%,rgba(4,4,12,0.97) 100%)`
        : "rgba(8,8,18,0.85)",
      border:`1px solid ${selected?agent.color:"rgba(255,255,255,0.06)"}`,
      borderRadius:14, padding:"18px 20px", cursor:"pointer",
      transition:"all 0.22s cubic-bezier(.4,0,.2,1)",
      boxShadow: selected?`0 0 28px rgba(${hexToRgb(agent.color)},0.18),inset 0 1px 0 rgba(${hexToRgb(agent.color)},0.1)`:"none",
      position:"relative", overflow:"hidden",
    }}>
      {selected && <div style={{position:"absolute",top:0,left:0,right:0,height:2,background:`linear-gradient(90deg,transparent,${agent.color},transparent)`}}/>}
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:12}}>
        <div>
          <span style={{fontFamily:"'Orbitron',monospace",fontWeight:900,fontSize:16,color:agent.color,letterSpacing:3,textShadow:`0 0 18px ${agent.color}55`}}>{agent.name}</span>
          <div style={{color:"rgba(255,255,255,0.35)",fontSize:10,fontFamily:"monospace",letterSpacing:1,marginTop:2}}>{agent.subtitle}</div>
        </div>
        <StatusPill status={agent.status} color={agent.color}/>
      </div>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-end"}}>
        <div>
          <div style={{fontFamily:"'Orbitron',monospace",fontSize:18,fontWeight:700,color:pos?"#00ff88":"#f43f5e",letterSpacing:0.5}}>
            {pos?"+":""}{(agent.pnl<0?"-":"")+"$"+Math.abs(agent.pnl).toFixed(0).replace(/\B(?=(\d{3})+(?!\d))/g,",")}
          </div>
          <div style={{color:"rgba(255,255,255,0.28)",fontSize:9,fontFamily:"monospace",marginTop:3,letterSpacing:0.8}}>
            {agent.winRate.toFixed(1)}% WIN · {agent.trades} TRADES
          </div>
        </div>
        <MiniSparkline data={agent.equity} color={pos?"#00ff88":"#f43f5e"}/>
      </div>
    </div>
  );
}

// ─── AGENT DETAIL ─────────────────────────────────────────────────────────────
function AgentDetail({ agent }) {
  if(!agent) return null;
  const sharpe=(1.2+Math.random()*1.8).toFixed(2);
  const dd=(5+Math.random()*15).toFixed(1);
  const avgW=(800+Math.random()*1200).toFixed(0);
  const avgL=(200+Math.random()*400).toFixed(0);
  const pf=(1.5+Math.random()*1.5).toFixed(2);
  const metrics=[
    {l:"SHARPE RATIO",v:sharpe,pos:true},
    {l:"MAX DRAWDOWN",v:`-${dd}%`,pos:false},
    {l:"AVG WIN",v:`$${parseInt(avgW).toLocaleString()}`,pos:true},
    {l:"AVG LOSS",v:`-$${parseInt(avgL).toLocaleString()}`,pos:false},
    {l:"PROFIT FACTOR",v:pf,pos:true},
    {l:"TOTAL P&L",v:`${agent.pnl>=0?"+":"-"}$${Math.abs(agent.pnl).toFixed(0).replace(/\B(?=(\d{3})+(?!\d))/g,",")}`,pos:agent.pnl>=0},
  ];
  return (
    <div style={{display:"flex",flexDirection:"column",gap:18}}>
      <div style={{background:`linear-gradient(135deg,rgba(${hexToRgb(agent.color)},0.08) 0%,rgba(4,4,12,0.95) 100%)`,border:`1px solid rgba(${hexToRgb(agent.color)},0.2)`,borderRadius:16,padding:22}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:14}}>
          <div>
            <div style={{fontFamily:"'Orbitron',monospace",fontSize:26,fontWeight:900,color:agent.color,letterSpacing:4,textShadow:`0 0 28px ${agent.color}77`}}>{agent.name}</div>
            <div style={{color:"rgba(255,255,255,0.45)",fontSize:12,marginTop:5,maxWidth:380,lineHeight:1.5}}>{agent.description}</div>
          </div>
          <StatusPill status={agent.status} color={agent.color}/>
        </div>
        <div style={{display:"flex",gap:7,flexWrap:"wrap",marginBottom:16}}>{agent.indicators.map(ind=><Tag key={ind} color={agent.color}>{ind}</Tag>)}</div>
        <div style={{color:"rgba(255,255,255,0.22)",fontSize:9,fontFamily:"monospace",letterSpacing:2,marginBottom:8}}>EQUITY CURVE</div>
        <EquityCurve data={agent.equity} color={agent.color}/>
      </div>

      <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:10}}>
        {metrics.map(m=>(
          <div key={m.l} style={{background:"rgba(8,8,18,0.85)",border:"1px solid rgba(255,255,255,0.06)",borderRadius:12,padding:"13px 15px"}}>
            <div style={{color:"rgba(255,255,255,0.28)",fontSize:9,fontFamily:"monospace",letterSpacing:1.2,marginBottom:7}}>{m.l}</div>
            <div style={{fontFamily:"'Orbitron',monospace",fontSize:13,fontWeight:700,color:m.pos?"#00ff88":"#f43f5e"}}>{m.v}</div>
          </div>
        ))}
      </div>

      {agent.recentTrades.length>0&&(
        <div style={{background:"rgba(8,8,18,0.85)",border:"1px solid rgba(255,255,255,0.06)",borderRadius:16,padding:20}}>
          <div style={{color:"rgba(255,255,255,0.25)",fontSize:9,fontFamily:"monospace",letterSpacing:2,marginBottom:14}}>RECENT EXECUTIONS</div>
          {agent.recentTrades.map(t=>(
            <div key={t.id} style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"8px 0",borderBottom:"1px solid rgba(255,255,255,0.04)"}}>
              <div style={{display:"flex",gap:10,alignItems:"center"}}>
                <span style={{background:t.side==="LONG"?"rgba(0,255,136,0.1)":"rgba(244,63,94,0.1)",color:t.side==="LONG"?"#00ff88":"#f43f5e",border:`1px solid ${t.side==="LONG"?"rgba(0,255,136,0.3)":"rgba(244,63,94,0.3)"}`,borderRadius:4,padding:"2px 7px",fontSize:9,fontFamily:"monospace",letterSpacing:1}}>{t.side}</span>
                <span style={{color:"rgba(255,255,255,0.65)",fontSize:12,fontFamily:"monospace"}}>{t.symbol}</span>
              </div>
              <div style={{display:"flex",gap:14,alignItems:"center"}}>
                <span style={{fontFamily:"'Orbitron',monospace",fontSize:12,color:t.pnl>=0?"#00ff88":"#f43f5e"}}>{t.pnl>=0?"+":"-"}${Math.abs(t.pnl).toFixed(0)}</span>
                <span style={{color:"rgba(255,255,255,0.2)",fontSize:10,fontFamily:"monospace"}}>{t.time}</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── TICKER BAR ───────────────────────────────────────────────────────────────
function TickerBar({ prices, changes }) {
  return (
    <div style={{background:"rgba(2,2,8,0.95)",borderBottom:"1px solid rgba(255,255,255,0.05)",padding:"7px 0",overflow:"hidden"}}>
      <div style={{display:"flex",gap:36,animation:"ticker 28s linear infinite",whiteSpace:"nowrap"}}>
        {[...SYMBOLS,...SYMBOLS].map((sym,i)=>{
          const p=prices[sym]||0, ch=changes[sym];
          return (
            <span key={i} style={{display:"inline-flex",gap:7,alignItems:"center"}}>
              <span style={{color:"rgba(255,255,255,0.35)",fontSize:10,fontFamily:"monospace",letterSpacing:1}}>{sym}</span>
              <span style={{fontFamily:"'Orbitron',monospace",fontSize:10,fontWeight:600,color:ch==="up"?"#00ff88":ch==="down"?"#f43f5e":"white",transition:"color 0.3s"}}>
                {p<10?p.toFixed(4):p<100?p.toFixed(2):p.toFixed(0)}
              </span>
              <span style={{color:ch==="up"?"#00ff88":"#f43f5e",fontSize:8}}>{ch==="up"?"▲":"▼"}</span>
            </span>
          );
        })}
      </div>
    </div>
  );
}

// ─── WITHDRAWAL TAB ───────────────────────────────────────────────────────────
function WithdrawalTab({ totalPnl }) {
  const balance = 285430.88 + totalPnl;
  const [method, setMethod] = useState("crypto");
  const [asset, setAsset] = useState("USDT");
  const [network, setNetwork] = useState(NETWORKS[0]);
  const [address, setAddress] = useState("");
  const [amount, setAmount] = useState("");
  const [step, setStep] = useState(1); // 1=form, 2=confirm, 3=success
  const [loading, setLoading] = useState(false);
  const [bankName, setBankName] = useState("");
  const [accountNo, setAccountNo] = useState("");
  const [routingNo, setRoutingNo] = useState("");
  const [country, setCountry] = useState(BANK_COUNTRIES[0]);
  const [history] = useState([
    { id:"WD-8821",method:"Crypto",asset:"USDT",amount:12500,status:"Completed",time:"2025-04-28 14:32",address:"0x3f9...a2c1",fee:2.50},
    { id:"WD-8734",method:"Bank",asset:"USD",amount:50000,status:"Completed",time:"2025-04-21 09:15",address:"Chase ****4821",fee:15.00},
    { id:"WD-8601",method:"Crypto",asset:"ETH",amount:8200,status:"Completed",time:"2025-04-14 17:44",address:"0x7b2...f903",fee:1.80},
    { id:"WD-8512",method:"Crypto",asset:"BTC",amount:31000,status:"Failed",time:"2025-04-07 11:20",address:"bc1q...p44s",fee:0},
    { id:"WD-8488",method:"Bank",asset:"USD",amount:25000,status:"Completed",time:"2025-03-30 08:55",address:"BoA ****7734",fee:12.00},
  ]);

  const fee = method==="crypto" ? (parseFloat(amount)||0)*0.001+2.5 : 15;
  const net = (parseFloat(amount)||0) - fee;

  function handleSubmit() {
    if(!amount||parseFloat(amount)<=0) return;
    setStep(2);
  }
  function handleConfirm() {
    setLoading(true);
    setTimeout(()=>{ setLoading(false); setStep(3); },2200);
  }
  function handleReset() {
    setStep(1); setAmount(""); setAddress(""); setBankName(""); setAccountNo(""); setRoutingNo("");
  }

  const inp = {
    background:"rgba(4,4,12,0.9)",
    border:"1px solid rgba(255,255,255,0.1)",
    borderRadius:10, padding:"11px 14px",
    color:"white", fontFamily:"monospace", fontSize:13,
    outline:"none", width:"100%", boxSizing:"border-box",
    transition:"border-color 0.2s",
  };
  const sel = { ...inp, appearance:"none", cursor:"pointer" };
  const lbl = { color:"rgba(255,255,255,0.35)",fontSize:9,fontFamily:"monospace",letterSpacing:2,marginBottom:7,display:"block" };

  return (
    <div style={{display:"grid",gridTemplateColumns:"1fr 340px",gap:20,height:"100%",overflow:"auto"}}>
      {/* LEFT: Form */}
      <div style={{display:"flex",flexDirection:"column",gap:18}}>

        {/* Balance card */}
        <div style={{background:"linear-gradient(135deg,rgba(0,255,136,0.08) 0%,rgba(4,4,12,0.97) 100%)",border:"1px solid rgba(0,255,136,0.22)",borderRadius:16,padding:"22px 24px",position:"relative",overflow:"hidden"}}>
          <div style={{position:"absolute",top:0,left:0,right:0,height:2,background:"linear-gradient(90deg,transparent,#00ff88,transparent)"}}/>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
            <div>
              <div style={{color:"rgba(255,255,255,0.3)",fontSize:9,fontFamily:"monospace",letterSpacing:2,marginBottom:8}}>AVAILABLE BALANCE</div>
              <div style={{fontFamily:"'Orbitron',monospace",fontSize:36,fontWeight:900,color:"#00ff88",textShadow:"0 0 30px rgba(0,255,136,0.5)",letterSpacing:2}}>
                ${balance.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g,",")}
              </div>
              <div style={{color:"rgba(255,255,255,0.3)",fontSize:10,fontFamily:"monospace",marginTop:6,letterSpacing:1}}>
                PORTFOLIO P&L INCLUDED · 4 AGENTS ACTIVE
              </div>
            </div>
            <div style={{display:"flex",flexDirection:"column",gap:10,alignItems:"flex-end"}}>
              <div style={{background:"rgba(0,255,136,0.06)",border:"1px solid rgba(0,255,136,0.15)",borderRadius:10,padding:"10px 16px",textAlign:"right"}}>
                <div style={{color:"rgba(255,255,255,0.3)",fontSize:9,fontFamily:"monospace",letterSpacing:1,marginBottom:4}}>PENDING</div>
                <div style={{fontFamily:"'Orbitron',monospace",fontSize:16,color:"#f59e0b"}}>$0.00</div>
              </div>
              <div style={{background:"rgba(0,255,136,0.06)",border:"1px solid rgba(0,255,136,0.15)",borderRadius:10,padding:"10px 16px",textAlign:"right"}}>
                <div style={{color:"rgba(255,255,255,0.3)",fontSize:9,fontFamily:"monospace",letterSpacing:1,marginBottom:4}}>WITHDRAWN (30D)</div>
                <div style={{fontFamily:"'Orbitron',monospace",fontSize:16,color:"white"}}>$126,700</div>
              </div>
            </div>
          </div>
        </div>

        {step===1 && (
          <div style={{background:"rgba(8,8,18,0.88)",border:"1px solid rgba(255,255,255,0.07)",borderRadius:16,padding:24,display:"flex",flexDirection:"column",gap:20}}>
            <div style={{color:"rgba(255,255,255,0.2)",fontSize:9,fontFamily:"monospace",letterSpacing:3}}>INITIATE WITHDRAWAL</div>

            {/* Method toggle */}
            <div>
              <span style={lbl}>WITHDRAWAL METHOD</span>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
                {["crypto","bank"].map(m=>(
                  <button key={m} onClick={()=>setMethod(m)} style={{
                    background:method===m?"rgba(0,255,136,0.1)":"rgba(4,4,12,0.9)",
                    border:`1px solid ${method===m?"rgba(0,255,136,0.45)":"rgba(255,255,255,0.08)"}`,
                    borderRadius:10, padding:"14px",cursor:"pointer",
                    color:method===m?"#00ff88":"rgba(255,255,255,0.5)",
                    fontFamily:"'Orbitron',monospace",fontSize:12,fontWeight:700,letterSpacing:2,
                    transition:"all 0.2s",
                  }}>
                    <div style={{fontSize:20,marginBottom:6}}>{m==="crypto"?"◈":"⬡"}</div>
                    {m==="crypto"?"CRYPTO":"BANK WIRE"}
                  </button>
                ))}
              </div>
            </div>

            {method==="crypto" ? (
              <>
                <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:14}}>
                  <div>
                    <span style={lbl}>ASSET</span>
                    <select value={asset} onChange={e=>setAsset(e.target.value)} style={sel}>
                      {CRYPTO_ASSETS.map(a=><option key={a} value={a}>{a}</option>)}
                    </select>
                  </div>
                  <div>
                    <span style={lbl}>NETWORK</span>
                    <select value={network} onChange={e=>setNetwork(e.target.value)} style={{...sel,fontSize:11}}>
                      {NETWORKS.map(n=><option key={n} value={n}>{n}</option>)}
                    </select>
                  </div>
                </div>
                <div>
                  <span style={lbl}>DESTINATION ADDRESS</span>
                  <input value={address} onChange={e=>setAddress(e.target.value)} placeholder="0x... or bc1q..." style={inp}/>
                </div>
              </>
            ):(
              <>
                <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:14}}>
                  <div>
                    <span style={lbl}>BANK NAME</span>
                    <input value={bankName} onChange={e=>setBankName(e.target.value)} placeholder="e.g. JPMorgan Chase" style={inp}/>
                  </div>
                  <div>
                    <span style={lbl}>COUNTRY</span>
                    <select value={country} onChange={e=>setCountry(e.target.value)} style={sel}>
                      {BANK_COUNTRIES.map(c=><option key={c} value={c}>{c}</option>)}
                    </select>
                  </div>
                </div>
                <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:14}}>
                  <div>
                    <span style={lbl}>ACCOUNT NUMBER</span>
                    <input value={accountNo} onChange={e=>setAccountNo(e.target.value)} placeholder="••••••••••" style={inp}/>
                  </div>
                  <div>
                    <span style={lbl}>ROUTING / SWIFT / IBAN</span>
                    <input value={routingNo} onChange={e=>setRoutingNo(e.target.value)} placeholder="e.g. 021000021" style={inp}/>
                  </div>
                </div>
              </>
            )}

            <div>
              <div style={{display:"flex",justifyContent:"space-between",marginBottom:7}}>
                <span style={lbl}>AMOUNT (USD)</span>
                <button onClick={()=>setAmount((balance*0.95).toFixed(2))} style={{background:"none",border:"none",color:"rgba(0,255,136,0.6)",fontSize:9,fontFamily:"monospace",cursor:"pointer",letterSpacing:1}}>MAX</button>
              </div>
              <input value={amount} onChange={e=>setAmount(e.target.value)} type="number" placeholder="0.00" style={{...inp,fontSize:22,fontFamily:"'Orbitron',monospace",fontWeight:700}}/>
            </div>

            {/* Fee breakdown */}
            {parseFloat(amount)>0 && (
              <div style={{background:"rgba(4,4,12,0.8)",border:"1px solid rgba(255,255,255,0.06)",borderRadius:10,padding:"14px 16px",display:"flex",flexDirection:"column",gap:8}}>
                {[["WITHDRAWAL AMOUNT","$"+parseFloat(amount).toFixed(2),"white"],[method==="crypto"?"NETWORK FEE (0.1% + $2.50)":"WIRE FEE","–$"+fee.toFixed(2),"#f43f5e"],["YOU RECEIVE","$"+(net>0?net.toFixed(2):"0.00"),"#00ff88"]].map(([l,v,c])=>(
                  <div key={l} style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                    <span style={{color:"rgba(255,255,255,0.35)",fontSize:10,fontFamily:"monospace",letterSpacing:1}}>{l}</span>
                    <span style={{fontFamily:"'Orbitron',monospace",fontSize:12,color:c,fontWeight:600}}>{v}</span>
                  </div>
                ))}
              </div>
            )}

            <button onClick={handleSubmit} style={{
              background:"linear-gradient(135deg,#00cc66,#009944)",
              border:"none",borderRadius:12,padding:"15px",cursor:"pointer",
              color:"#020208",fontFamily:"'Orbitron',monospace",fontWeight:900,fontSize:13,letterSpacing:3,
              boxShadow:"0 0 30px rgba(0,255,136,0.3)",transition:"all 0.2s",
              opacity:(!amount||parseFloat(amount)<=0)?0.4:1,
            }}>REVIEW WITHDRAWAL →</button>
          </div>
        )}

        {step===2 && (
          <div style={{background:"rgba(8,8,18,0.88)",border:"1px solid rgba(244,196,63,0.25)",borderRadius:16,padding:24,display:"flex",flexDirection:"column",gap:18}}>
            <div style={{display:"flex",alignItems:"center",gap:10}}>
              <span style={{fontSize:22,color:"#f59e0b"}}>⚠</span>
              <div>
                <div style={{fontFamily:"'Orbitron',monospace",fontWeight:700,color:"#f59e0b",letterSpacing:2}}>CONFIRM WITHDRAWAL</div>
                <div style={{color:"rgba(255,255,255,0.35)",fontSize:10,fontFamily:"monospace",marginTop:2}}>REVIEW DETAILS CAREFULLY — THIS ACTION CANNOT BE UNDONE</div>
              </div>
            </div>

            <div style={{background:"rgba(4,4,12,0.9)",border:"1px solid rgba(255,255,255,0.06)",borderRadius:12,padding:18,display:"flex",flexDirection:"column",gap:12}}>
              {[
                ["METHOD", method==="crypto"?"Cryptocurrency":"Bank Wire"],
                method==="crypto"?["ASSET",asset]:["BANK",bankName||"—"],
                method==="crypto"?["NETWORK",network]:["ACCOUNT","••••"+accountNo.slice(-4)],
                method==="crypto"?["ADDRESS",address.slice(0,12)+"..."+address.slice(-6)]:["ROUTING/SWIFT",routingNo],
                ["AMOUNT","$"+parseFloat(amount).toFixed(2)],
                ["FEE","–$"+fee.toFixed(2)],
                ["NET AMOUNT","$"+(net>0?net.toFixed(2):"0.00")],
              ].map(([l,v])=>(
                <div key={l} style={{display:"flex",justifyContent:"space-between",borderBottom:"1px solid rgba(255,255,255,0.04)",paddingBottom:10}}>
                  <span style={{color:"rgba(255,255,255,0.3)",fontSize:10,fontFamily:"monospace",letterSpacing:1}}>{l}</span>
                  <span style={{color:"white",fontSize:11,fontFamily:"monospace"}}>{v}</span>
                </div>
              ))}
            </div>

            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
              <button onClick={handleReset} style={{background:"rgba(8,8,18,0.9)",border:"1px solid rgba(255,255,255,0.1)",borderRadius:12,padding:"13px",cursor:"pointer",color:"rgba(255,255,255,0.5)",fontFamily:"'Orbitron',monospace",fontSize:11,letterSpacing:2}}>← BACK</button>
              <button onClick={handleConfirm} style={{
                background:loading?"rgba(0,153,68,0.4)":"linear-gradient(135deg,#00cc66,#009944)",
                border:"none",borderRadius:12,padding:"13px",cursor:"pointer",
                color:"#020208",fontFamily:"'Orbitron',monospace",fontWeight:900,fontSize:12,letterSpacing:2,
                boxShadow:"0 0 24px rgba(0,255,136,0.25)",display:"flex",alignItems:"center",justifyContent:"center",gap:8,
              }}>
                {loading?<><span style={{display:"inline-block",width:12,height:12,border:"2px solid #020208",borderTopColor:"transparent",borderRadius:"50%",animation:"spin 0.6s linear infinite"}}/>PROCESSING...</>:"CONFIRM ✓"}
              </button>
            </div>
          </div>
        )}

        {step===3 && (
          <div style={{background:"linear-gradient(135deg,rgba(0,255,136,0.07) 0%,rgba(4,4,12,0.97) 100%)",border:"1px solid rgba(0,255,136,0.3)",borderRadius:16,padding:32,display:"flex",flexDirection:"column",alignItems:"center",gap:18,textAlign:"center"}}>
            <div style={{width:64,height:64,borderRadius:"50%",background:"rgba(0,255,136,0.1)",border:"2px solid rgba(0,255,136,0.5)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:28,color:"#00ff88",boxShadow:"0 0 40px rgba(0,255,136,0.3)"}}>✓</div>
            <div>
              <div style={{fontFamily:"'Orbitron',monospace",fontSize:20,fontWeight:900,color:"#00ff88",letterSpacing:3,marginBottom:8}}>WITHDRAWAL INITIATED</div>
              <div style={{color:"rgba(255,255,255,0.45)",fontSize:12,fontFamily:"monospace",lineHeight:1.6}}>
                ${(net>0?net:0).toFixed(2)} is being processed.<br/>
                Reference: WD-{Math.floor(Math.random()*9000)+1000}<br/>
                {method==="crypto"?"ETA: 10–30 minutes":"ETA: 1–3 business days"}
              </div>
            </div>
            <button onClick={handleReset} style={{background:"rgba(0,255,136,0.08)",border:"1px solid rgba(0,255,136,0.25)",borderRadius:10,padding:"12px 28px",cursor:"pointer",color:"#00ff88",fontFamily:"'Orbitron',monospace",fontSize:11,letterSpacing:2}}>NEW WITHDRAWAL</button>
          </div>
        )}
      </div>

      {/* RIGHT: History */}
      <div style={{display:"flex",flexDirection:"column",gap:16}}>
        <div style={{background:"rgba(8,8,18,0.88)",border:"1px solid rgba(255,255,255,0.07)",borderRadius:16,padding:20,flex:1}}>
          <div style={{color:"rgba(255,255,255,0.22)",fontSize:9,fontFamily:"monospace",letterSpacing:3,marginBottom:18}}>WITHDRAWAL HISTORY</div>
          <div style={{display:"flex",flexDirection:"column",gap:0}}>
            {history.map((h,i)=>(
              <div key={h.id} style={{padding:"13px 0",borderBottom:i<history.length-1?"1px solid rgba(255,255,255,0.05)":"none"}}>
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:6}}>
                  <div>
                    <span style={{fontFamily:"'Orbitron',monospace",fontSize:11,color:"white",letterSpacing:1}}>{h.id}</span>
                    <div style={{color:"rgba(255,255,255,0.3)",fontSize:9,fontFamily:"monospace",marginTop:3}}>{h.time}</div>
                  </div>
                  <span style={{
                    background:h.status==="Completed"?"rgba(0,255,136,0.08)":"rgba(244,63,94,0.08)",
                    color:h.status==="Completed"?"#00ff88":"#f43f5e",
                    border:`1px solid ${h.status==="Completed"?"rgba(0,255,136,0.2)":"rgba(244,63,94,0.2)"}`,
                    borderRadius:6,padding:"2px 8px",fontSize:8,fontFamily:"monospace",letterSpacing:1
                  }}>{h.status.toUpperCase()}</span>
                </div>
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                  <span style={{color:"rgba(255,255,255,0.4)",fontSize:10,fontFamily:"monospace"}}>{h.method} · {h.asset} · {h.address}</span>
                  <span style={{fontFamily:"'Orbitron',monospace",fontSize:13,fontWeight:700,color:"white"}}>${h.amount.toLocaleString()}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Security notice */}
        <div style={{background:"rgba(167,139,250,0.05)",border:"1px solid rgba(167,139,250,0.15)",borderRadius:12,padding:16}}>
          <div style={{color:"#a78bfa",fontSize:9,fontFamily:"monospace",letterSpacing:2,marginBottom:8}}>⬡ SECURITY PROTOCOLS</div>
          {["2FA verification required for all withdrawals","Withdrawals reviewed by AI anomaly detection","New addresses require 24h cooldown"].map(s=>(
            <div key={s} style={{display:"flex",gap:8,alignItems:"flex-start",marginBottom:6}}>
              <span style={{color:"rgba(167,139,250,0.5)",fontSize:10}}>◈</span>
              <span style={{color:"rgba(255,255,255,0.3)",fontSize:9,fontFamily:"monospace",lineHeight:1.5}}>{s}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── PORTFOLIO OVERVIEW TAB ───────────────────────────────────────────────────
function PortfolioTab({ agents, totalPnl }) {
  const allocations = [
    { label:"AGENTS (LIVE)", value: 60, color:"#00ff88" },
    { label:"STABLE RESERVE", value: 25, color:"#a78bfa" },
    { label:"CASH BUFFER", value: 15, color:"#f59e0b" },
  ];
  const balance = 285430.88 + totalPnl;
  const weekData = [240000,248000,235000,262000,258000,271000,balance];

  return (
    <div style={{display:"flex",flexDirection:"column",gap:18}}>
      <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:14}}>
        {[
          {l:"TOTAL EQUITY",v:`$${balance.toFixed(0).replace(/\B(?=(\d{3})+(?!\d))/g,",")}`,c:"#00ff88",sub:"↑ +12.4% MTD"},
          {l:"REALIZED P&L",v:`+$${(Math.abs(totalPnl)+82000).toFixed(0).replace(/\B(?=(\d{3})+(?!\d))/g,",")}`,c:"#00ff88",sub:"All time"},
          {l:"OPEN POSITIONS",v:`${agents.filter(a=>a.status==="in position").length}`,c:"#f43f5e",sub:"Agents deployed"},
          {l:"PORTFOLIO BETA",v:"1.24",c:"#f59e0b",sub:"vs S&P 500"},
        ].map(m=>(
          <div key={m.l} style={{background:"rgba(8,8,18,0.88)",border:"1px solid rgba(255,255,255,0.07)",borderRadius:14,padding:"18px 20px"}}>
            <div style={{color:"rgba(255,255,255,0.28)",fontSize:9,fontFamily:"monospace",letterSpacing:2,marginBottom:10}}>{m.l}</div>
            <div style={{fontFamily:"'Orbitron',monospace",fontSize:20,fontWeight:700,color:m.c}}>{m.v}</div>
            <div style={{color:"rgba(255,255,255,0.25)",fontSize:10,fontFamily:"monospace",marginTop:5}}>{m.sub}</div>
          </div>
        ))}
      </div>

      <div style={{display:"grid",gridTemplateColumns:"2fr 1fr",gap:18}}>
        <div style={{background:"rgba(8,8,18,0.88)",border:"1px solid rgba(255,255,255,0.07)",borderRadius:16,padding:22}}>
          <div style={{color:"rgba(255,255,255,0.22)",fontSize:9,fontFamily:"monospace",letterSpacing:3,marginBottom:16}}>7-DAY EQUITY CURVE</div>
          <EquityCurve data={weekData} color="#00ff88"/>
          <div style={{display:"flex",justifyContent:"space-between",marginTop:10}}>
            {["MON","TUE","WED","THU","FRI","SAT","TODAY"].map(d=>(
              <span key={d} style={{color:"rgba(255,255,255,0.2)",fontSize:8,fontFamily:"monospace"}}>{d}</span>
            ))}
          </div>
        </div>

        <div style={{display:"flex",flexDirection:"column",gap:14}}>
          <div style={{background:"rgba(8,8,18,0.88)",border:"1px solid rgba(255,255,255,0.07)",borderRadius:16,padding:20,flex:1}}>
            <div style={{color:"rgba(255,255,255,0.22)",fontSize:9,fontFamily:"monospace",letterSpacing:3,marginBottom:16}}>ALLOCATION</div>
            {allocations.map(a=>(
              <div key={a.label} style={{marginBottom:14}}>
                <div style={{display:"flex",justifyContent:"space-between",marginBottom:6}}>
                  <span style={{color:a.color,fontSize:9,fontFamily:"monospace",letterSpacing:1}}>{a.label}</span>
                  <span style={{color:"rgba(255,255,255,0.4)",fontSize:9,fontFamily:"monospace"}}>{a.value}%</span>
                </div>
                <div style={{height:4,background:"rgba(255,255,255,0.04)",borderRadius:2}}>
                  <div style={{height:"100%",width:`${a.value}%`,background:`linear-gradient(90deg,${a.color},${a.color}88)`,borderRadius:2,boxShadow:`0 0 8px ${a.color}44`}}/>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div style={{background:"rgba(8,8,18,0.88)",border:"1px solid rgba(255,255,255,0.07)",borderRadius:16,padding:22}}>
        <div style={{color:"rgba(255,255,255,0.22)",fontSize:9,fontFamily:"monospace",letterSpacing:3,marginBottom:16}}>AGENT PERFORMANCE RANKING</div>
        <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:14}}>
          {[...agents].sort((a,b)=>b.pnl-a.pnl).map((a,i)=>(
            <div key={a.id} style={{background:`rgba(${hexToRgb(a.color)},0.05)`,border:`1px solid rgba(${hexToRgb(a.color)},0.15)`,borderRadius:12,padding:"16px 18px"}}>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:10}}>
                <span style={{fontFamily:"'Orbitron',monospace",color:a.color,fontSize:14,fontWeight:900,letterSpacing:2}}>{a.name}</span>
                <span style={{fontFamily:"'Orbitron',monospace",color:"rgba(255,255,255,0.2)",fontSize:20,fontWeight:900}}>#{i+1}</span>
              </div>
              <div style={{fontFamily:"'Orbitron',monospace",fontSize:15,fontWeight:700,color:a.pnl>=0?"#00ff88":"#f43f5e",marginBottom:6}}>
                {a.pnl>=0?"+":"-"}${Math.abs(a.pnl).toFixed(0).replace(/\B(?=(\d{3})+(?!\d))/g,",")}
              </div>
              <div style={{display:"flex",gap:8}}>
                <Tag color={a.color}>{a.winRate.toFixed(1)}% WIN</Tag>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── SETTINGS TAB ─────────────────────────────────────────────────────────────
function SettingsTab() {
  const [riskLevel, setRiskLevel] = useState(65);
  const [maxDrawdown, setMaxDrawdown] = useState(15);
  const [maxPositions, setMaxPositions] = useState(8);
  const [apiKey, setApiKey] = useState("sk-nexus-••••••••••••••••••••••");
  const [notifications, setNotifications] = useState({trade:true,risk:true,withdrawal:true,news:false});
  const [activeAgents, setActiveAgents] = useState({apex:true,vega:true,nova:true,ares:false});

  const inp={background:"rgba(4,4,12,0.9)",border:"1px solid rgba(255,255,255,0.1)",borderRadius:10,padding:"11px 14px",color:"white",fontFamily:"monospace",fontSize:13,outline:"none",width:"100%",boxSizing:"border-box"};
  const lbl={color:"rgba(255,255,255,0.35)",fontSize:9,fontFamily:"monospace",letterSpacing:2,marginBottom:7,display:"block"};

  return (
    <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:18}}>
      <div style={{display:"flex",flexDirection:"column",gap:18}}>
        <div style={{background:"rgba(8,8,18,0.88)",border:"1px solid rgba(255,255,255,0.07)",borderRadius:16,padding:22}}>
          <div style={{color:"rgba(255,255,255,0.22)",fontSize:9,fontFamily:"monospace",letterSpacing:3,marginBottom:18}}>RISK PARAMETERS</div>
          {[{l:"PORTFOLIO RISK LEVEL",v:riskLevel,set:setRiskLevel,color:"#00ff88",max:100},{l:"MAX DRAWDOWN (%)",v:maxDrawdown,set:setMaxDrawdown,color:"#f43f5e",max:50},{l:"MAX OPEN POSITIONS",v:maxPositions,set:setMaxPositions,color:"#a78bfa",max:20}].map(s=>(
            <div key={s.l} style={{marginBottom:20}}>
              <div style={{display:"flex",justifyContent:"space-between",marginBottom:8}}>
                <span style={lbl}>{s.l}</span>
                <span style={{fontFamily:"'Orbitron',monospace",color:s.color,fontSize:13,fontWeight:700}}>{s.v}{s.max===100?"%":""}</span>
              </div>
              <input type="range" min="0" max={s.max} value={s.v} onChange={e=>s.set(parseInt(e.target.value))} style={{width:"100%",accentColor:s.color,cursor:"pointer"}}/>
            </div>
          ))}
        </div>

        <div style={{background:"rgba(8,8,18,0.88)",border:"1px solid rgba(255,255,255,0.07)",borderRadius:16,padding:22}}>
          <div style={{color:"rgba(255,255,255,0.22)",fontSize:9,fontFamily:"monospace",letterSpacing:3,marginBottom:18}}>AGENT ACTIVATION</div>
          {AGENTS.map(a=>(
            <div key={a.id} style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"12px 0",borderBottom:"1px solid rgba(255,255,255,0.04)"}}>
              <div style={{display:"flex",alignItems:"center",gap:10}}>
                <GlowDot color={activeAgents[a.id]?a.color:"rgba(255,255,255,0.15)"} pulse={activeAgents[a.id]}/>
                <div>
                  <div style={{fontFamily:"'Orbitron',monospace",color:activeAgents[a.id]?a.color:"rgba(255,255,255,0.4)",fontSize:12,letterSpacing:2}}>{a.name}</div>
                  <div style={{color:"rgba(255,255,255,0.25)",fontSize:9,fontFamily:"monospace"}}>{a.strategy}</div>
                </div>
              </div>
              <div onClick={()=>setActiveAgents(p=>({...p,[a.id]:!p[a.id]}))} style={{
                width:44,height:24,borderRadius:12,background:activeAgents[a.id]?`rgba(${hexToRgb(a.color)},0.3)`:"rgba(255,255,255,0.08)",
                border:`1px solid ${activeAgents[a.id]?a.color:"rgba(255,255,255,0.15)"}`,
                cursor:"pointer",position:"relative",transition:"all 0.2s",
              }}>
                <div style={{position:"absolute",top:3,left:activeAgents[a.id]?20:3,width:16,height:16,borderRadius:"50%",background:activeAgents[a.id]?a.color:"rgba(255,255,255,0.3)",transition:"all 0.2s",boxShadow:activeAgents[a.id]?`0 0 8px ${a.color}`:"none"}}/>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div style={{display:"flex",flexDirection:"column",gap:18}}>
        <div style={{background:"rgba(8,8,18,0.88)",border:"1px solid rgba(255,255,255,0.07)",borderRadius:16,padding:22}}>
          <div style={{color:"rgba(255,255,255,0.22)",fontSize:9,fontFamily:"monospace",letterSpacing:3,marginBottom:18}}>API CONFIGURATION</div>
          <div style={{marginBottom:16}}>
            <span style={lbl}>EXCHANGE API KEY</span>
            <input value={apiKey} onChange={e=>setApiKey(e.target.value)} style={inp}/>
          </div>
          <div style={{marginBottom:16}}>
            <span style={lbl}>API SECRET</span>
            <input type="password" value="nexus_secret_key_2025" style={inp}/>
          </div>
          <div>
            <span style={lbl}>WEBHOOK URL</span>
            <input defaultValue="https://nexus.io/webhook/signals" style={inp}/>
          </div>
        </div>

        <div style={{background:"rgba(8,8,18,0.88)",border:"1px solid rgba(255,255,255,0.07)",borderRadius:16,padding:22}}>
          <div style={{color:"rgba(255,255,255,0.22)",fontSize:9,fontFamily:"monospace",letterSpacing:3,marginBottom:18}}>NOTIFICATIONS</div>
          {[["trade","Trade executions","#00ff88"],["risk","Risk alerts","#f43f5e"],["withdrawal","Withdrawal updates","#a78bfa"],["news","Market news feed","#f59e0b"]].map(([k,label,c])=>(
            <div key={k} style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"10px 0",borderBottom:"1px solid rgba(255,255,255,0.04)"}}>
              <span style={{color:"rgba(255,255,255,0.5)",fontSize:11,fontFamily:"monospace"}}>{label}</span>
              <div onClick={()=>setNotifications(p=>({...p,[k]:!p[k]}))} style={{
                width:40,height:22,borderRadius:11,background:notifications[k]?`rgba(${hexToRgb(c)},0.25)`:"rgba(255,255,255,0.06)",
                border:`1px solid ${notifications[k]?c:"rgba(255,255,255,0.12)"}`,
                cursor:"pointer",position:"relative",transition:"all 0.2s",
              }}>
                <div style={{position:"absolute",top:3,left:notifications[k]?17:3,width:14,height:14,borderRadius:"50%",background:notifications[k]?c:"rgba(255,255,255,0.25)",transition:"all 0.2s"}}/>
              </div>
            </div>
          ))}
        </div>

        <button style={{background:"linear-gradient(135deg,rgba(0,255,136,0.1),rgba(0,153,68,0.1))",border:"1px solid rgba(0,255,136,0.3)",borderRadius:12,padding:"14px",cursor:"pointer",color:"#00ff88",fontFamily:"'Orbitron',monospace",fontSize:12,letterSpacing:3,transition:"all 0.2s"}}>
          SAVE CONFIGURATION ✓
        </button>
      </div>
    </div>
  );
}

// ─── MAIN APP ─────────────────────────────────────────────────────────────────
export default function NexusCybersuite() {
  const [activeTab, setActiveTab] = useState("agents");
  const [selectedAgent, setSelectedAgent] = useState("apex");
  const agents = useAgentSim();
  const { prices, changes } = useMarketData();
  const totalPnl = agents.reduce((s,a)=>s+a.pnl,0);
  const totalTrades = agents.reduce((s,a)=>s+a.trades,0);
  const avgWin = agents.reduce((s,a)=>s+a.winRate,0)/agents.length;
  const selAgent = agents.find(a=>a.id===selectedAgent);

  const TABS = [
    { id:"agents", label:"AGENTS", icon:"◈" },
    { id:"portfolio", label:"PORTFOLIO", icon:"⬡" },
    { id:"withdraw", label:"WITHDRAW", icon:"↗" },
    { id:"settings", label:"SETTINGS", icon:"⚙" },
  ];

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@400;600;700;900&family=Share+Tech+Mono&display=swap');
        *{box-sizing:border-box;margin:0;padding:0;}
        html,body{height:100%;overflow:hidden;}
        ::-webkit-scrollbar{width:3px;}
        ::-webkit-scrollbar-track{background:transparent;}
        ::-webkit-scrollbar-thumb{background:rgba(0,255,136,0.15);border-radius:2px;}
        @keyframes ticker{0%{transform:translateX(0);}100%{transform:translateX(-50%);}}
        @keyframes glowPulse{0%,100%{opacity:1;box-shadow:0 0 8px currentColor;}50%{opacity:0.4;box-shadow:0 0 20px currentColor;}}
        @keyframes spin{to{transform:rotate(360deg);}}
        @keyframes fadeUp{from{opacity:0;transform:translateY(16px);}to{opacity:1;transform:translateY(0);}}
        @keyframes scanline{0%{top:-5%;}100%{top:105%;}}
        .scan::after{content:'';position:fixed;left:0;right:0;height:1px;background:linear-gradient(90deg,transparent,rgba(0,255,136,0.06),transparent);animation:scanline 6s linear infinite;pointer-events:none;z-index:9999;}
        .fadein{animation:fadeUp 0.35s ease both;}
        input[type=range]{-webkit-appearance:none;height:3px;border-radius:2px;background:rgba(255,255,255,0.08);outline:none;}
        input[type=range]::-webkit-slider-thumb{-webkit-appearance:none;width:16px;height:16px;border-radius:50%;cursor:pointer;border:2px solid rgba(255,255,255,0.2);}
        select option{background:#04040c;color:white;}
      `}</style>

      <div className="scan" style={{
        height:"100vh",display:"flex",flexDirection:"column",
        background:"radial-gradient(ellipse at 15% 0%,rgba(0,255,136,0.04) 0%,transparent 55%),radial-gradient(ellipse at 85% 100%,rgba(167,139,250,0.04) 0%,transparent 55%),#030309",
        color:"white",fontFamily:"'Share Tech Mono',monospace",overflow:"hidden",
        position:"relative",
      }}>
        {/* Grid overlay */}
        <div style={{position:"fixed",inset:0,backgroundImage:"linear-gradient(rgba(0,255,136,0.015) 1px,transparent 1px),linear-gradient(90deg,rgba(0,255,136,0.015) 1px,transparent 1px)",backgroundSize:"60px 60px",pointerEvents:"none",zIndex:0}}/>

        {/* HEADER */}
        <div style={{position:"relative",zIndex:10,background:"rgba(3,3,9,0.96)",backdropFilter:"blur(24px)",borderBottom:"1px solid rgba(255,255,255,0.055)",padding:"0 28px",flexShrink:0}}>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",height:60}}>
            <div style={{display:"flex",alignItems:"center",gap:14}}>
              <div style={{width:38,height:38,borderRadius:11,background:"linear-gradient(135deg,#00ff88,#009944)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:18,boxShadow:"0 0 24px rgba(0,255,136,0.45)",flexShrink:0}}>◈</div>
              <div>
                <div style={{fontFamily:"'Orbitron',monospace",fontWeight:900,fontSize:15,letterSpacing:5,color:"white",lineHeight:1}}>NEXUS</div>
                <div style={{color:"rgba(255,255,255,0.25)",fontSize:8,letterSpacing:3,marginTop:3}}>AUTONOMOUS TRADING SYSTEM · v4.2.1</div>
              </div>
            </div>

            {/* NAV TABS */}
            <div style={{display:"flex",gap:2,background:"rgba(4,4,12,0.7)",border:"1px solid rgba(255,255,255,0.07)",borderRadius:12,padding:4}}>
              {TABS.map(t=>(
                <button key={t.id} onClick={()=>setActiveTab(t.id)} style={{
                  background:activeTab===t.id?"rgba(0,255,136,0.1)":"transparent",
                  border:`1px solid ${activeTab===t.id?"rgba(0,255,136,0.3)":"transparent"}`,
                  borderRadius:9,padding:"7px 18px",cursor:"pointer",
                  color:activeTab===t.id?"#00ff88":"rgba(255,255,255,0.38)",
                  fontFamily:"'Orbitron',monospace",fontSize:10,letterSpacing:2,fontWeight:700,
                  transition:"all 0.2s",display:"flex",alignItems:"center",gap:6,
                  boxShadow:activeTab===t.id?"0 0 18px rgba(0,255,136,0.15)":"none",
                }}>
                  <span style={{fontSize:12}}>{t.icon}</span>{t.label}
                  {t.id==="withdraw"&&<span style={{background:"rgba(0,255,136,0.15)",color:"#00ff88",borderRadius:4,padding:"1px 5px",fontSize:8}}>NEW</span>}
                </button>
              ))}
            </div>

            {/* STATS */}
            <div style={{display:"flex",gap:24,alignItems:"center"}}>
              {[
                {l:"PORTFOLIO",v:`${totalPnl>=0?"+":"-"}$${Math.abs(totalPnl).toFixed(0).replace(/\B(?=(\d{3})+(?!\d))/g,",")}`,c:totalPnl>=0?"#00ff88":"#f43f5e"},
                {l:"WIN RATE",v:`${avgWin.toFixed(1)}%`,c:"#a78bfa"},
                {l:"TRADES",v:totalTrades.toLocaleString(),c:"#f59e0b"},
              ].map(s=>(
                <div key={s.l} style={{textAlign:"right"}}>
                  <div style={{fontFamily:"'Orbitron',monospace",fontSize:15,fontWeight:700,color:s.c,letterSpacing:0.5}}>{s.v}</div>
                  <div style={{color:"rgba(255,255,255,0.25)",fontSize:8,letterSpacing:2,marginTop:2}}>{s.l}</div>
                </div>
              ))}
              <div style={{display:"flex",alignItems:"center",gap:7,background:"rgba(0,255,136,0.06)",border:"1px solid rgba(0,255,136,0.18)",borderRadius:8,padding:"6px 12px"}}>
                <GlowDot color="#00ff88" pulse={true}/>
                <span style={{fontSize:9,color:"rgba(0,255,136,0.8)",fontFamily:"monospace",letterSpacing:1.5}}>LIVE</span>
              </div>
            </div>
          </div>
        </div>

        {/* TICKER */}
        <TickerBar prices={prices} changes={changes}/>

        {/* CONTENT */}
        <div style={{flex:1,overflow:"hidden",position:"relative",zIndex:1}}>
          {activeTab==="agents" && (
            <div className="fadein" style={{display:"grid",gridTemplateColumns:"360px 1fr",height:"100%"}}>
              <div style={{borderRight:"1px solid rgba(255,255,255,0.055)",padding:"18px 16px",display:"flex",flexDirection:"column",gap:10,overflowY:"auto",background:"rgba(3,3,9,0.5)"}}>
                <div style={{color:"rgba(255,255,255,0.2)",fontSize:8,letterSpacing:3,padding:"0 4px 4px",flexShrink:0}}>
                  ACTIVE AGENTS · {agents.filter(a=>a.status!=="waiting").length}/{agents.length} RUNNING
                </div>
                {agents.map(a=>(
                  <AgentCard key={a.id} agent={a} selected={selectedAgent===a.id} onClick={()=>setSelectedAgent(a.id)}/>
                ))}
                <div style={{background:"rgba(8,8,18,0.8)",border:"1px solid rgba(255,255,255,0.06)",borderRadius:14,padding:"16px 18px",marginTop:4,flexShrink:0}}>
                  <div style={{color:"rgba(255,255,255,0.22)",fontSize:8,letterSpacing:2,marginBottom:14}}>CAPITAL ALLOCATION</div>
                  {agents.map(a=>(
                    <div key={a.id} style={{marginBottom:10}}>
                      <div style={{display:"flex",justifyContent:"space-between",marginBottom:4}}>
                        <span style={{color:a.color,fontSize:9,fontFamily:"monospace",letterSpacing:1}}>{a.name}</span>
                        <span style={{color:"rgba(255,255,255,0.35)",fontSize:9}}>25%</span>
                      </div>
                      <div style={{height:3,background:"rgba(255,255,255,0.05)",borderRadius:2}}>
                        <div style={{height:"100%",width:"25%",background:`linear-gradient(90deg,${a.color},${a.accent})`,borderRadius:2,boxShadow:`0 0 7px ${a.color}55`}}/>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              <div style={{padding:"22px 24px",overflowY:"auto"}}>
                <AgentDetail agent={selAgent}/>
              </div>
            </div>
          )}

          {activeTab==="portfolio" && (
            <div className="fadein" style={{padding:"22px 24px",overflowY:"auto",height:"100%"}}>
              <PortfolioTab agents={agents} totalPnl={totalPnl}/>
            </div>
          )}

          {activeTab==="withdraw" && (
            <div className="fadein" style={{padding:"22px 24px",overflowY:"auto",height:"100%"}}>
              <WithdrawalTab totalPnl={totalPnl}/>
            </div>
          )}

          {activeTab==="settings" && (
            <div className="fadein" style={{padding:"22px 24px",overflowY:"auto",height:"100%"}}>
              <SettingsTab/>
            </div>
          )}
        </div>
      </div>
    </>
  );
}
