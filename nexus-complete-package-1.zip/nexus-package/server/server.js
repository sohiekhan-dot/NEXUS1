// server.js — NEXUS BTCPay Auto-Delivery Server
import "dotenv/config";
import express from "express";
import webhookRouter from "./routes/webhook.js";
import downloadRouter from "./routes/download.js";
import checkoutRouter from "./routes/checkout.js";
import { getSales } from "./lib/db.js";

const app = express();
const PORT = process.env.PORT || 3001;

// ── MIDDLEWARE ────────────────────────────────────────────────────────────────
// NOTE: webhook route uses express.raw() internally for HMAC verification
// All other routes use JSON
app.use((req, res, next) => {
  if (req.path.startsWith("/webhook")) return next();
  express.json()(req, res, next);
});

// ── ROUTES ────────────────────────────────────────────────────────────────────
app.use("/webhook", webhookRouter);
app.use("/download", downloadRouter);
app.use("/checkout", checkoutRouter);

// ── HEALTH CHECK ──────────────────────────────────────────────────────────────
app.get("/health", (req, res) => {
  res.json({ status: "ok", time: new Date().toISOString() });
});

// ── SALES DASHBOARD (protect this in production with a password) ──────────────
app.get("/sales", async (req, res) => {
  // Basic auth check
  const auth = req.headers.authorization;
  const expected = "Bearer " + process.env.ADMIN_TOKEN;
  if (!auth || auth !== expected) {
    return res.status(401).json({ error: "Unauthorized" });
  }
  const sales = await getSales();
  const total = sales.filter(s => s.status === "delivered").length;
  const btcTotal = sales
    .filter(s => s.status === "delivered")
    .reduce((sum, s) => sum + parseFloat(s.btc || 0), 0);
  res.json({ total_sales: total, total_btc: btcTotal.toFixed(6), sales });
});

// ── START ─────────────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`
  ╔═══════════════════════════════════════════╗
  ║   NEXUS BTCPay Auto-Delivery Server       ║
  ║   Running on port ${PORT}                    ║
  ╠═══════════════════════════════════════════╣
  ║  Webhook:  POST /webhook/btcpay           ║
  ║  Download: GET  /download/:token          ║
  ║  Health:   GET  /health                   ║
  ║  Sales:    GET  /sales (Bearer token)     ║
  ╚═══════════════════════════════════════════╝
  `);
  checkConfig();
});

function checkConfig() {
  const required = ["BTCPAY_URL","BTCPAY_WEBHOOK_SECRET","BTCPAY_STORE_ID","SMTP_HOST","SMTP_USER","SMTP_PASS","TOKEN_SECRET","SERVER_URL"];
  const missing = required.filter(k => !process.env[k]);
  if (missing.length) {
    console.warn("⚠  Missing env vars:", missing.join(", "));
    console.warn("   Copy .env.example → .env and fill them in.\n");
  } else {
    console.log("✅ All required env vars present\n");
  }
}
