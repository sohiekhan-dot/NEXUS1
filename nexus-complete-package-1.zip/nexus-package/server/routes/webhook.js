// routes/webhook.js
// Handles incoming BTCPay Server webhook events
// Verifies HMAC signature, checks invoice status, triggers delivery

import express from "express";
import crypto from "crypto";
import { generateToken } from "../lib/tokens.js";
import { sendDeliveryEmail, sendAdminAlert } from "../lib/mailer.js";
import { logSale, hasBeenDelivered, markDelivered } from "../lib/db.js";

const router = express.Router();

// ── BTCPAY SIGNATURE VERIFICATION ─────────────────────────────────────────────
function verifyBTCPaySignature(rawBody, sigHeader) {
  if (!sigHeader) return false;
  const secret = process.env.BTCPAY_WEBHOOK_SECRET;
  if (!secret) {
    console.warn("⚠ BTCPAY_WEBHOOK_SECRET not set — skipping signature check (dev mode only)");
    return process.env.NODE_ENV !== "production";
  }
  const expected = "sha256=" + crypto
    .createHmac("sha256", secret)
    .update(rawBody)
    .digest("hex");
  try {
    return crypto.timingSafeEqual(Buffer.from(sigHeader), Buffer.from(expected));
  } catch {
    return false;
  }
}

// ── TIER DETECTION ─────────────────────────────────────────────────────────────
// BTCPay invoice metadata carries the tier you set when creating the invoice.
// Set metadata.tier = "starter" | "pro" | "elite" when creating invoices via API.
const TIER_BTC = { starter: 0.003, pro: 0.009, elite: 0.025 };

function detectTier(invoice) {
  // First: check metadata (most reliable — set this when creating the invoice)
  if (invoice.metadata?.tier) return invoice.metadata.tier.toLowerCase();

  // Fallback: infer from amount paid
  const paid = parseFloat(invoice.amount || invoice.price || 0);
  if (paid >= 0.024) return "elite";
  if (paid >= 0.008) return "pro";
  return "starter";
}

// ── MAIN WEBHOOK HANDLER ──────────────────────────────────────────────────────
router.post(
  "/btcpay",
  express.raw({ type: "application/json" }), // raw body needed for HMAC
  async (req, res) => {
    // 1. Verify signature
    const sig = req.headers["btcpay-sig"] || req.headers["x-btcpay-signature"];
    if (!verifyBTCPaySignature(req.body, sig)) {
      console.error("❌ Invalid BTCPay webhook signature");
      return res.status(401).json({ error: "Invalid signature" });
    }

    let event;
    try {
      event = JSON.parse(req.body.toString());
    } catch {
      return res.status(400).json({ error: "Invalid JSON" });
    }

    console.log(`📨 BTCPay event: ${event.type} | invoice: ${event.invoiceId}`);

    // 2. Only process settled/confirmed payments
    // BTCPay event types: InvoiceSettled, InvoicePaymentSettled, InvoiceConfirmed
    const DELIVERY_EVENTS = ["InvoiceSettled", "InvoicePaymentSettled", "InvoiceConfirmed"];
    if (!DELIVERY_EVENTS.includes(event.type)) {
      return res.status(200).json({ received: true, action: "ignored", reason: `Event type ${event.type} not a delivery trigger` });
    }

    const invoiceId = event.invoiceId;
    if (!invoiceId) return res.status(400).json({ error: "Missing invoiceId" });

    // 3. Idempotency — don't deliver twice for same invoice
    if (await hasBeenDelivered(invoiceId)) {
      console.log(`ℹ Already delivered for invoice ${invoiceId} — skipping`);
      return res.status(200).json({ received: true, action: "skipped", reason: "Already delivered" });
    }

    // 4. Fetch full invoice from BTCPay to get buyer email + metadata
    let invoice;
    try {
      invoice = await fetchInvoice(invoiceId);
    } catch (err) {
      console.error(`❌ Failed to fetch invoice ${invoiceId}:`, err.message);
      // Respond 200 so BTCPay doesn't retry endlessly; log for manual followup
      return res.status(200).json({ received: true, action: "error", reason: "Invoice fetch failed — check logs" });
    }

    // 5. Extract buyer email
    const buyerEmail = invoice.buyer?.email || invoice.metadata?.buyerEmail || null;
    if (!buyerEmail) {
      console.warn(`⚠ No buyer email on invoice ${invoiceId} — cannot auto-deliver`);
      await logSale({ invoiceId, tier: detectTier(invoice), email: null, status: "no_email", btc: invoice.amount });
      return res.status(200).json({ received: true, action: "no_email" });
    }

    // 6. Determine tier
    const tier = detectTier(invoice);
    const btcAmount = TIER_BTC[tier];

    // 7. Generate secure download token
    const token = generateToken({ invoiceId, tier, email: buyerEmail });
    const downloadUrl = `${process.env.SERVER_URL}/download/${token}`;

    // 8. Send delivery email
    try {
      await sendDeliveryEmail({
        to: buyerEmail,
        tier,
        downloadUrl,
        invoiceId,
        downloadsLeft: 3,
      });
      console.log(`✅ Delivered ${tier} to ${buyerEmail} | invoice ${invoiceId}`);
    } catch (err) {
      console.error(`❌ Email send failed for ${invoiceId}:`, err.message);
      await logSale({ invoiceId, tier, email: buyerEmail, status: "email_failed", btc: btcAmount });
      return res.status(200).json({ received: true, action: "email_failed" });
    }

    // 9. Mark as delivered + log sale
    await markDelivered(invoiceId);
    await logSale({ invoiceId, tier, email: buyerEmail, status: "delivered", btc: btcAmount });

    // 10. Notify you via Telegram (optional)
    await sendAdminAlert({ invoiceId, tier, buyerEmail, btcAmount });

    return res.status(200).json({ received: true, action: "delivered", tier, email: buyerEmail });
  }
);

// ── FETCH INVOICE FROM BTCPAY API ─────────────────────────────────────────────
async function fetchInvoice(invoiceId) {
  const url = `${process.env.BTCPAY_URL}/api/v1/stores/${process.env.BTCPAY_STORE_ID}/invoices/${invoiceId}`;
  const res = await fetch(url, {
    headers: {
      Authorization: `token ${process.env.BTCPAY_API_KEY}`,
      "Content-Type": "application/json",
    },
  });
  if (!res.ok) throw new Error(`BTCPay API ${res.status}: ${await res.text()}`);
  return res.json();
}

export default router;
