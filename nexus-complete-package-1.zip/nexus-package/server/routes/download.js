// routes/download.js
import express from "express";
import fs from "fs";
import path from "path";
import { verifyToken, recordDownload } from "../lib/tokens.js";

const router = express.Router();

const TIER_FILES = {
  starter: process.env.STARTER_ZIP || "./downloads/nexus-starter.zip",
  pro:     process.env.PRO_ZIP     || "./downloads/nexus-pro.zip",
  elite:   process.env.ELITE_ZIP   || "./downloads/nexus-elite.zip",
};

const TIER_NAMES = {
  starter: "nexus-starter.zip",
  pro:     "nexus-professional.zip",
  elite:   "nexus-elite.zip",
};

// GET /download/:token
router.get("/:token", (req, res) => {
  const { token } = req.params;
  const result = verifyToken(token);

  if (!result.valid) {
    return res.status(403).send(errorPage(result.error));
  }

  const { tier, email } = result.payload;
  const filePath = path.resolve(TIER_FILES[tier] || TIER_FILES.pro);

  if (!fs.existsSync(filePath)) {
    console.error(`❌ File not found for tier ${tier}: ${filePath}`);
    return res.status(404).send(errorPage("File not found — contact support"));
  }

  // Record the download
  const count = recordDownload(token);
  console.log(`⬇ Download #${count} | tier=${tier} | email=${email}`);

  res.setHeader("Content-Disposition", `attachment; filename="${TIER_NAMES[tier]}"`);
  res.setHeader("Content-Type", "application/zip");
  fs.createReadStream(filePath).pipe(res);
});

// Landing page for expired/invalid tokens
function errorPage(reason) {
  return `<!DOCTYPE html>
<html>
<head>
  <title>NEXUS — Download Error</title>
  <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@700;900&family=Share+Tech+Mono&display=swap" rel="stylesheet"/>
  <style>
    body { margin:0; background:#010108; color:white; font-family:'Share Tech Mono',monospace;
           display:flex; align-items:center; justify-content:center; min-height:100vh; }
    .box { background:rgba(6,6,20,0.95); border:1px solid rgba(244,63,94,0.3);
           border-radius:20px; padding:48px 40px; text-align:center; max-width:460px; }
    h1 { font-family:'Orbitron',monospace; font-size:18px; color:#f43f5e;
         letter-spacing:4px; margin-bottom:16px; }
    p { color:rgba(255,255,255,0.4); font-size:13px; line-height:1.8; margin-bottom:24px; }
    a { color:#00f5a0; text-decoration:none; font-size:12px; letter-spacing:2px; }
  </style>
</head>
<body>
  <div class="box">
    <h1>DOWNLOAD ERROR</h1>
    <p>${reason}<br/><br/>Download links expire after 72 hours and allow 3 downloads.<br/>Reply to your purchase email for a new link.</p>
    <a href="mailto:support@nexustrading.io">→ CONTACT SUPPORT</a>
  </div>
</body>
</html>`;
}

export default router;
