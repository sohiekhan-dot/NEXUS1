// routes/checkout.js
// Creates BTCPay invoices dynamically when buyers click "Buy Now"
import express from "express";

const router = express.Router();

const TIER_PRICES = {
  starter: { usd: 204,  label: "NEXUS Starter",       btc: "0.003" },
  pro:     { usd: 612,  label: "NEXUS Professional",  btc: "0.009" },
  elite:   { usd: 1700, label: "NEXUS Elite",          btc: "0.025" },
};

// POST /checkout/create-invoice
// Body: { tier: "pro", email: "buyer@email.com" }
router.post("/create-invoice", express.json(), async (req, res) => {
  const { tier, email } = req.body;

  if (!TIER_PRICES[tier]) {
    return res.status(400).json({ error: "Invalid tier. Must be starter, pro, or elite." });
  }
  if (!email || !email.includes("@")) {
    return res.status(400).json({ error: "Valid email address required for delivery." });
  }

  const { usd, label, btc } = TIER_PRICES[tier];

  try {
    const response = await fetch(
      `${process.env.BTCPAY_URL}/api/v1/stores/${process.env.BTCPAY_STORE_ID}/invoices`,
      {
        method: "POST",
        headers: {
          Authorization: `token ${process.env.BTCPAY_API_KEY}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          amount: usd,
          currency: "USD",
          metadata: {
            buyerEmail: email,
            tier,
            orderId: `nexus-${tier}-${Date.now()}`,
            btcExpected: btc,
          },
          checkout: {
            speedPolicy:           "MediumSpeed",  // 1 confirmation (~10 min)
            expirationMinutes:     20,
            redirectURL:           `${process.env.SERVER_URL}/thank-you`,
            redirectAutomatically: true,
            requiresRefundEmail:   false,
          },
          receipt: { enabled: true },
        }),
      }
    );

    const invoice = await response.json();

    if (!invoice.id) {
      console.error("BTCPay invoice creation failed:", invoice);
      return res.status(500).json({ error: "Invoice creation failed. Try again." });
    }

    console.log(`🧾 Invoice created: ${invoice.id} | tier=${tier} | email=${email}`);
    res.json({ checkoutUrl: invoice.checkoutLink, invoiceId: invoice.id });

  } catch (err) {
    console.error("Checkout error:", err.message);
    res.status(500).json({ error: "Server error creating invoice." });
  }
});

// GET /thank-you  — shown after successful payment
router.get("/thank-you", (req, res) => {
  res.send(`<!DOCTYPE html>
<html>
<head>
  <title>NEXUS — Payment Received</title>
  <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@700;900&family=Share+Tech+Mono&display=swap" rel="stylesheet"/>
  <style>
    body { margin:0; background:#010108; color:white; font-family:'Share Tech Mono',monospace;
           display:flex; align-items:center; justify-content:center; min-height:100vh; }
    .box { background:rgba(6,6,20,0.95); border:1px solid rgba(0,245,160,0.25);
           border-radius:20px; padding:52px 44px; text-align:center; max-width:480px;
           box-shadow: 0 0 60px rgba(0,245,160,0.08); }
    .check { font-size:52px; color:#00f5a0; margin-bottom:20px;
             text-shadow: 0 0 30px rgba(0,245,160,0.5); }
    h1 { font-family:'Orbitron',monospace; font-size:20px; color:#00f5a0;
         letter-spacing:4px; margin-bottom:14px; }
    p  { color:rgba(255,255,255,0.45); font-size:13px; line-height:1.9; margin-bottom:0; }
    .highlight { color:#f59e0b; }
    .top-bar { position:absolute; top:0; left:0; right:0; height:2px;
               background:linear-gradient(90deg,transparent,#00f5a0,transparent);
               border-radius:20px 20px 0 0; }
  </style>
</head>
<body>
  <div class="box">
    <div class="top-bar"></div>
    <div class="check">✓</div>
    <h1>PAYMENT RECEIVED</h1>
    <p>
      Your Bitcoin transaction has been detected.<br/>
      Once it receives <span class="highlight">1 confirmation</span>
      (~10 minutes), your download link will be sent to your email.<br/><br/>
      Check your inbox — including spam.<br/>
      If you don't receive it within 30 minutes, reply to your
      confirmation email or contact support.
    </p>
  </div>
</body>
</html>`);
});

export default router;
