# BTCPay Server Setup Guide for NEXUS

This guide walks you through setting up BTCPay Server to accept Bitcoin payments
and auto-trigger product delivery for NEXUS Trading OS.

---

## Option A: Self-Hosted on Your VPS (Recommended)

### 1. Prerequisites
- Ubuntu 22.04 VPS (separate from your app server, or same — both work)
- Domain pointed at the VPS (e.g. btcpay.yourdomain.com)
- At least 2GB RAM (4GB recommended — it runs a full Bitcoin node)

### 2. Install BTCPay Server

```bash
# BTCPay has an official one-line installer
# Full docs: https://docs.btcpayserver.org/Docker/

# Install Docker
curl -fsSL https://get.docker.com | sh
systemctl enable docker && systemctl start docker

# Install BTCPay
mkdir -p /var/www/btcpayserver && cd /var/www/btcpayserver

export BTCPAY_HOST="btcpay.yourdomain.com"
export NGENX_HTTP_PORT=80
export NGENX_HTTPS_PORT=443
export BTCPAYGEN_CRYPTO1="btc"
export BTCPAYGEN_REVERSEPROXY="nginx"
export BTCPAYGEN_LIGHTNING="lnd"   # optional: remove if no Lightning
export BTCPAY_ENABLE_SSH=false

. <(curl -s https://raw.githubusercontent.com/btcpayserver/btcpayserver-docker/master/btcpay-setup.sh) -i
```

BTCPay will:
- Pull all Docker images
- Start a full Bitcoin node (syncs in ~1-3 days initially)
- Set up Nginx + Let's Encrypt SSL automatically
- Be accessible at https://btcpay.yourdomain.com

### 3. Create Your Account
- Visit https://btcpay.yourdomain.com
- Register (first account = admin)
- Create a Store

---

## Option B: Hosted BTCPay (No Server Needed)

If you don't want to run your own node, use a hosted instance:

| Provider | Cost | Notes |
|---|---|---|
| voltage.cloud | ~$12/mo | Best UX, instant setup |
| btcpay.ch | Free (donation) | Community hosted |
| lunanode.com | ~$8/mo | Self-managed but easy |

Create account → Create store → Skip to Step 4 below.

---

## Step 4: Connect Your Bitcoin Wallet

In BTCPay Dashboard:
1. **Store → Settings → Wallets → Bitcoin → Setup**
2. Choose **Connect an existing wallet**
3. Paste your **xpub / zpub** (extended public key from your wallet)
   - Electrum: Wallet → Information → Master Public Key
   - Sparrow: Settings → Addresses → xpub
   - Hardware wallet: exported from device companion app
4. Save — BTCPay can now generate fresh addresses for each invoice
   **Your private keys never touch BTCPay**

---

## Step 5: Create Your API Key

1. BTCPay Dashboard → Account (top right) → **Manage Account**
2. **API Keys → Generate Key**
3. Label: "nexus-delivery-server"
4. Permissions — check ONLY:
   - `btcpay.store.canviewinvoices`
   - `btcpay.store.cancreateinvoice` (optional, for manual invoice creation)
5. Generate → **Copy the key** → paste into your `.env` as `BTCPAY_API_KEY`

---

## Step 6: Set Up Webhook

1. BTCPay Dashboard → Your Store → **Settings → Webhooks**
2. **Create Webhook**
3. Fill in:
   ```
   Payload URL:   https://yourdomain.com/webhook/btcpay
   Secret:        (generate: openssl rand -hex 32)
   Events:        ✓ InvoiceSettled
                  ✓ InvoicePaymentSettled
                  ✓ InvoiceConfirmed
   Automatic redelivery: ✓ enabled
   ```
4. Save
5. Paste the secret into your `.env` as `BTCPAY_WEBHOOK_SECRET`

---

## Step 7: Create Your Product Invoices / Payment Buttons

### Option A: Static payment buttons on your sales page

In BTCPay: **Store → Pay Button → Create**

Configure:
```
Currency:         USD
Amount:           204       (Starter) / 612 (Pro) / 1700 (Elite)
Title:            NEXUS Starter
Custom metadata:  {"tier": "starter", "buyerEmail": "VARIABLE"}
```

Copy the generated HTML button and replace the placeholder buttons
on your `nexus-sales.html` page.

### Option B: API-generated invoices (fully automated)

When the buyer clicks "Buy Now" on your sales page, your server
creates a BTCPay invoice dynamically and redirects them to it.

Add this endpoint to your server:

```javascript
// routes/checkout.js
import express from "express";
const router = express.Router();

const TIER_PRICES = {
  starter: { usd: 204, label: "NEXUS Starter" },
  pro:     { usd: 612, label: "NEXUS Professional" },
  elite:   { usd: 1700, label: "NEXUS Elite" },
};

router.post("/create-invoice", express.json(), async (req, res) => {
  const { tier, email } = req.body;
  if (!TIER_PRICES[tier]) return res.status(400).json({ error: "Invalid tier" });
  if (!email || !email.includes("@")) return res.status(400).json({ error: "Valid email required" });

  const { usd, label } = TIER_PRICES[tier];

  const invoice = await fetch(
    `${process.env.BTCPAY_URL}/api/v1/stores/${process.env.BTCPAY_STORE_ID}/invoices`,
    {
      method: "POST",
      headers: {
        Authorization: `token ${process.env.BTCPAY_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        amount: usd,
        currency: "USD",
        metadata: {
          buyerEmail: email,
          tier: tier,
          orderId: `nexus-${tier}-${Date.now()}`,
        },
        checkout: {
          speedPolicy: "MediumSpeed",        // 1 confirmation
          expirationMinutes: 20,
          redirectURL: `https://yourdomain.com/thank-you`,
          redirectAutomatically: true,
        },
        receipt: {
          enabled: true,
          showPayments: true,
        },
      }),
    }
  );

  const data = await invoice.json();
  if (data.id) {
    // Return the BTCPay checkout URL
    res.json({ checkoutUrl: data.checkoutLink });
  } else {
    res.status(500).json({ error: "Invoice creation failed", detail: data });
  }
});

export default router;
```

Then in your sales page checkout modal, replace the static address with:
```javascript
async function handleBuy(tier, email) {
  const res = await fetch("/checkout/create-invoice", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ tier, email }),
  });
  const { checkoutUrl } = await res.json();
  window.location.href = checkoutUrl; // redirect to BTCPay checkout
}
```

---

## Step 8: Test the Full Flow

```bash
# 1. Create a test invoice manually in BTCPay dashboard
#    Store → Invoices → Create Invoice → Amount: 0.001, Currency: BTC
#    Add metadata: {"tier":"starter","buyerEmail":"test@test.com"}

# 2. Pay it using a testnet wallet or a tiny real amount

# 3. Watch your server logs:
pm2 logs nexus-delivery

# You should see:
# 📨 BTCPay event: InvoiceSettled | invoice: xxxx
# ✅ Delivered starter to test@test.com | invoice xxxx

# 4. Check the delivery email arrives
# 5. Click the download link — file downloads
# 6. Check your BTC wallet — funds arrived
```

---

## Step 9: Get Your Store ID

```
BTCPay Dashboard → Your Store → Settings → General
→ Store ID: (copy this) → paste into .env as BTCPAY_STORE_ID
```

---

## Full .env Checklist

```bash
BTCPAY_URL=https://btcpay.yourdomain.com     ✓ your BTCPay URL
BTCPAY_WEBHOOK_SECRET=abc123...              ✓ from Step 6
BTCPAY_STORE_ID=AbCdEfGh123                  ✓ from Step 9
BTCPAY_API_KEY=token_xyz...                  ✓ from Step 5
SMTP_HOST=smtp.gmail.com                     ✓
SMTP_PORT=587                                ✓
SMTP_USER=you@gmail.com                      ✓
SMTP_PASS=xxxx xxxx xxxx xxxx               ✓ Gmail App Password
EMAIL_FROM=NEXUS <you@gmail.com>             ✓
TOKEN_SECRET=<64 char random hex>            ✓ openssl rand -hex 32
SERVER_URL=https://yourdomain.com            ✓ your app server URL
ADMIN_TOKEN=<random>                         ✓ for /sales endpoint
STARTER_ZIP=./downloads/nexus-starter.zip   ✓
PRO_ZIP=./downloads/nexus-pro.zip           ✓
ELITE_ZIP=./downloads/nexus-elite.zip       ✓
```

---

## Troubleshooting

**Webhook not firing:**
- Check BTCPay → Store → Webhooks → click webhook → View Deliveries
- Ensure your server URL is publicly reachable: `curl https://yourdomain.com/health`
- Check nginx is running: `systemctl status nginx`

**Payment confirmed but no email sent:**
- Check logs: `pm2 logs nexus-delivery`
- Verify SMTP credentials: test with a manual nodemailer script
- Check spam folder

**Bitcoin node still syncing:**
- BTCPay won't process payments until the node is synced (100%)
- Check sync: BTCPay → Server Settings → Services → Full node → Sync status
- Use a hosted option (Voltage) to skip this

**Download link not working:**
- Check TOKEN_SECRET is set and consistent (don't change it after launch)
- Check the zip file exists: `ls -la /var/www/nexus-server/downloads/`
