#!/bin/bash
# deploy/setup.sh
# Run once on a fresh Ubuntu 22.04 VPS to set everything up
# Usage: bash setup.sh yourdomain.com your@email.com
#
# What this does:
#   1. Installs Node.js 20, PM2, Nginx, Certbot
#   2. Clones your repo
#   3. Installs SSL certificate via Let's Encrypt
#   4. Configures Nginx as reverse proxy
#   5. Starts the server with PM2
#   6. Sets up auto-start on reboot

set -e  # exit on any error

DOMAIN="${1:-yourdomain.com}"
EMAIL="${2:-your@email.com}"
REPO="${3:-https://github.com/YOURNAME/nexus-delivery-server.git}"
APP_DIR="/var/www/nexus-server"

echo "
╔══════════════════════════════════════════╗
║   NEXUS Server Setup                     ║
║   Domain: $DOMAIN
╚══════════════════════════════════════════╝
"

# ── 1. SYSTEM UPDATE ──────────────────────────────────────────────────────────
echo "▶ Updating system..."
apt-get update -qq && apt-get upgrade -y -qq

# ── 2. NODE.JS 20 ─────────────────────────────────────────────────────────────
echo "▶ Installing Node.js 20..."
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt-get install -y nodejs
node --version
npm --version

# ── 3. PM2 ────────────────────────────────────────────────────────────────────
echo "▶ Installing PM2..."
npm install -g pm2
pm2 --version

# ── 4. NGINX ──────────────────────────────────────────────────────────────────
echo "▶ Installing Nginx..."
apt-get install -y nginx
systemctl enable nginx
systemctl start nginx

# ── 5. CERTBOT (Let's Encrypt SSL) ────────────────────────────────────────────
echo "▶ Installing Certbot..."
apt-get install -y certbot python3-certbot-nginx
certbot --version

# ── 6. FIREWALL ───────────────────────────────────────────────────────────────
echo "▶ Configuring firewall..."
ufw allow OpenSSH
ufw allow 'Nginx Full'
ufw --force enable
ufw status

# ── 7. CLONE REPO ─────────────────────────────────────────────────────────────
echo "▶ Cloning repo..."
mkdir -p /var/www
if [ -d "$APP_DIR" ]; then
  echo "  Directory exists — pulling latest..."
  cd "$APP_DIR" && git pull origin main
else
  git clone "$REPO" "$APP_DIR"
fi
cd "$APP_DIR"

# ── 8. INSTALL DEPENDENCIES ───────────────────────────────────────────────────
echo "▶ Installing npm dependencies..."
npm install --omit=dev

# ── 9. ENV FILE ───────────────────────────────────────────────────────────────
if [ ! -f "$APP_DIR/.env" ]; then
  cp "$APP_DIR/.env.example" "$APP_DIR/.env"
  echo ""
  echo "⚠  .env file created from template."
  echo "   You MUST fill it in before starting the server:"
  echo "   nano $APP_DIR/.env"
  echo ""
fi

# ── 10. DOWNLOADS FOLDER ──────────────────────────────────────────────────────
echo "▶ Creating downloads folder..."
mkdir -p "$APP_DIR/downloads"
mkdir -p "$APP_DIR/data"
echo "  ⚠  Place your zip files in: $APP_DIR/downloads/"

# ── 11. NGINX CONFIG ──────────────────────────────────────────────────────────
echo "▶ Configuring Nginx..."
cp "$APP_DIR/deploy/nginx.conf" /etc/nginx/sites-available/nexus
# Replace placeholder domain
sed -i "s/yourdomain.com/$DOMAIN/g" /etc/nginx/sites-available/nexus
# Enable site
ln -sf /etc/nginx/sites-available/nexus /etc/nginx/sites-enabled/nexus
# Remove default site
rm -f /etc/nginx/sites-enabled/default
# Test config
nginx -t
systemctl reload nginx

# ── 12. SSL CERTIFICATE ───────────────────────────────────────────────────────
echo "▶ Obtaining SSL certificate for $DOMAIN..."
certbot --nginx \
  --non-interactive \
  --agree-tos \
  --email "$EMAIL" \
  --domains "$DOMAIN" \
  --redirect
echo "✅ SSL certificate obtained"

# Auto-renewal cron (certbot adds this automatically, but verify)
systemctl status certbot.timer || true

# ── 13. START WITH PM2 ────────────────────────────────────────────────────────
echo "▶ Starting server with PM2..."
cd "$APP_DIR"
pm2 start server.js --name nexus-delivery \
  --log /var/log/nexus-server.log \
  --error /var/log/nexus-server-error.log \
  --restart-delay 3000 \
  --max-restarts 10
pm2 save

# ── 14. PM2 STARTUP (survive reboots) ─────────────────────────────────────────
echo "▶ Setting up PM2 startup..."
pm2 startup systemd -u root --hp /root | tail -1 | bash || true
pm2 save

# ── DONE ──────────────────────────────────────────────────────────────────────
echo "
╔══════════════════════════════════════════════════════╗
║   ✅ NEXUS Server Setup Complete                     ║
╠══════════════════════════════════════════════════════╣
║                                                      ║
║  Server URL:  https://$DOMAIN
║  Health:      https://$DOMAIN/health
║  Webhook:     https://$DOMAIN/webhook/btcpay
║                                                      ║
║  Next steps:                                         ║
║  1. nano $APP_DIR/.env   (fill in your keys)
║  2. Add zip files to $APP_DIR/downloads/
║  3. pm2 restart nexus-delivery                       ║
║  4. Set webhook URL in BTCPay (see below)            ║
║                                                      ║
║  BTCPay Webhook URL:                                 ║
║  https://$DOMAIN/webhook/btcpay
║                                                      ║
╚══════════════════════════════════════════════════════╝
"
pm2 status nexus-delivery
