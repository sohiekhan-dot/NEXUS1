# NEXUS Quantum Trading Platform
### Complete Package · v1.0.0 · 2026

---

## What's Included

| Module | File | Description |
|--------|------|-------------|
| **NEXUS Merged** | `NexusMerged2026.jsx` | Main dashboard: quantum charts + prop firms + market connections |
| **Quantum Dashboard** | `QuantumDashboard2026.jsx` | Full quantum probability cloud trading OS with 2026 market data |
| **Simple Trader** | `SimpleTrader2026.jsx` | Clean easy-execution trader with one-click order panel |
| **PropTrack** | `PropTrackDashboard.jsx` | Prop firm evaluation tracker, drawdown monitor, payout manager |
| **Marketing OS** | `NexusMarketingDept.jsx` | AI sales & marketing agents (ZARA, REX, LYRA, ATLAS) |
| **Cybersuite** | `NexusCybersuite.jsx` | Original full cyberpunk trading suite |
| **Sales Page** | `NexusSalesPage.html` | Bitcoin-payment sales landing page |
| **Delivery Server** | `server/` | BTCPay webhook handler + auto email delivery |

---

## Quick Start (Frontend)

```bash
# 1. Install dependencies
npm install

# 2. Start development server
npm run dev

# 3. Open in browser
open http://localhost:3000
```

## Quick Start (Full Stack)

```bash
# 1. Install dependencies
npm install

# 2. Copy and fill environment variables
cp .env.example .env
nano .env

# 3. Run everything together
npm run dev:all
# Frontend: http://localhost:3000
# Backend:  http://localhost:3001
```

---

## Project Structure

```
nexus-package/
├── index.html              ← HTML entry point
├── main.jsx                ← React root
├── index.css               ← Global styles
├── vite.config.js          ← Vite bundler config
├── package.json            ← Dependencies
├── .env.example            ← Environment variables template
│
├── src/
│   ├── App.jsx             ← Module launcher / home screen
│   ├── NexusMerged2026.jsx        ← ⭐ Main merged dashboard
│   ├── QuantumDashboard2026.jsx   ← Quantum chart OS
│   ├── SimpleTrader2026.jsx       ← Simple trader UI
│   ├── PropTrackDashboard.jsx     ← Prop firm tracker
│   ├── NexusMarketingDept.jsx     ← AI marketing agents
│   ├── NexusCybersuite.jsx        ← Cyberpunk suite
│   └── NexusSalesPage.html        ← Sales landing page
│
├── server/
│   ├── server.js           ← Express app entry point
│   ├── routes/
│   │   ├── webhook.js      ← BTCPay payment webhook
│   │   ├── checkout.js     ← Invoice creation
│   │   └── download.js     ← Secure file delivery
│   └── lib/
│       ├── tokens.js       ← Signed download tokens
│       ├── mailer.js       ← Email delivery templates
│       └── db.js           ← Sale logging
│
└── docs/
    ├── BTCPAY_SETUP.md     ← Full BTCPay walkthrough
    ├── PROP_FIRMS.md       ← Prop firm connection guide
    └── DEPLOYMENT.md       ← Server deployment guide
```

---

## Key Features

### Quantum Charts
- **Geometric Brownian Motion** price simulation with real 2026 parameters
- **GARCH volatility clustering** — realistic vol regimes
- **Monte Carlo probability clouds** — 180 paths, 5th–95th percentile bands
- Real May 2026 prices: BTC $78,244 · ETH $2,295 · SOL $83.74

### Prop Firm Tracker
- Live evaluation progress: profit target, drawdown buffer, trading days
- Rules checklist auto-validated in real time
- Firm comparison: FTMO, Apex, TopStep, E8 Funding with real 2026 rules
- Payout history and connection guide (MT5, Rithmic, API)

### Market Connections
| Feed | Status | Key Required |
|------|--------|-------------|
| Binance WebSocket | Public | No |
| Coinbase WebSocket | Public | No |
| Bybit WebSocket | Public | No |
| Alpaca Markets | Free | Yes (free signup) |
| Polygon.io | Free tier | Yes (free signup) |

### AI Marketing Agents
Powered by Claude API (claude-sonnet-4-20250514):
- **ZARA** — Ad copy for Twitter, Reddit, Telegram, Discord
- **REX** — Outreach DMs for crypto communities  
- **LYRA** — Viral content threads and YouTube scripts
- **ATLAS** — Growth analytics and strategy reports

### Auto-Delivery Server
- BTCPay Server webhook integration
- HMAC-SHA256 signature verification
- Signed download tokens (72hr expiry, 3 downloads max)
- HTML delivery email with beautiful template
- Optional Telegram sale alerts

---

## Deployment Options

### Option A — Vercel (Frontend only, free)
```bash
npm install -g vercel
vercel --prod
```

### Option B — Railway (Full stack, free tier)
```bash
# Push to GitHub
git init && git add . && git commit -m "deploy"
git remote add origin https://github.com/YOU/nexus.git
git push -u origin main
# Connect Railway to GitHub repo, add env vars in dashboard
```

### Option C — VPS (Production)
```bash
# On Ubuntu 22.04
bash deploy/setup.sh yourdomain.com you@email.com
```

---

## API Keys You'll Want

| Service | URL | Cost | Use |
|---------|-----|------|-----|
| Alpaca | alpaca.markets | Free | US stocks + crypto live data |
| Polygon.io | polygon.io | Free tier | All markets, 15min delay free |
| BTCPay Server | btcpayserver.org | Free (self-hosted) | Accept BTC payments |
| Claude API | console.anthropic.com | Pay per use | AI marketing agents |
| Binance | binance.com | Free | Crypto trading API |

---

## Market Data Sources (Real 2026)
- BTC: $78,244 · ETH: $2,295 · SOL: $83.74 (May 2, 2026)
- Fear & Greed Index: 26 (Fear)
- BTC Dominance: 58.5%
- Total Market Cap: $2.68T
- BlackRock IBIT ETF Inflows: $630M/day
- BTC Funding Rate: -0.012% (bearish bias)

---

## Important Notices

> **This software is for educational and personal use.**
> Past simulated performance does not guarantee future results.
> Trading involves substantial risk of loss.
> This is not financial advice.
> Prop firm evaluations carry risk of losing the evaluation fee.

---

## License
MIT License — you own this code. Use, modify, and distribute freely.
